/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package BILL.Manager;

import DAL.DAO.LoginClass;
import DAL.Gateway.AdminLoginGateway;
import java.sql.SQLException;

/**
 *
 * @author SHAHRIAR
 */
public class AdminLoginManager {
    public String message;
    public String studentSession,studentSemester,adminId,adminName,adminSession;
    
    public boolean checkLogInManager(LoginClass login) throws SQLException, ClassNotFoundException {
        if(login.id.equals("")||login.password.equals("")){
            this.message="please,fill up required Information";
            return false;
        }else{
            AdminLoginGateway gateway=new AdminLoginGateway();
            if(gateway.checkLogInGateway(login)){
               this.adminId=gateway.adminId;
               this.adminName=gateway.adminName;
               this.message=gateway.message;
               this.studentSession=gateway.studentSession;
               this.studentSemester=gateway.studentSemester; 
               this.adminSession=gateway.adminSession;
               
               return true;
            }else{
               this.message=gateway.message; 
               return false;
            }
        
        }
    }

   
}
