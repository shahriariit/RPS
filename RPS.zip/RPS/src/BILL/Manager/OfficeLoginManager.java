/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package BILL.Manager;

import DAL.DAO.LoginClass;
import DAL.Gateway.OfficeLoginGateway;

/**
 *
 * @author Setu
 */
public class OfficeLoginManager {
    public String message;
    public String identification;
    public String name;
    
    public boolean checkLogInManager(LoginClass login) {
      if(login.id.equals("")||login.password.equals("")){
          this.message="please fill up required information";
          return false;
      }else{
           OfficeLoginGateway gateway=new OfficeLoginGateway();
           if(gateway.checkInLoginGateway(login)){
                this.message=gateway.message;
                this.identification=gateway.identification;
                this.name=gateway.name;
                return true;
           }else{
               this.message=gateway.message;
               return false;
           }
      }
    }
}
