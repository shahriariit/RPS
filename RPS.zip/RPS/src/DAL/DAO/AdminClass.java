/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DAL.DAO;

/**
 *
 * @author SHAHRIAR
 */
public class AdminClass {
    
    public String adminId;
    public String adminName;
    public String adminSession;

    public String getAdminId() {
        return adminId;
    }

    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }

    public String getAdminName() {
        return adminName;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }

    public String getAdminSession() {
        return adminSession;
    }

    public void setAdminSession(String adminSession) {
        this.adminSession = adminSession;
    }
     
}
