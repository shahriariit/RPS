/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DAL.Gateway;

import DAL.DAO.LoginClass;
import Database.DatabaseConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author SHAHRIAR
 */
public class AdminLoginGateway {
    public String message;
    public String adminId,adminSession;
    public String adminName,studentSession,studentSemester;
    
  //  AdminClass adminClass=new AdminClass();

    public boolean checkLogInGateway(LoginClass login) {
        try {
            //String sql="select id,name,session,semester from admin where userid = '"+login.id+"'and password = '"+login.password+"'";
              
            String sql=" select adm.adminId,(select teacherName from teacher where teacherId=adm.adminTeacherId) TeacherName,ads.adminSession,ads.semesterNo,ads.adminAssignYear from adminSession ads natural join admin adm where adm.adminUserId='"+login.id+"' and adm.adminPassword='"+login.password+"' and ads.status='YES'";
           
            Connection connectionObj=DatabaseConnection.getConnectionObject();
            Statement statement=connectionObj.prepareStatement(sql);
            ResultSet resultSet=statement.executeQuery(sql);
            while(resultSet.next()){
              
                this.adminId=resultSet.getString("adm.adminId");
                this.adminName=resultSet.getString("TeacherName");
                this.studentSession=resultSet.getString("ads.adminSession");
                this.studentSemester=resultSet.getString("ads.semesterNo");
                this.adminSession=resultSet.getString("ads.adminAssignYear");
                
                System.out.println("AdminGateway:"+studentSession+" "+studentSemester);
                this.message="Log in successful as Admin by "+resultSet.getString("TeacherName")+"("+resultSet.getString("adm.adminId")+")";
                return true;
            }
            
            this.message="Log in failed for incorrect id or password or you are not allowed"
                    + "";
            return false;
        } catch (SQLException ex) {
            Logger.getLogger(AdminLoginGateway.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } 
    }
    
}