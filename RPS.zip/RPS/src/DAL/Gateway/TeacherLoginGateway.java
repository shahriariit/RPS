/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DAL.Gateway;

import DAL.DAO.LoginClass;
import Database.DatabaseConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SHAHRIAR
 */
public class TeacherLoginGateway {

    public String message;
    public String name;
    public String identification;

    public boolean checkInLoginGateway(LoginClass login) {
        try {
            String sql = "select t.teacherId,t.teacherName from teacher t where teacherUserId = '" + login.id + "' and teacherPassword = '" + login.password + "'";

            Connection connectionObj = DatabaseConnection.getConnectionObject();
            Statement statement = connectionObj.prepareStatement(sql);
            ResultSet rs = statement.executeQuery(sql);

            while (rs.next()) {
                
                identification = rs.getString("t.teacherId");
                name = rs.getString("t.teacherName");
                this.message = "Log in succesful as Teacher by " + name + "(" + identification + ")";
                return true;
                
            }

            this.message = "Log in failed for incorrect id or password";
            return false;
        } catch (SQLException ex) {
            Logger.getLogger(TeacherLoginGateway.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
}
