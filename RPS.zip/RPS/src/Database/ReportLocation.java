/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

/**
 *
 * @author Setu
 */
public class ReportLocation {

    public String TheoryClassTestVerificationReportLocation() {
       return "C:/Users/Setu/Documents/NetBeansProjects/RPS/src/UI/Report/theoryClassTestReport.jrxml";
    }
    
    public String FirstExaminerReportLocation(){
      return "C:/Users/Setu/Documents/NetBeansProjects/RPS/src/UI/Report/FirstExaminerReport.jrxml";
    } 
    
    
    public String SecondExaminerReportLocation(){
       return "C:/Users/Setu/Documents/NetBeansProjects/RPS/src/UI/Report/SecondExaminerReport.jrxml";
    } 
    
    public String ThirdExaminerReportLocation() {
        return "C:/Users/Setu/Documents/NetBeansProjects/RPS/src/UI/Report/ThirdExaminerReport.jrxml";
    } 
    
    
     public String LabClassTestVerificationReportLocation(){
       return "C:/Users/Setu/Documents/NetBeansProjects/RPS/src/UI/Report/labClassTestReport.jrxml";
    }

    public String LabFinalTestVerificationReportLocation() {
        return "C:/Users/Setu/Documents/NetBeansProjects/RPS/src/UI/Report/labFinalReport.jrxml";
    }

    public String TheoryGradeSheetReportLocation() {
        return "C:/Users/Setu/Documents/NetBeansProjects/RPS/src/UI/Report/theoryGradeReport.jrxml";
    }

    public String LabGradeSheetReportLocation() {
        return "C:/Users/Setu/Documents/NetBeansProjects/RPS/src/UI/Report/labVerificationReport.jrxml";
    }

    public String ErrorousTheoryGradeSheetReportLocation() {
        return "C:/Users/Setu/Documents/NetBeansProjects/RPS/src/UI/Report/ErrorousTheoryGradeReport.jrxml";
    }

    public String VivaMarksCalculationSheetReportLocation() {
       return "C:/Users/Setu/Documents/NetBeansProjects/RPS/src/UI/Report/vivaReport.jrxml";
    }

 
}
