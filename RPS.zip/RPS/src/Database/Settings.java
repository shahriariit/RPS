/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import java.awt.Dimension;
import java.awt.Toolkit;

/**
 *
 * @author SHAHRIAR
 */
public class Settings {
    
      public static Dimension getScreenSize(){
        Dimension d=Toolkit.getDefaultToolkit().getScreenSize();
        return d;   
    }
    
}
