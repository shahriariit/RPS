/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package UI.database;


import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;




/**
 *
 * @author SHAHRIAR
 */
public class ChangePasswordDatabaseRetrivation {
    
     static Connection connectionObj=null;
    
    public ChangePasswordDatabaseRetrivation(Connection connectionObj){
        this.connectionObj=connectionObj;
        
    }
    
     public ResultSet StudentTableInfo(String identification)
      {
            Statement stmt = null;
            ResultSet resultSetObj = null;
        try {
            
              
             String sql = "select studentUserId ,studentPassword from student where studentIdentification = '" + identification + "'";
             stmt = connectionObj.createStatement();
             resultSetObj =  stmt.executeQuery(sql);
             return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      } 
    
     
     
     public ResultSet TeacherTableInfo(String identification)
      {
            Statement stmt = null;
            ResultSet resultSetObj = null;
        try {
            
              
             String sql = "select teacherUserId ,teacherPassword from teacher where teacherId = '" + identification + "'";
             System.out.println(sql);
             stmt =  connectionObj.createStatement();
             System.out.println(stmt);
             resultSetObj =stmt.executeQuery(sql);
             System.out.println(resultSetObj);
             return resultSetObj;
            } 
         catch (SQLException ex) {
            System.out.println(resultSetObj);
            return resultSetObj; 
        }   
      } 
    
     
    public ResultSet AdminTableInfo(String identification)
      {
            Statement stmt = null;
            ResultSet resultSetObj = null;
        try {
            
              
             String sql = "select adminUserId ,adminPassword from admin where adminId = '" + identification + "'";
            
             stmt = connectionObj.createStatement();
             resultSetObj = stmt.executeQuery(sql);
             return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      }  
    
}
