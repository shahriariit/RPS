/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package UI.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author SHAHRIAR
 */
public class DatabaseInsertion {
    static Connection connectionObj = null;

    public DatabaseInsertion(Connection connectionObj) {
        this.connectionObj = connectionObj;
    }

    
    public boolean insertErrorousStudentInfo(String string, String toString, String course, String string0, String session, String semester) {
         String sql = "INSERT INTO thirdexaminertable(resultIdentification,teacherId,courseId,studentExamRoll,studentSession,studentSemester)VALUES " + "("
                + "'" + string
                + "','" + toString
                + "','" + course
                + "','" + string0
                + "','" + session
                + "','" + semester
                
                + "')";


        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

    }

    public boolean insertTutorialInfo(String string, String text, String text0, String string0, String string1, String session, String semester, String string2, String string3, String string4) {
        String sql = "INSERT INTO classPerform(resultIdentification,teacherId,courseId,studentRoll,studentExamRoll,studentSession,studentSemester,avg,atten,classPerform)VALUES " + "('"
                           +string
                           +"','"+text
                           +"','"+text0
                           +"','" +string0
                           +"','"+string1
                           + "','" +session
                           + "','" + semester
                           + "','" + string2
                           + "','" + string3
                           + "','" + string4
                           + "')";
       System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            //Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public boolean insertfinalResult3Info(String resultIdentification, String text, String courseId, String string, String session, String semester, String string0, String string1, String string2, String string3, String string4, String string5, String string6, String string7, String string8) {
        String sql = "INSERT INTO finalResult3(resultIdentification,teacherId,courseId,studentExamRoll,studentSession,studentSemester,one,two,three,four,five,six,seven,eight,finalExam)VALUES " + "('"
                        +resultIdentification
                        + "','" + text
                        +"','"+courseId
                        + "','" + string
                        + "','" + session
                        + "','" + semester
                        + "','" + string0
                        + "','" + string1
                        + "','" + string2
                        + "','" + string3
                        + "','" + string4
                        + "','" + string5
                        + "','" + string6
                        + "','" + string7
                        + "','" + string8
                        + "')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public boolean insertfinalResult2Info(String resultIdentification, String text, String courseId, String string, String session, String semester, String string0, String string1, String string2, String string3, String string4, String string5, String string6, String string7, String string8) {
               String sql = "INSERT INTO finalResult2(resultIdentification,teacherId,courseId,studentExamRoll,studentSession,studentSemester,one,two,three,four,five,six,seven,eight,finalExam)VALUES " + "('"
                        +resultIdentification
                        + "','" + text
                        +"','"+courseId
                        + "','" + string
                        + "','" + session
                        + "','" + semester
                        + "','" + string0
                        + "','" + string1
                        + "','" + string2
                        + "','" + string3
                        + "','" + string4
                        + "','" + string5
                        + "','" + string6
                        + "','" + string7
                        + "','" + string8
                        + "')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } 
    }

    public boolean insertfinalResult1Info(String resultIdentification, String text, String courseId, String string, String session, String semester, String string0, String string1, String string2, String string3, String string4, String string5, String string6, String string7, String string8) {
                   String sql = "INSERT INTO finalResult1(resultIdentification,teacherId,courseId,studentExamRoll,studentSession,studentSemester,one,two,three,four,five,six,seven,eight,finalExam)VALUES " + "('"
                        +resultIdentification
                        + "','" + text
                        +"','"+courseId
                        + "','" + string
                        + "','" + session
                        + "','" + semester
                        + "','" + string0
                        + "','" + string1
                        + "','" + string2
                        + "','" + string3
                        + "','" + string4
                        + "','" + string5
                        + "','" + string6
                        + "','" + string7
                        + "','" + string8
                        + "')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } 
    }

    public boolean insertGradeTableInfo(String resultIdentification, String toString, String identification, String toString0, String string, String string0, String semester) {
        String sql = "INSERT INTO gradetable(resultIdentification,courseId,adminId,studentClassRoll,studentExamRoll,studentSession,studentSemester)VALUES " + "("
                                    + "'" + resultIdentification
                                    + "','" + toString
                                    + "','" + identification
                                    + "','" + toString0
                                    + "','" + string
                                    + "','" + string0
                                    + "','" + semester
                                    + "')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } 
        
        
        
    }

  public  boolean insertfinalResult12Info(String resultIdentification, String toString, String toString0, String toString1, String toString2, String toString3, String toString4, String toString5, String toString6, String toString7, String toString8) {
        String sql = "INSERT INTO firstexaminedsheet(firstExaminedId,studentExamRoll,one,two,three,four,five,six,seven,eight,total)VALUES " + "('"
                        +resultIdentification
                        + "','" + toString
                        + "','" + toString0
                        + "','" + toString1
                        + "','" + toString2
                        + "','" + toString3
                        + "','" + toString4
                        + "','" + toString5
                        + "','" + toString6
                        + "','" + toString7
                        + "','" + toString8
                        + "')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
            //JOptionPane.showMessageDialog(null, "Data already exist"); 
            return false;
        } 
    }
  
    public boolean insertfinalResultTwoInfo(String resultIdentification, String toString, String toString0, String toString1, String toString2, String toString3, String toString4, String toString5, String toString6, String toString7, String toString8) {
         String sql = "INSERT INTO secondexaminedsheet(secondExaminedId,studentExamRoll,one,two,three,four,five,six,seven,eight,total)VALUES " + "('"
                        +resultIdentification
                        + "','" + toString
                        + "','" + toString0
                        + "','" + toString1
                        + "','" + toString2
                        + "','" + toString3
                        + "','" + toString4
                        + "','" + toString5
                        + "','" + toString6
                        + "','" + toString7
                        + "','" + toString8
                        + "')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
           // Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
            //JOptionPane.showMessageDialog(null, "Data already exist"); 
            return false;
        } 
    }

   public boolean insertfinalResultThreeInfo(String resultIdentification, String toString, String toString0, String toString1, String toString2, String toString3, String toString4, String toString5, String toString6, String toString7, String toString8) {
       String sql = "INSERT INTO thirdexaminedsheet(thirdExaminedId,studentExamRoll,one,two,three,four,five,six,seven,eight,total)VALUES " + "('"
                        +resultIdentification
                        + "','" + toString
                        + "','" + toString0
                        + "','" + toString1
                        + "','" + toString2
                        + "','" + toString3
                        + "','" + toString4
                        + "','" + toString5
                        + "','" + toString6
                        + "','" + toString7
                        + "','" + toString8
                        + "')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
           // Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
            //JOptionPane.showMessageDialog(null, "Data already exist"); 
            return false;
        } 
    }   

    public boolean insertClassTestInfo(String resultIdentification, String toString, String toString0, String toString1, String toString2, String toString3, String toString4, String toString5, String toString6, String toString7,String toString8) {
       String sql = "INSERT INTO classperformancetable(classTestId,studentClassRoll,studentExamRoll,classTestOne,classTestTwo,classTestThree,classTestFinal,classAssignment,classAttendance,classPresentation,total)VALUES " + "('"
                        +resultIdentification
                        + "','" + toString
                        + "','" + toString0
                        + "','" + toString1
                        + "','" + toString2
                        + "','" + toString3
                        + "','" + toString4
                        + "','" + toString5
                        + "','" + toString6
                        + "','" + toString7
                        + "','" + toString8
                        + "')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
           //Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
           //JOptionPane.showMessageDialog(null, "Data already exist");
            System.out.println("Data already Exist");
            return false;
        } 
    }
    
    public boolean insertlabClassTestInfo(String resultIdentification, String toString, String toString0, String toString1, String toString2, String toString3, String toString4, String toString5, String toString6, String toString7, String toString8,String toString9) {
         String sql = "INSERT INTO labclassperformancetable(labClassTestId,studentClassRoll,studentExamRoll,classTestOne,classTestTwo,classTestThree,classTestFinal,classLabReport,classAssignment,classAttendance,classPresentation,total)VALUES " + "('"
                        +resultIdentification
                        + "','" + toString
                        + "','" + toString0
                        + "','" + toString1
                        + "','" + toString2
                        + "','" + toString3
                        + "','" + toString4
                        + "','" + toString5
                        + "','" + toString6
                        + "','" + toString7
                        + "','" + toString8
                        + "','" + toString9
                        + "')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
           //Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
           //JOptionPane.showMessageDialog(null, "Data already exist");
            System.out.println("Data already Exist");
            return false;
        } 
    }
    
    public boolean insertLabfinalResultInfo(String resultIdentification, String text, String text0, String text1, String text2) {
         String sql = "INSERT INTO labexaminedsheet(labfinalExaminedId,studentExamRoll,experiment,viva,total)VALUES " + "('"
                        +resultIdentification
                        + "','" + text
                        + "','" + text0
                        + "','" + text1
                        + "','" + text2   
                        + "')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
           Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
           //JOptionPane.showMessageDialog(null, "Data already exist");
            System.out.println("Data already Exist");
            return false;
        } 
    }

   public boolean insertOtherfinalResultInfo(String resultIdentification, String text, String text0, String text1, String text2,String text3,String text4) {
          String sql = "INSERT INTO vivaexaminedsheet(vivaExaminedId,studentExamRoll,ProjectWork,viva,total,GPA,LetterGrade)VALUES " + "('"
                        +resultIdentification
                        + "','" + text
                        + "','" + text0
                        + "','" + text1
                        + "','" + text2
                        + "','" + text3
                        + "','" + text4 
                        + "')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
           //Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
           //JOptionPane.showMessageDialog(null, "Data already exist");
            System.out.println("Data already Exist");
            return false;
        } 
    }
   
  

   /* public boolean insertTheoryGradeResultInfo(String resultIdentification, String toString, String toString0, String toString1, String toString2, String toString3, String toString4, String toString5, String toString6, String toString7, String toString8, String toString9,String toString10) {
       String sql = "INSERT INTO theorygradeexaminedsheet(theoryGradeExaminedId,studentExamRoll,firstExaminerMarks,secondExaminerMarks,differences,averages,finalMarks,tutorialMarks,total,adminId,adminSession,semesterNo,courseId)VALUES " + "('"
                        +resultIdentification
                        + "','" + toString
                        + "','" + toString0
                        + "','" + toString1
                        + "','" + toString2 
                        + "','" + toString3
                        + "','" + toString4
                        + "','" + toString5
                        + "','" + toString6 
                        + "','" + toString7
                        + "','" + toString8
                        + "','" + toString9 
                        + "','" + toString10
                        + "')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            //Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
           //JOptionPane.showMessageDialog(null, "Data already exist");
            System.out.println("Data already Exist");
            return false;
        } 
    }*/
    
    
    public boolean insertTheoryGradeResultInfo(String resultIdentification, String studentExamRoll, String firstExaminerMarks, String secondExaminerMarks, String differences,String averages,String finalMarks,String tutorialMarks,String total,String GPA,String LetterGrade,String adminId, String studentSession, String semesterNo, String courseId,String status) {
       /*  String sql = "INSERT INTO theorygradeexaminedsheet(theoryGradeExaminedId,studentExamRoll,firstExaminerMarks,secondExaminerMarks,differences,tutorialMarks,adminId,studentSession,semesterNo,courseId,status)VALUES " + "('"
                        +resultIdentification
                        + "','" + studentExamRoll
                        + "','" + firstExaminerMarks
                        + "','" + secondExaminerMarks
                        + "','" + differences 
                        + "','" + tutorialMarks
                        + "','" + adminId
                        + "','" + studentSession
                        + "','" + semesterNo 
                        + "','" + courseId 
                        + "','" + status  
                        + "')"; */
         
         String sql="INSERT INTO `rpsdbms`.`theorygradeexaminedsheet` (`theoryGradeExaminedId`, `studentExamRoll`, `firstExaminerMarks`, `secondExaminerMarks`, `differences`, `averages`, `finalMarks`, `tutorialMarks`, `total`, `GPA`, `LetterGrade`, `adminId`, `studentSession`, `semesterNo`, `courseId`, `status`) VALUES ('"
                 +resultIdentification
                 + "','" + studentExamRoll
                 + "','" + firstExaminerMarks
                 + "','" + secondExaminerMarks
                 + "','" + differences 
                 + "','" + averages 
                 + "', '" + finalMarks 
                 + "', '" + tutorialMarks 
                 + "', '" + total 
                 + "', '" + GPA
                 + "','" +  LetterGrade 
                 + "','" + adminId 
                 + "', '"+studentSession
                 + "', '"+semesterNo
                 + "','"+courseId
                 + "', 'OK')";
         
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
             Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
           //JOptionPane.showMessageDialog(null, "Data already exist");
            System.out.println("Data already Exist");
            return false;
        } 
    }
    
    
    
    /*public boolean insertErrorousTheoryGradeResultInfo(String resultIdentification, String toString, String toString0, String toString1, String toString2, String toString3, String toString4, String toString5, String toString6, String identification, String studentSession, String semesterNo, String courseId) {
        String sql = "INSERT INTO erroroustheorygradeexaminedsheet(theoryGradeExaminedId,studentExamRoll,firstExaminerMarks,secondExaminerMarks,differences,averages,finalMarks,tutorialMarks,total,adminId,adminSession,semesterNo,courseId)VALUES " + "('"
                        +resultIdentification
                        + "','" + toString
                        + "','" + toString0
                        + "','" + toString1
                        + "','" + toString2 
                        + "','" + toString3
                        + "','" + toString4
                        + "','" + toString5
                        + "','" + toString6
                        + "','" + identification 
                        + "','" + studentSession
                        + "','" + semesterNo
                        + "','" + courseId
                        + "')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            //Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
           //JOptionPane.showMessageDialog(null, "Data already exist");
            System.out.println("Data already Exist");
            return false;
        } 
    }*/
   
    public boolean insertErrorousTheoryGradeResultInfo(String resultIdentification, String studentExamRoll, String firstExaminerMarks, String secondExaminerMarks, String differences, String tutorialMarks, String identification, String studentSession, String semesterNo, String courseId,String status) {
        String sql = "INSERT INTO theorygradeexaminedsheet(theoryGradeExaminedId,studentExamRoll,firstExaminerMarks,secondExaminerMarks,differences,tutorialMarks,adminId,studentSession,semesterNo,courseId,status)VALUES " + "('"
                        +resultIdentification
                        + "','" + studentExamRoll
                        + "','" + firstExaminerMarks
                        + "','" + secondExaminerMarks
                        + "','" + differences 
                        + "','" + tutorialMarks
                        + "','" + identification 
                        + "','" + studentSession
                        + "','" + semesterNo
                        + "','" + courseId 
                        + "','" + status
                        + "')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
             Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
            //JOptionPane.showMessageDialog(null, "Data already exist");
            System.out.println("Data already Exist");
            return false;
        } 
    } 
    
    public boolean insertLabGradeResultInfo(String resultIdentification, String toString, String toString0, String toString1, String toString2,String toString3,String toString4) {
         String sql = "INSERT INTO labgradeexaminedsheet(labGradeExaminedId,studentExamRoll,labClassTest,labFinalExam,GPA,LetterGrade,total)VALUES " + "('"
                        +resultIdentification
                        + "','" + toString
                        + "','" + toString0
                        + "','" + toString1
                        + "','" + toString2 
                        + "','" + toString3
                        + "','" + toString4
                        + "')"; 
         
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
           //JOptionPane.showMessageDialog(null, "Data already exist");
            System.out.println("Data already Exist");
            return false;
        } 
    }
    
   /* public boolean insertLabGradeResultInfo(String resultIdentification, String toString, String toString0, String toString1) {
       String sql = "INSERT INTO labgradeexaminedsheet(labGradeExaminedId,studentExamRoll,labClassTest,labFinalExam)VALUES " + "('"
                        +resultIdentification
                        + "','" + toString
                        + "','" + toString0
                        + "','" + toString1
                        + "')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
           //JOptionPane.showMessageDialog(null, "Data already exist");
            System.out.println("Data already Exist");
            return false;
        } 
    }*/
    
    public boolean insertCourseFirstExaminerAssignInfo(String resultIdentification, String toString, String teacherId, String session, String semester, String courseType,String assignYear) {
        String sql="insert into coursefirstexaminerassigntable values('"+resultIdentification+"','"+toString+"','"+teacherId+"','"+session+"','"+semester+"','"+courseType+"','"+assignYear+"')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
           // Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
            JOptionPane.showMessageDialog(null, "Data already exist(AT)"); 
            return false;
        } 
    }

    public boolean insertFirstExaminerStatus(String string, String resultIdentification, String string0) {
        String sql="insert into firstexaminedstatus(examinerOneTagId,assignId,ExaminerOneStatus) values('"+string+"','"+resultIdentification+"','"+string0+"')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
           //Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
            JOptionPane.showMessageDialog(null, "Data already exist(FE)"); 
            return false;
        } 
    }

     public boolean insertThirdExaminerStatus(String string, String resultIdentification, String string0){
        String sql="insert into thirdexaminedstatus(examinerThreeTagId,assignId,ExaminerThreeStatus) values('"+string+"','"+resultIdentification+"','"+string0+"')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
           // Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
            JOptionPane.showMessageDialog(null, "Data already exist(TE)"); 
            return false;
        } 
    }
     

    public boolean insertClassTestStatus(String string, String resultIdentification, String string0) {
        String sql="insert into classteststatus(classtestTagId,assignId,classTestStatus) values('"+string+"','"+resultIdentification+"','"+string0+"')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
           // Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
            JOptionPane.showMessageDialog(null, "Data already exist(CT)"); 
            
            return false;
        } 
    }

    public boolean insertCourseSecondExaminerAssignInfo(String resultIdentification, String toString, String teacherId2, String session, String semester, String courseType, String assignYear) {
        String sql="insert into coursesecondexaminerassigntable values('"+resultIdentification+"','"+toString+"','"+teacherId2+"','"+session+"','"+semester+"','"+courseType+"','"+assignYear+"')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
           // Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
           // JOptionPane.showMessageDialog(null, "Data already exist in Table 2nd"); 
            return false;
        } 
    }
    
    public boolean insertCourseThirdExaminerAssignInfo(String resultIdentification, String toString, String teacherId3, String session, String semester, String courseType, String assignYear) {
        String sql="insert into coursethirdexaminerassigntable values('"+resultIdentification+"','"+toString+"','"+teacherId3+"','"+session+"','"+semester+"','"+courseType+"','"+assignYear+"')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
           // Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
           // JOptionPane.showMessageDialog(null, "Data already exist in Table 2nd"); 
            return false;
        } 
    }


    public boolean insertSecondExaminerStatus(String string, String resultIdentification, String string0) {
         String sql="insert into secondexaminedstatus(examinerTwoTagId,assignId,ExaminerTwoStatus) values('"+string+"','"+resultIdentification+"','"+string0+"')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
           // Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
            JOptionPane.showMessageDialog(null, "Data already exist in Table 2nd"); 
            return false;
        } 
    }

    public boolean insertLabCourseExaminerAssignInfo(String resultIdentification, String toString, String labTeacherId, String session, String semester, String courseType, String assignYear) {
        String sql="insert into labcourseexaminerassigntable values('"+resultIdentification+"','"+toString+"','"+labTeacherId+"','"+session+"','"+semester+"','"+courseType+"','"+assignYear+"')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
            JOptionPane.showMessageDialog(null, "Data already exist(LAT)"); 
            return false;
        } 
    }

    public boolean insertLabExaminerStatus(String string, String resultIdentification, String string0) {
        String sql="insert into labfinalexaminedstatus(labfinalexaminerTagId,assignId,labfinalExaminerStatus) values('"+string+"','"+resultIdentification+"','"+string0+"')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
           // Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
            JOptionPane.showMessageDialog(null, "Data already exist(LE)"); 
            return false;
        } 
    }

    public boolean insertLabClassTestStatus(String string, String resultIdentification, String string0) {
        String sql="insert into labclassteststatus(labClassTestTagId,assignId,classTestStatus) values('"+string+"','"+resultIdentification+"','"+string0+"')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            //Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
            JOptionPane.showMessageDialog(null, "Data already exist(LCT)"); 
            
            return false;
        } 
    }

  
    public boolean insertFourYear2ndSemesterInfo(String identification, String studentSession, String semesterNo, String toString, String toString0, String toString1, String toString2, String toString3, String toString4, String toString5, String toString6, String toString7, String toString8, String toString9, String toString10, String toString11, String toString12, String toString13, String toString14, String toString15, String toString16, String toString17, String toString18, String toString19, String toString20, String toString21, String toString22, String toString23, String toString24, String toString25, String toString26) {
        String sql="insert into fouryear2ndsemestergradesheet(adminId,adminSession,semesterNo,studentExamRoll,F800,G800,C801,F801,T801,G801,C802,F802,T802,G802,C803,F803,T803,G803,C804,F804,T804,G804,C805,F805,T805,G805,C807,F807,T807,G807,CGPA) values('"+identification+"','"+
                                                              studentSession+"','"+
                                                              semesterNo+"','"+ 
                                                              toString+"','"+
                                                              toString0+"','"+ 
                                                              toString1+"','"+
                                                              toString2+"','"+ 
                                                              toString3+"','"+
                                                              toString4+"','"+ 
                                                              toString5+"','"+
                                                              toString6+"','"+
                                                              toString7+"','"+
                                                              toString8+"','"+ 
                                                              toString9+"','"+
                                                              toString10+"','"+ 
                                                              toString11+"','"+
                                                              toString12+"','"+ 
                                                              toString13+"','"+
                                                              toString14+"','"+ 
                                                              toString15+"','"+
                                                              toString16+"','"+ 
                                                              toString17+"','"+
                                                              toString18+"','"+
                                                              toString19+"','"+
                                                              toString20+"','"+ 
                                                              toString21+"','"+
                                                              toString22+"','"+ 
                                                              toString23+"','"+
                                                              toString24+"','"+ 
                                                              toString25+"','"+
                                                              toString26+
                                                              "')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
           // JOptionPane.showMessageDialog(null, "Data already exist(FGT)"); 
            
            return false;
        } 
    }

  /*  public boolean insertFinalGradeInfo(String toString, String toString0, String toString1, String toString2, String toString3, String toString4, String toString5, String toString6, String toString7, String toString8, String toString9, String toString10, String toString11, String toString12, String toString13, String toString14, String toString15, String toString16, String toString17, String toString18, String toString19, String toString20, String toString21, String toString22, String toString23, String toString24, String toString25, String toString26, String toString27, String toString28, String toString29, String toString30, String toString31, String toString32, String toString33, String toString34, String toString35, String toString36, String toString37, String toString38, String toString39, String toString40, String toString41, String toString42, String toString43, String toString44, String toString45, String toString46, String toString47, String toString48, String toString49, String toString50, String toString51, String toString52, String toString53, String toString54, String toString55, String toString56, String toString57, String toString58, String toString59, String toString60, String toString61, String toString62) {
         String sql="insert into finalgradesheet values('"+
                                                              toString+"','"+
                                                              toString0+"','"+ 
                                                              toString1+"','"+
                                                              toString2+"','"+ 
                                                              toString3+"','"+
                                                              toString4+"','"+ 
                                                              toString5+"','"+
                                                              toString6+"','"+
                                                              toString7+"','"+
                                                              toString8+"','"+ 
                                                              toString9+"','"+
                                                              toString10+"','"+ 
                                                              toString11+"','"+
                                                              toString12+"','"+ 
                                                              toString13+"','"+
                                                              toString14+"','"+ 
                                                              toString15+"','"+
                                                              toString16+"','"+ 
                                                              toString17+"','"+
                                                              toString18+"','"+
                                                              toString19+"','"+
                                                              toString20+"','"+ 
                                                              toString21+"','"+
                                                              toString22+"','"+ 
                                                              toString23+"','"+
                                                              toString24+"','"+ 
                                                              toString25+"','"+
                                                              toString26+"','"+ 
                                                              toString27+"','"+
                                                              toString28+"','"+
                                                              toString29+"','"+ 
                                                              toString30+"','"+   
                                                              toString31+"','"+
                                                              toString32+"','"+ 
                                                              toString33+"','"+
                                                              toString34+"','"+ 
                                                              toString35+"','"+
                                                              toString36+"','"+ 
                                                              toString37+"','"+
                                                              toString38+"','"+
                                                              toString39+"','"+ 
                                                              toString40+"','"+ 
                                                              toString41+"','"+
                                                              toString42+"','"+ 
                                                              toString43+"','"+
                                                              toString44+"','"+ 
                                                              toString45+"','"+
                                                              toString46+"','"+ 
                                                              toString47+"','"+
                                                              toString48+"','"+
                                                              toString49+"','"+ 
                                                              toString50+"','"+ 
                                                              toString51+"','"+
                                                              toString52+"','"+ 
                                                              toString53+"','"+
                                                              toString54+"','"+ 
                                                              toString55+"','"+ 
                                                              toString56+"','"+
                                                              toString57+"','"+ 
                                                              toString58+"','"+ 
                                                              toString59+"','"+ 
                                                              toString60+"','"+ 
                                                              toString61+"','"+
                                                              toString62+"','"+ 
                                                              toString63+
                                                              "')"; 
         
         
         String sql="INSERT INTO `rpsdbms`.`finalgradesheet` (`adminId`, `studentSession`, `semesterNo`, `studentExamRoll`, "
                 + "     `Subject1Examiner1`, `Subject1Examiner2`, `Subject1Examiner3`, `Subject1Average`, `Subject1Tutorial`, `Subject1Total`, "
                 + "     `Subject2Examiner1`, `Subject2Examiner2`, `Subject2Examiner3`, `Subject2Average`, `Subject2Tutorial`, `Subject2Total`, "
                 + "     `Subject3Examiner1`, `Subject3Examiner2`, `Subject3Examiner3`, `Subject3Average`, `Subject3Tutorial`, `Subject3Total`, "
                 + "     `Subject4Examiner1`, `Subject4Examiner2`, `Subject4Examiner3`, `Subject4Average`, `Subject4Tutorial`, `Subject4Total`, "
                 + "     `Subject5Examiner1`, `Subject5Examiner2`, `Subject5Examiner3`, `Subject5Average`, `Subject5Tutorial`, `Subject5Total`, "
                 + "     `Subject6Examiner1`, `Subject6Examiner2`, `Subject6Examiner3`, `Subject6Average`, `Subject6Tutorial`, `Subject6Total`,"
                 + "     `Subject7Tutorial`, `Subject7LabFinal`, `Subject7Total`, "
                 + "     `Subject8Tutorial`, `Subject8LabFinal`, `Subject8Total`, "
                 + "     `Subject9Tutorial`, `Subject9LabFinal`, `Subject9Total`, "
                 + "     `Subject10Tutorial`, `Subject10LabFinal`, `Subject10Total`) VALUES ('"+
                                                              toString+"','"+
                                                              toString0+"','"+ 
                                                              toString1+"','"+
                                                              toString2+"','"+ 
                                                              toString3+"','"+
                                                              toString4+"','"+ 
                                                              toString5+"','"+
                                                              toString6+"','"+
                                                              toString7+"','"+
                                                              toString8+"','"+ 
                                                              toString9+"','"+
                                                              toString10+"','"+ 
                                                              toString11+"','"+
                                                              toString12+"','"+ 
                                                              toString13+"','"+
                                                              toString14+"','"+ 
                                                              toString15+"','"+
                                                              toString16+"','"+ 
                                                              toString17+"','"+
                                                              toString18+"','"+
                                                              toString19+"','"+
                                                              toString20+"','"+ 
                                                              toString21+"','"+
                                                              toString22+"','"+ 
                                                              toString23+"','"+
                                                              toString24+"','"+ 
                                                              toString25+"','"+
                                                              toString26+"','"+ 
                                                              toString27+"','"+
                                                              toString28+"','"+
                                                              toString29+"','"+ 
                                                              toString30+"','"+   
                                                              toString31+"','"+
                                                              toString32+"','"+ 
                                                              toString33+"','"+
                                                              toString34+"','"+ 
                                                              toString35+"','"+
                                                              toString36+"','"+ 
                                                              toString37+"','"+
                                                              toString38+"','"+
                                                              toString39+"','"+ 
                                                              toString40+"','"+ 
                                                              toString41+"','"+
                                                              toString42+"','"+ 
                                                              toString43+"','"+
                                                              toString44+"','"+ 
                                                              toString45+"','"+
                                                              toString46+"','"+ 
                                                              toString47+"','"+
                                                              toString48+"','"+
                                                              toString49+"','"+ 
                                                              
                                                              toString50+
                                                              "')";
         
         
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
           // JOptionPane.showMessageDialog(null, "Data already exist(FGT)"); 
            
            return false;
        } 
    }*/

   /* public boolean insertFinalGradeInfo(String identification, String studentSession, String semesterNo, String toString, String toString0, String toString1, String toString2, String toString3, String toString4, String toString5, String toString6, String toString7, String toString8, String toString9, String toString10, String toString11, String toString12, String toString13, String toString14, String toString15, String toString16, String toString17, String toString18, String toString19, String toString20, String toString21, String toString22, String toString23, String toString24, String toString25, String toString26, String toString27, String toString28, String toString29, String toString30, String toString31, String toString32, String toString33, String toString34, String toString35, String toString36, String toString37, String toString38, String toString39, String toString40, String toString41, String toString42, String toString43, String toString44, String toString45, String toString46, String toString47, String toString48, String toString49, String toString50, String toString51, String toString52, String toString53, String toString54, String toString55, String toString56, String toString57, String toString58, String toString59) {
               String sql="insert into finalgradesheet values('"+
                                                              toString+"','"+
                                                              toString0+"','"+ 
                                                              toString1+"','"+
                                                              toString2+"','"+ 
                                                              toString3+"','"+
                                                              toString4+"','"+ 
                                                              toString5+"','"+
                                                              toString6+"','"+
                                                              toString7+"','"+
                                                              toString8+"','"+ 
                                                              toString9+"','"+
                                                              toString10+"','"+ 
                                                              toString11+"','"+
                                                              toString12+"','"+ 
                                                              toString13+"','"+
                                                              toString14+"','"+ 
                                                              toString15+"','"+
                                                              toString16+"','"+ 
                                                              toString17+"','"+
                                                              toString18+"','"+
                                                              toString19+"','"+
                                                              toString20+"','"+ 
                                                              toString21+"','"+
                                                              toString22+"','"+ 
                                                              toString23+"','"+
                                                              toString24+"','"+ 
                                                              toString25+"','"+
                                                              toString26+"','"+ 
                                                              toString27+"','"+
                                                              toString28+"','"+
                                                              toString29+"','"+ 
                                                              toString30+"','"+   
                                                              toString31+"','"+
                                                              toString32+"','"+ 
                                                              toString33+"','"+
                                                              toString34+"','"+ 
                                                              toString35+"','"+
                                                              toString36+"','"+ 
                                                              toString37+"','"+
                                                              toString38+"','"+
                                                              toString39+"','"+ 
                                                              toString40+"','"+ 
                                                              toString41+"','"+
                                                              toString42+"','"+ 
                                                              toString43+"','"+
                                                              toString44+"','"+ 
                                                              toString45+"','"+
                                                              toString46+"','"+ 
                                                              toString47+"','"+
                                                              toString48+"','"+
                                                              toString49+"','"+ 
                                                              toString50+"','"+ 
                                                              toString51+"','"+
                                                              toString52+"','"+ 
                                                              toString53+"','"+
                                                              toString54+"','"+ 
                                                              toString55+"','"+ 
                                                              toString56+"','"+
                                                              toString57+"','"+ 
                                                              toString58+"','"+
                                                              toString59+
                                                              "')";
        System.out.println(sql);

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
           // JOptionPane.showMessageDialog(null, "Data already exist(FGT)"); 
            
            return false;
        } 
    }*/

    public boolean insertFinalGradeInfo(String toString, String toString0, String toString1, String toString2, String toString3, String toString4, String toString5, String toString6, String toString7, String toString8, String toString9, String toString10, String toString11, String toString12, String toString13, String toString14, String toString15, String toString16, String toString17, String toString18, String toString19, String toString20, String toString21, String toString22, String toString23, String toString24, String toString25, String toString26, String toString27, String toString28, String toString29, String toString30, String toString31, String toString32, String toString33, String toString34, String toString35, String toString36, String toString37, String toString38, String toString39, String toString40, String toString41, String toString42, String toString43, String toString44, String toString45, String toString46, String toString47, String toString48, String toString49, String toString50, String toString51, String toString52, String toString53, String toString54, String toString55, String toString56, String toString57, String toString58, String toString59, String toString60, String toString61, String toString62, String toString63, String toString64, String toString65, String toString66, String toString67, String toString68, String toString69, String toString70, String toString71, String toString72, String toString73, String toString74, String toString75, String toString76, String toString77, String toString78, String toString79, String toString80, String toString81, String toString82, String toString83) {
        String sql="INSERT INTO `rpsdbms`.`finalgradesheet` (`adminId`, `studentSession`, `semesterNo`, `studentExamRoll`, "
                + "`Subject1Examiner1`, `Subject1Examiner2`, `Subject1Examiner3`, `Subject1Average`, `Subject1Tutorial`, `Subject1Total`, `Subject1GPA`, "
                + "`Subject2Examiner1`, `Subject2Examiner2`, `Subject2Examiner3`, `Subject2Average`, `Subject2Tutorial`, `Subject2Total`, `Subject2GPA`, "
                + "`Subject3Examiner1`, `Subject3Examiner2`, `Subject3Examiner3`, `Subject3Average`, `Subject3Tutorial`, `Subject3Total`, `Subject3GPA`, "
                + "`Subject4Examiner1`, `Subject4Examiner2`, `Subject4Examiner3`, `Subject4Average`, `Subject4Tutorial`, `Subject4Total`, `Subject4GPA`, "
                + "`Subject5Examiner1`, `Subject5Examiner2`, `Subject5Examiner3`, `Subject5Average`, `Subject5Tutorial`, `Subject5Total`, `Subject5GPA`, "
                + "`Subject6Examiner1`, `Subject6Examiner2`, `Subject6Examiner3`, `Subject6Average`, `Subject6Tutorial`, `Subject6Total`, `Subject6GPA`, "
                + "`Subject7Examiner1`, `Subject7Examiner2`, `Subject7Examiner3`, `Subject7Average`, `Subject7Tutorial`, `Subject7Total`, `Subject7GPA`, "
                + "`Subject8Tutorial`, `Subject8LabFinal`, `Subject8Total`, `Subject8GPA`,"
                + "`Subject9Tutorial`, `Subject9LabFinal`, `Subject9Total`, `Subject9GPA`, "
                + "`Subject10Tutorial`, `Subject10LabFinal`, `Subject10Total`, `Subject10GPA`, "
                + "`Subject11Tutorial`, `Subject11LabFinal`, `Subject11Total`, `Subject11GPA`, "
                + "`Subject12Tutorial`, `Subject12LabFinal`, `Subject12Total`, `Subject12GPA`, "
                + "`Subject13Tutorial`, `Subject13LabFinal`, `Subject13Total`, `Subject13GPA`, "
                + "`Subject14Project`, `Subject14Viva`, `Subject14Total`, `Subject14GPA`, "
                + "`Subject15Viva`, `Subject15Total`, `Subject15GPA`, `TotalCGPA`) VALUES ('"+
                                                              toString+"','"+
                                                              toString0+"','"+ 
                                                              toString1+"','"+
                                                              toString2+"','"+ 
                                                              toString3+"','"+
                                                              toString4+"','"+ 
                                                              toString5+"','"+
                                                              toString6+"','"+
                                                              toString7+"','"+
                                                              toString8+"','"+ 
                                                              toString9+"','"+
                                                              toString10+"','"+ 
                                                              toString11+"','"+
                                                              toString12+"','"+ 
                                                              toString13+"','"+
                                                              toString14+"','"+ 
                                                              toString15+"','"+
                                                              toString16+"','"+ 
                                                              toString17+"','"+
                                                              toString18+"','"+
                                                              toString19+"','"+
                                                              toString20+"','"+ 
                                                              toString21+"','"+
                                                              toString22+"','"+ 
                                                              toString23+"','"+
                                                              toString24+"','"+ 
                                                              toString25+"','"+
                                                              toString26+"','"+ 
                                                              toString27+"','"+
                                                              toString28+"','"+
                                                              toString29+"','"+ 
                                                              toString30+"','"+   
                                                              toString31+"','"+
                                                              toString32+"','"+ 
                                                              toString33+"','"+
                                                              toString34+"','"+ 
                                                              toString35+"','"+
                                                              toString36+"','"+ 
                                                              toString37+"','"+
                                                              toString38+"','"+
                                                              toString39+"','"+ 
                                                              toString40+"','"+ 
                                                              toString41+"','"+
                                                              toString42+"','"+ 
                                                              toString43+"','"+
                                                              toString44+"','"+ 
                                                              toString45+"','"+
                                                              toString46+"','"+ 
                                                              toString47+"','"+
                                                              toString48+"','"+
                                                              toString49+"','"+ 
                                                              toString50+"','"+ 
                                                              toString51+"','"+
                                                              toString52+"','"+ 
                                                              toString53+"','"+
                                                              toString54+"','"+ 
                                                              toString55+"','"+
                                                              toString56+"','"+ 
                                                              toString57+"','"+
                                                              toString58+"','"+
                                                              toString59+"','"+ 
                                                              toString60+"','"+ 
                                                              toString61+"','"+
                                                              toString62+"','"+ 
                                                              toString63+"','"+
                                                              toString64+"','"+ 
                                                              toString65+"','"+
                                                              toString66+"','"+ 
                                                              toString67+"','"+
                                                              toString68+"','"+
                                                              toString69+"','"+ 
                                                              toString70+"','"+ 
                                                              toString71+"','"+
                                                              toString72+"','"+ 
                                                              toString73+"','"+
                                                              toString74+"','"+ 
                                                              toString75+"','"+
                                                              toString76+"','"+ 
                                                              toString77+"','"+
                                                              toString78+"','"+
                                                              toString79+"','"+ 
                                                              toString80+"','"+ 
                                                              toString81+"','"+
                                                              toString82+"','"+  
                                                              toString83+
                                                              "')";
        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
           // JOptionPane.showMessageDialog(null, "Data already exist(FGT)"); 
            
            return false;
        } 
    
    
    }

    public boolean insertTempTheoryTableUploadInfo(String toString, String toString0, String toString1, String toString2, String toString3, String toString4, String toString5, String toString6, String toString7) {
       
        String sql="INSERT INTO `rpsdbms`.`temptheorygradeexaminedsheet` (`SubmissionId`, `adminId`, `studentSession`, `semesterNo`, `courseId`, `studentExamRoll`, `FirstExaminerMarks`, `SecondExaminerMarks`, `TutorialMarks`) VALUES ("
                + "  '"+toString+"', '"+toString0+"', '"+toString1+"', '"+toString2+"', '"+toString3+"', '"+toString4+"', '"+toString5+"', '"+toString6+"', '"+toString7+"')";
    
         Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
           // JOptionPane.showMessageDialog(null, "Data already exist(FGT)"); 
            
            return false;
        } 
    
    }

    public boolean insertTempLabTableUploadInfo(String toString, String toString0, String toString1, String toString2, String toString3, String toString4, String toString5, String toString6) {
          String sql="INSERT INTO `rpsdbms`.`templabgradeexaminedsheet` (`SubmissionId`, `adminId`, `studentSession`, `semesterNo`, `courseId`, `studentExamRoll`, `LabClassTest`, `LabFinalExam`) VALUES ("
                + "  '"+toString+"', '"+toString0+"', '"+toString1+"', '"+toString2+"', '"+toString3+"', '"+toString4+"', '"+toString5+"','"+toString6+"')";
    
         Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
         }catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex); 
           // JOptionPane.showMessageDialog(null, "Data already exist(FGT)"); 
            
            return false;
        } 
    }

    public boolean insertTeacherUploadInfo(String teacherId, String teacherName, String teacherDesignation, String teacherJoinDate, String teacherEmailId, String teacherSex, String teacherContactNo, String teacherPresentAddress, String teacherPermanentAddress, String teacherPassword) {

        String sql = "INSERT INTO `rpsdbms`.`teacher` (`teacherId`, `teacherName`, `teacherDesignation`, `teacherJoinDate`, `teacherEmailId`, `teacherSex`, `teacherContactNo`, `teacherPresentAddress`, `teacherPermanentAddress`, `teacherPassword`) VALUES ("
                + "'" + teacherId + "', "
                
                + "'" + teacherName + "', "
                + "'" + teacherDesignation + "',"
                + "'" + teacherJoinDate + "', "
                + "'" + teacherEmailId + "', "
                + "'" + teacherSex + "',"
                + "'" + teacherContactNo + "', "
                + "'" + teacherPresentAddress + "', "
                + "'" + teacherPermanentAddress + "', "
                + "'" + teacherPassword + "')";

        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex);
            // JOptionPane.showMessageDialog(null, "Data already exist(FGT)"); 

            return false;
        }

    }

    public boolean insertStudentUploadInfo(int studentUserId, String studentSession, String studentSemester, String studentClassRoll, String studentRegNo, String studentExamRoll, String studentName, String studentFatherName, String studentMotherName, String studentHall, String studentSex, String studentEmailId, String studentContactNo, String studentPresentAddress, String studentPermanentAddress,String studentPassword) {
       String sql=" INSERT INTO `rpsdbms`.`student` (`studentUserId`, `studentSession`, `studentSemester`, `studentClassRoll`, `studentRegNo`, `studentExamRoll`, `studentName`, `studentFatherName`, `studentMotherName`, `studentHall`, `studentSex`, `studentEmailId`, `studentContactNo`, `studentPresentAddress`, `studentPermanentAddress`, `studentPassword`) VALUES ("
               + "'"+studentUserId+"', "
               + "'"+studentSession+"', "
               + "'"+studentSemester+"', "
               + "'"+studentClassRoll+"', "
               + "'"+studentRegNo+"', "
               + "'"+studentExamRoll+"', "
               + "'"+studentName+"', "
               + "'"+studentFatherName+"', "
               + "'"+studentMotherName+"', "
               + "'"+studentHall+"', "
               + "'"+studentSex+"', "
               + "'"+studentEmailId+"', "
               + "'"+studentContactNo+"', "
               + "'"+studentPresentAddress+"', "
               + "'"+studentPermanentAddress+"', "
               + "'"+studentPassword+"')";
   
         Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex);
            // JOptionPane.showMessageDialog(null, "Data already exist(FGT)"); 

            return false;
        }
    
    }

    public boolean insertAdminUploadInfo(String adminId,String adminTeacherId, String adminPassword) {
      
        String sql="INSERT INTO `rpsdbms`.`admin` (`adminId`, `adminTeacherId`, `adminPassword`) VALUES ("
               + "'"+adminId+"', "  
               + "'"+adminTeacherId+"', "
               + "'"+adminPassword+"')"; 
       
         Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex);
            // JOptionPane.showMessageDialog(null, "Data already exist(FGT)"); 

            return false;
        }
       
    }

    public boolean insertSemesterUploadInfo(String semesterNo, String semesterName, String semesterCredit) {
       String sql="INSERT INTO `rpsdbms`.`semester` (`semesterNo`, `semesterName`, `semesterCredit`) VALUES ("
               + "'"+semesterNo+"', "
               + "'"+semesterName+"', "
               + "'"+semesterCredit+"')"; 
       
        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex);
            // JOptionPane.showMessageDialog(null, "Data already exist(FGT)"); 

            return false;
        }
    }

    public boolean insertCourseUploadInfo(String courseId, String courseName, String courseCredit, String semesterNo, String courseType) {
           String sql="INSERT INTO `rpsdbms`.`course` (`courseId` ,`courseName` ,`courseCredit` ,`semesterNo` ,`courseType`) VALUES ("
                   + "'"+courseId+"', "
                   + "'"+courseName+"', "
                   + "'"+courseCredit+"', "
                   + "'"+semesterNo+"', "
                   + "'"+courseType+"')";
       
        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex);
            // JOptionPane.showMessageDialog(null, "Data already exist(FGT)"); 

            return false;
        }
    }

    public boolean insertTeacherYearUploadInfo(String teacherId, String year) {
        
        String sql=" INSERT INTO `rpsdbms`.`yearselection` (`teacherId` ,`Year`)VALUES "
                + "('"+teacherId+"', "
                + "'"+year+"')"; 
        
         Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex);
            // JOptionPane.showMessageDialog(null, "Data already exist(FGT)"); 

            return false;
        }
    }

    public boolean insertAdminSessionUploadInfo(String adminId, String adminSession, String semesterNo, String status, String adminAssignYear) {
       // throw new UnsupportedOperationException("Not yet implemented");
        String sql="INSERT INTO `rpsdbms`.`adminsession` (`adminId` ,`adminSession` ,`semesterNo` ,`status` ,`adminAssignYear`)VALUES ("
                +"'"+adminId+"', "
                + "'"+adminSession+"', "
                + "'"+semesterNo+"', "
                + "'"+status+"', "
                + "'"+adminAssignYear+"'"
         +")";
          
           Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex);
            // JOptionPane.showMessageDialog(null, "Data already exist(FGT)"); 

            return false;
        }
        
    }

    public boolean insertTheoryGeneratedKeyUploadInfo(String assignTeacherId, String courseId, String assignYear, String semesterNo) {
      
        
        String sql="INSERT INTO `rpsdbms`.`keygeneratedassignmenttable` (`assignTeacherId`, `courseId`, `assignYear`, `semesterNo`) VALUES ("
                + "'"+assignTeacherId+"', "
                + "'"+courseId+"', "
                + "'"+assignYear+"', "
                + "'"+semesterNo+"');";
        
        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex);
            // JOptionPane.showMessageDialog(null, "Data already exist(FGT)"); 

            return false;
        }
    }

   
    public boolean insertLabGeneratedKeyUploadInfo(String assignTeacherId, String courseId, String assignYear, String semesterNo) {
      
        
        String sql="INSERT INTO `rpsdbms`.`labkeygeneratedassignmenttable` (`assignTeacherId`, `courseId`, `assignYear`, `semesterNo`) VALUES ("
                + "'"+assignTeacherId+"', "
                + "'"+courseId+"', "
                + "'"+assignYear+"', "
                + "'"+semesterNo+"');";
        
        Statement statement;
        try {
            statement = connectionObj.createStatement();
            statement.executeUpdate(sql);
            System.out.println("statement :" + sql);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseInsertion.class.getName()).log(Level.SEVERE, null, ex);
            // JOptionPane.showMessageDialog(null, "Data already exist(FGT)"); 

            return false;
        }
    }
   
}
