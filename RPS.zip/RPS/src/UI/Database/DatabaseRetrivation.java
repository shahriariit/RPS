/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package UI.Database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author SHAHRIAR
 */
public class DatabaseRetrivation {
    
    static Connection connectionObj=null;
    
    public DatabaseRetrivation(Connection connectionObj){
        this.connectionObj=connectionObj;
        
    }
    
     public ResultSet semesterNameByAdminId(String identification,String semesterNo)
      {
            Statement stmt = null;
            ResultSet resultSetObj = null;
        try {
            
            String sql = "select a.semesterName from semester a natural join adminSession b where b.adminId = '" + identification + "' and b.semesterNo='"+semesterNo+"'";
            System.out.println(sql);
            stmt = connectionObj.prepareStatement(sql);
            System.out.println(stmt);
            resultSetObj = stmt.executeQuery(sql);
            System.out.println("ER-01"+resultSetObj );
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      }
     
     
   public ResultSet theoryCourseIdBySemester(String semester)
      {
            Statement stmt = null;
            ResultSet resultSetObj = null;
            System.out.println(semester);
        try {
           
            String studentSessionquery = "select distinct courseId,courseName from course where semesterNo = '" + semester + "' and courseType='theory'";
            System.out.println(studentSessionquery);

            stmt = connectionObj.prepareStatement(studentSessionquery);
            System.out.println(stmt);
            resultSetObj = stmt.executeQuery(studentSessionquery);
            System.out.println(resultSetObj);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
     }
   
    public ResultSet labCourseIdBySemester(String semester)
      {
            Statement stmt = null;
            ResultSet resultSetObj = null;
            System.out.println(semester);
        try {
           
            String studentSessionquery = "select distinct courseId,courseName from course where semesterNo = '" + semester + "' and courseType='lab'";
            System.out.println(studentSessionquery);

            stmt = connectionObj.prepareStatement(studentSessionquery);
            System.out.println(stmt);
            resultSetObj = stmt.executeQuery(studentSessionquery);
            System.out.println(resultSetObj);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      }
    
     public ResultSet otherCourseIdBySemester(String semester)
      {
            Statement stmt = null;
            ResultSet resultSetObj = null;
            System.out.println(semester);
        try {
           
            String studentSessionquery = "select distinct courseId,courseName from course where semesterNo = '" + semester + "' and courseType='viva'";
            System.out.println(studentSessionquery);

            stmt = connectionObj.prepareStatement(studentSessionquery);
            System.out.println(stmt);
            resultSetObj = stmt.executeQuery(studentSessionquery);
            System.out.println(resultSetObj);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      }
   
    public ResultSet teacherTableInfo(String identification)
      {
            Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
            String studentSessionquery = "select distinct teacherId,teacherName from teacher ";

            statementObj = connectionObj.prepareStatement(studentSessionquery);
            resultSetObj = statementObj.executeQuery(studentSessionquery);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      }
       
     
   /* public ResultSet semesterNameByAdminId(String identification)
      {
            Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
              
            String studentSessionquery = "select distinct semesterName from admin where adminId = '" + identification + "'";

            statementObj = connectionObj.prepareStatement(studentSessionquery);
            resultSetObj = statementObj.executeQuery(studentSessionquery);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      }*/
     
     
      public ResultSet sessionBySesmester(String semester)
      {
            Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
            String studentSessionquery = "select distinct studentSession from student where studentSemester = '" + semester + "'"; 
            statementObj = connectionObj.prepareStatement(studentSessionquery);
            resultSetObj = statementObj.executeQuery(studentSessionquery);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      }
      
       public ResultSet getTeacherId()
      {
            Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
          
            String studentSessionquery = "select distinct teacherId from teacher ";
            statementObj = connectionObj.prepareStatement(studentSessionquery);
            resultSetObj = statementObj.executeQuery(studentSessionquery);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      }
    
       
    public ResultSet classExamRollSessionBySemester(String semester)
      {
            Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
            String sql = "SELECT studentClassRoll,studentExamRoll,studentSession FROM student where studentSemester = '" +semester+"'";
            System.out.println("Student sql :"+sql);  
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      }
       
      public ResultSet adminByAdminId(String identification)
      {
            Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
            String sql = "select * from admin where adminId = '"+identification+"'";
            System.out.println("Error:"+identification);
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      } 
      
      
      
       public ResultSet teacherByTeacherId(String identification)
      {
            Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
           String sql = "select * from teacher where teacherId = '"+identification+"'";
            System.out.println("Error:"+identification);
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      } 
      
      
       public ResultSet studentByStudentId(String identification)
      {
            Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
            String sql = "select * from student where studentIdentification = '" + identification + "'";
            System.out.println("Error:"+identification);
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      } 
      
     
      
     public ResultSet courseIdByFirstTeacherId(String identification)
      {
            Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
             String sql = "select courseId from course where firstteacherId = '" + identification + "'";
            System.out.println("Error1:"+identification);
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      } 
     
   public ResultSet courseIdBySecondTeacherId(String identification)
      {
            Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
            String sql = "select courseId from course where secondteacherId = '" + identification + "'";
            System.out.println("Error2:"+identification);
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      } 
   
    public ResultSet semesterNameBycourseId(String toString)
      {
            Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
              
            String studentSessionquery = "select semesterName from course where courseId = '"+toString+"'";
            System.out.println("courseId :"+studentSessionquery);
            statementObj = connectionObj.prepareStatement(studentSessionquery);
            resultSetObj = statementObj.executeQuery(studentSessionquery);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      }
   
     public ResultSet teacherNameByteacherId(String teacherIdentification)
      {
            Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
              
            String studentSessionquery = "select teacherName from teacher where teacherId = '"+teacherIdentification+"'";
            System.out.println(studentSessionquery);
            statementObj = connectionObj.prepareStatement(studentSessionquery);
            resultSetObj = statementObj.executeQuery(studentSessionquery);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      }
     
       public ResultSet teacherNameteacherDesignationByteacherId(String identification) {
           Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
              
            String studentSessionquery = "select teacherName,teacherDesignation from teacher where teacherId = '"+identification+"'";
            System.out.println(studentSessionquery);
            statementObj = connectionObj.prepareStatement(studentSessionquery);
            resultSetObj = statementObj.executeQuery(studentSessionquery);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      }
     
       public ResultSet adminNameDesignationByadminId(String adminId) {
            Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
              
            String studentSessionquery = "select a.teacherName,a.teacherDesignation from teacher a inner join admin b where b.adminId = '"+adminId+"' and a.teacherId=b.adminTeacherId";
            System.out.println(studentSessionquery);
            
            statementObj = connectionObj.prepareStatement(studentSessionquery);
            resultSetObj = statementObj.executeQuery(studentSessionquery);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
    }
     
    public ResultSet classExamRollBySemester(String semester)
      {
            Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
           
            String sql = "SELECT studentClassRoll,studentExamRoll FROM student where studentSemester = '" +semester+"'";
            System.out.println("Student sql :"+sql);  
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      } 
     
     
    public ResultSet firstSecondTeacherIdBycourseId(String toString)
      {
            Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
           
            String sql = "select firstteacherId,secondteacherId from course where courseId = '" + toString + "'";
            System.out.println("Student sql :"+sql);  
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
      }

    public ResultSet courseIdByThirdTeacherId(String identification) {
            Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
            String sql = "select courseId from thirdexaminertable where teacherId = '" + identification + "'";
            System.out.println("Error2:"+identification);
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
    }

    public ResultSet examRollByCourseIdSessionSemester(String text, String courseId, String session, String semester) {
          Statement statementObj = null;
          ResultSet resultSetObj = null;
          
        try {
            String sql = "select studentExamRoll from thirdexaminertable where teacherId = '" + text + 
                    "' and courseId ='"+courseId+
                    "' and studentSession ='"+session+"' and studentSemester ='"+semester+"'";
            
            System.out.println("query:"+sql);
            statementObj = connectionObj.prepareStatement(sql);
            System.out.println("statement:"+ statementObj);
            resultSetObj = statementObj.executeQuery(sql);
            System.out.println("resultSet:"+ resultSetObj);
            return resultSetObj;
            
            } 
         catch (SQLException ex) {
             return resultSetObj; 
        }   
    }

  
   public ResultSet courseIdSemesterNameByFirstTeacherId(String identification) {
         Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
             String sql = "select courseId,semesterName from course where firstteacherId = '" + identification + "'";
            System.out.println("Error1:"+identification);
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
    }

  
    public ResultSet sessionByAdminId(String identification) {
            Statement statementObj = null;
            ResultSet resultSetObj = null;
        try {
          
            String studentSessionquery = "select distinct studentSession from gradeTable where adminId = '"+identification+"'";
            statementObj = connectionObj.prepareStatement(studentSessionquery);
            resultSetObj = statementObj.executeQuery(studentSessionquery);
            return resultSetObj;
            } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
    }

    public ResultSet courseIdBySessionAdminId(String toString, String identification) {
          Statement statementObj = null;
          ResultSet resultSetObj = null;
        try {
          
            String sql = "select distinct courseId from gradetable where studentSession = '"+toString+"' and adminId = '"+identification+"'";
            System.out.println(sql);
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
    }

    public ResultSet semesterBySessionAdminId(String session, String Identification) {
          Statement statementObj = null;
          ResultSet resultSetObj = null;
        try {
          
            String sql = "select distinct studentSemester from gradetable where studentSession = '"+session+"' and adminId = '"+Identification+"'";
            System.out.println(sql);
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
    }

    public ResultSet studentInfoBySessionSemesterCourseId(String toString, String toString0, String toString1) {
          Statement statementObj = null;
          ResultSet resultSetObj = null;
        try {
          
           String sql = "SELECT studentClassRoll,studentExamRoll,finalMarks,tutorialMarks,total,gpa FROM gradetable where studentSession = '" +toString 
                         + "' and studentSemester = '"+toString0
                         +" ' and courseId = '"+toString1
                         +" ' ";
           
           
            System.out.println(sql);
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }   
    }

    public ResultSet examRollBySemesterAdminId(String toString, String identification) {
          Statement statementObj = null;
          ResultSet resultSetObj = null;
        try {
          
            String sql = "select distinct studentExamRoll from gradetable where studentSemester = '"+toString+"' and adminId = '"+identification+"'";
            System.out.println(sql);
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }  
    }

   

    public ResultSet transcriptBySessionSemesterExamRoll(String session, String semester, String examRoll) {
          Statement statementObj = null;
          ResultSet resultSetObj = null;
        try {
          
            String sql = "select distinct courseId,total,gpa from gradetable where studentSession = '"+session+"' and studentSemester = '"+semester+"' and studentExamRoll = '"+examRoll+"'";
            System.out.println(sql);
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }  
    }

    public ResultSet namerollBySessionSemesterExamroll(String session, String semester, String examRoll) {
          Statement statementObj = null;
          ResultSet resultSetObj = null;
        try {
          
            String sql = "select distinct studentName,studentClassRoll from student where studentSession = '"+session+"' and studentSemester = '"+semester+"' and studentExamRoll = '"+examRoll+"'";
            System.out.println(sql);
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }  
    }

   
    
    public ResultSet courseNameByCourseId(String courseId) {
        Statement statementObj = null;
        ResultSet resultSetObj = null;
        try {
          
            String sql = "select courseName from course where courseId = '"+courseId+"'";
            System.out.println(sql);
            
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }  
    }

    public ResultSet studentSessionFromStudentTable() {
        Statement statementObj = null;
        ResultSet resultSetObj = null;
        try {
          
            String sql = "select distinct studentSession from student";
            System.out.println(sql);
            
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }  
    }

    public ResultSet studentClassRollFromStudentTable(String session) {
        Statement statementObj = null;
        ResultSet resultSetObj = null;
        try {
          
            String sql = "select distinct studentClassRoll from student where studentSession = '"+session+"'";
            System.out.println(sql);
            
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }  
    }

    public ResultSet getCourseIdNameYear(String semester, Object selectedItem) {
       Statement statementObj = null;
       ResultSet resultSetObj = null;
        try {
          
            String sql="select a.courseId,c.courseName,a.assignYear from keygeneratedassignmenttable a natural join course c where a.semesterNo='"+semester+"' and assignTeacherId='"+selectedItem+"'";
            System.out.println(sql);
            
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }  
    }
    
     public ResultSet getLabCourseIdNameYear(String semester, Object selectedItem) {
       Statement statementObj = null;
       ResultSet resultSetObj = null;
        try {
          
            String sql="select a.courseId,c.courseName,a.assignYear from labkeygeneratedassignmenttable a natural join course c where a.semesterNo='"+semester+"' and assignTeacherId='"+selectedItem+"'";
            System.out.println(sql);
            
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }  
    }

    public ResultSet teacherIdFromTeacherName(Object selectedItem) {
       Statement statementObj = null;
       ResultSet resultSetObj = null;
        try {
          
             String sql="select teacherId from teacher where teacherName='"+selectedItem+"'";
            System.out.println(sql);
            
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }  
    }

    public ResultSet loadAssignTeacherYear(String identification) {
        Statement statementObj = null;
       ResultSet resultSetObj = null;
        try {
          
            String sql="select Year from yearselection where teacherId='"+identification+"'"; 
            System.out.println(sql);
            
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }  
    }
    
    public ResultSet loadOtherAssignTeacherYear(String identification) {
        Statement statementObj = null;
       ResultSet resultSetObj = null;
        try {
          
            String sql="select adminAssignYear from adminsession where adminId='"+identification+"'"; 
            System.out.println(sql);
            
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }  
    }

    public ResultSet loadFirstExaminerIdCourseIdCourseNameStudentSemesterStudentSession(String identification, String assignYear) {
       Statement statementObj = null;
       ResultSet resultSetObj = null;
        try {
          
            String sql = "select a.assignFirstExaminerId,a.courseId,b.courseName,a.studentSemester,a.studentSession from coursefirstexaminerassigntable a natural join course b where teacherId = '" + identification + "' and teacherAssignYear='"+assignYear+"'";
            System.out.println(sql);
            
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }  
    }

    public ResultSet loadSecondExaminerIdCourseIdCourseNameStudentSemesterStudentSession(String identification, String assignYear) {
       Statement statementObj = null;
       ResultSet resultSetObj = null;
        try {
          
            String sql = "select a.assignSecondExaminerId,a.courseId,b.courseName,a.studentSemester,a.studentSession from coursesecondexaminerassigntable a natural join course b where teacherId = '" + identification + "' and teacherAssignYear='"+assignYear+"'";
            System.out.println(sql);
            
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }  
    }
    
    
    public ResultSet loadThirdExaminerIdCourseIdCourseNameStudentSemesterStudentSession(String identification, String assignYear) {
         Statement statementObj = null;
       ResultSet resultSetObj = null;
        try {
          
            String sql = "select a.assignThirdExaminerId,a.courseId,b.courseName,a.studentSemester,a.studentSession from coursethirdexaminerassigntable a natural join course b where teacherId = '" + identification + "' and teacherAssignYear='"+assignYear+"'";
            System.out.println(sql);
            
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }  
    }


    public ResultSet loadLabExaminerIdCourseIdCourseNameStudentSemesterStudentSession(String identification, String assignYear) {
         Statement statementObj = null;
       ResultSet resultSetObj = null;
        try {
          
            String sql = "select a.assignlabExaminerId,a.courseId,b.courseName,a.studentSemester,a.studentSession from labcourseexaminerassigntable a natural join course b where teacherId = '" + identification + "' and teacherAssignYear='"+assignYear+"'";
            System.out.println(sql);
            
            statementObj = connectionObj.prepareStatement(sql);
            resultSetObj = statementObj.executeQuery(sql);
            return resultSetObj;
            
         } 
         catch (SQLException ex) {
          return resultSetObj; 
        }  
    }

  

  

 
}
