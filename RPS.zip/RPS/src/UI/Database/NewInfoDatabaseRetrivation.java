/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package UI.Database;

import java.sql.*;

/**
 *
 * @author SHAHRIAR
 */
public class NewInfoDatabaseRetrivation {

    static Connection connectionObj = null;

    public NewInfoDatabaseRetrivation(Connection connectionObj) {
        this.connectionObj = connectionObj;

    }

    public ResultSet loadAdminTableInfo() {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {

            String SQL = "SELECT adminId,adminName,adminEmailId,semesterName FROM admin";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(SQL);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadTeacherIdTableInfo() {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {

            String SQL = "SELECT teacherId FROM teacher";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(SQL);

            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadTeacherTableInfo() {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {

            String SQL = "SELECT teacherId,teacherName,teacherEmailId FROM teacher";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(SQL);

            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadThirdExaminerIdTableInfo(String FirstExaminerId, String SecondExaminerId) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {

            String SQL = "SELECT teacherId FROM teacher where teacherId not like '" + FirstExaminerId + "' and teacherId not like '" + SecondExaminerId + "'";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(SQL);

            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadStudentTableInfo() {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "SELECT studentClassRoll,studentExamRoll,studentName,studentEmailId,studentSession,studentSemester FROM student";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadCourseTableInfo() {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {

            String query = "SELECT courseId ,courseName,courseCredit,semesterName,courseType FROM course";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(query);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadSemesterTableInfo() {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {

            String SQL = "SELECT semesterName, semesterCredit FROM semester";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(SQL);

            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadLabExaminedSheet(String resultIdentification) {

        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "SELECT studentExamRoll,experiment,viva,total FROM labexaminedsheet where labfinalExaminedId='" + resultIdentification + "'";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadOtherExaminedSheet(String resultIdentification) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "SELECT studentExamRoll,ProjectWork,viva,total,GPA,LetterGrade FROM vivaexaminedsheet where vivaExaminedId='" + resultIdentification + "'";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadTheoryGradeExaminedSheet(String identification, String studentSession, String semesterNo, String courseId) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            // String sql = "SELECT studentExamRoll,firstExaminerMarks,secondExaminerMarks,differences,averages,finalMarks,tutorialMarks,total,GPA,LetterGrade FROM theorygradeexaminedsheet where theoryGradeExaminedId='"+resultIdentification+"'";
            String sql = "SELECT studentExamRoll, firstExaminerMarks, secondExaminerMarks, differences, averages, finalMarks, tutorialMarks, total, GPA, LetterGrade FROM theorygradeexaminedsheet WHERE `adminId` = '" + identification + "' AND `studentSession` = '" + studentSession + "' AND semesterNo = '" + semesterNo + "' AND courseId = '" + courseId + "' AND status='OK'";

            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadTempTheoryGradeExaminedSheet(String identification, String semesterNo, String studentSession, String courseId) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "SELECT studentExamRoll,firstExaminerMarks,secondExaminerMarks,tutorialMarks FROM temptheorygradeexaminedsheet where adminId='" + identification + "' and studentSession='" + studentSession + "' and semesterNo='" + semesterNo + "' and courseId='" + courseId + "'";
            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadTempLabGradeExaminedSheet(String identification, String semesterNo, String studentSession, String courseId) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "SELECT studentExamRoll,LabClassTest,LabFinalExam FROM templabgradeexaminedsheet where adminId='" + identification + "' and studentSession='" + studentSession + "' and semesterNo='" + semesterNo + "' and courseId='" + courseId + "'";
            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadErrorousTheoryGradeExaminedSheet(String identification, String studentSession, String semesterNo, String courseId) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            // String sql = "SELECT studentExamRoll,firstExaminerMarks,secondExaminerMarks,differences,averages,finalMarks,tutorialMarks,total,GPA,LetterGrade FROM theorygradeexaminedsheet where theoryGradeExaminedId='"+resultIdentification+"'";
            String sql = "SELECT studentExamRoll, firstExaminerMarks,secondExaminerMarks,thirdExaminerMarks,differences, averages, finalMarks, tutorialMarks, total, GPA, LetterGrade FROM theorygradeexaminedsheet WHERE `adminId` = '" + identification + "' AND `studentSession` = '" + studentSession + "' AND semesterNo = '" + semesterNo + "' AND courseId = '" + courseId + "' AND status='Error'";

            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadLabGradeExaminedSheet(String resultIdentification) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "SELECT studentExamRoll,labClassTest,labFinalExam,total,GPA,LetterGrade FROM labgradeexaminedsheet where labGradeExaminedId='" + resultIdentification + "'";
            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadClasstestSheet(String resultIdentification) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "SELECT studentClassRoll,studentExamRoll,classTestOne,classTestTwo,classTestThree,classTestFinal,classAssignment,classAttendance,classPresentation,total  FROM classperformancetable where classTestId='" + resultIdentification + "'";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadLabClasstestSheet(String resultIdentification) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "SELECT studentClassRoll,studentExamRoll,classTestOne,classTestTwo,classTestThree,classTestFinal,classLabReport,classAssignment,classAttendance,classPresentation,total  FROM labclassperformancetable where labClassTestId='" + resultIdentification + "'";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadAssignTeacherTable(String session, String semester, String courseType) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "SELECT courseId,teacherId  FROM coursefirstexaminerassigntable where studentSession='" + session + "' and studentSemester='" + semester + "' and courseType='" + courseType + "'";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadAssignTeacherTwoTable(String session, String semester, String courseType) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "SELECT courseId,teacherId  FROM coursesecondexaminerassigntable where studentSession='" + session + "' and studentSemester='" + semester + "' and courseType='" + courseType + "'";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadAssignThirdExaminerTable(String session, String semester, String courseType) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "SELECT courseId,teacherId  FROM coursethirdexaminerassigntable where studentSession='" + session + "' and studentSemester='" + semester + "' and courseType='" + courseType + "'";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet getAssignTeacherIdTable(String semester) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "select assignTeacherId,assignYear from keygeneratedassignmenttable where semesterNo='" + semester + "'";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet getFirstTeacherIdNameTableByCourseIdSemesterSession(String courseId, String semester, String session) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "select b.teacherId,a.teacherName from teacher a inner join coursefirstexaminerassigntable b where b.courseId='" + courseId + "' and b.studentSession='" + session + "' and b.studentSemester='" + semester + "' and a.teacherId=b.teacherId";
            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet getSecondTeacherIdNameTableByCourseIdSemesterSession(String courseId, String semester, String session) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "select b.teacherId,a.teacherName from teacher a inner join coursesecondexaminerassigntable b where b.courseId='" + courseId + "' and b.studentSession='" + session + "' and b.studentSemester='" + semester + "' and a.teacherId=b.teacherId";
            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    } 
    
    public ResultSet getThirdTeacherIdNameTableByCourseIdSemesterSession(String courseId, String semester, String session) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "select b.teacherId,a.teacherName from teacher a inner join coursethirdexaminerassigntable b where b.courseId='" + courseId + "' and b.studentSession='" + session + "' and b.studentSemester='" + semester + "' and a.teacherId=b.teacherId";
            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    } 
    
     public ResultSet getLabCourseTeacherIdNameTableByCourseIdSemesterSession(String courseId, String semester, String session) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "select b.teacherId,a.teacherName from teacher a inner join labcourseexaminerassigntable b where b.courseId='" + courseId + "' and b.studentSession='" + session + "' and b.studentSemester='" + semester + "' and a.teacherId=b.teacherId";
            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    } 
    
    public ResultSet getAssignTeacherIdTableBySemesterCourseId(String semester, String courseId) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "select assignTeacherId,assignYear from keygeneratedassignmenttable where semesterNo='" + semester + "' and courseId='" + courseId + "'";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadLabAssignTeacherTable(String session, String semester, String courseType) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "SELECT courseId,teacherId  FROM labcourseexaminerassigntable where studentSession='" + session + "' and studentSemester='" + semester + "' and courseType='" + courseType + "'";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet getLabAssignTeacherIdTable(String semester) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "select assignTeacherId,assignYear from labkeygeneratedassignmenttable where semesterNo='" + semester + "'";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadFirstExaminedSheet(String resultIdentification) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "SELECT studentExamRoll,one,two,three,four,five,six,seven,eight,total FROM firstexaminedsheet where firstExaminedId='" + resultIdentification + "'";
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadSecondExaminedSheet(String resultIdentification) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "SELECT studentExamRoll,one,two,three,four,five,six,seven,eight,total FROM secondexaminedsheet where secondExaminedId='" + resultIdentification + "'";
            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadThirdExaminedSheet(String resultIdentification) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            String sql = "SELECT studentExamRoll,one,two,three,four,five,six,seven,eight,total FROM thirdexaminedsheet where thirdExaminedId='" + resultIdentification + "'";
            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    
    public ResultSet loadFinalExaminedSheet(String identification, String studentSession, String semesterNo) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
             String sql = "SELECT studentExamRoll,Subject1Examiner1,Subject1Examiner2,Subject1Examiner3,Subject1Average,Subject1Tutorial,Subject1Total,"
            + "                          Subject2Examiner1,Subject2Examiner2,Subject2Examiner3,Subject2Average,Subject2Tutorial,Subject2Total,"
            + "                          Subject3Examiner1,Subject3Examiner2,Subject3Examiner3,Subject3Average,Subject3Tutorial,Subject3Total,"
            + "                          Subject4Examiner1,Subject4Examiner2,Subject4Examiner3,Subject4Average,Subject4Tutorial,Subject4Total,"
            + "                          Subject5Examiner1,Subject5Examiner2,Subject5Examiner3,Subject5Average,Subject5Tutorial,Subject5Total,"
            + "                          Subject6Examiner1,Subject6Examiner2,Subject6Examiner3,Subject6Average,Subject6Tutorial,Subject6Total,"
            + "                          Subject7Examiner1,Subject7Examiner2,Subject7Examiner3,Subject7Average,Subject7Tutorial,Subject7Total,"
            + "                          Subject8Examiner1,Subject8Examiner2,Subject8Examiner3,Subject8Average,Subject8Tutorial,Subject8Total,"
            + "                          Subject9Examiner1,Subject9Examiner2,Subject9Examiner3,Subject9Average,Subject9Tutorial,Subject9Total,"
            + "                          Subject10Examiner1,Subject10Examiner2,Subject10Examiner3,Subject10Average,Subject10Tutorial,Subject10Total FROM finalgradesheet where adminId='"+identification+"' and adminSession='"+studentSession+"' and semesterNo='"+semesterNo+"'";



           /* String sql = "SELECT studentExamRoll, "
                    + "Subject1Examiner1, Subject1Examiner2, Subject1Examiner3, Subject1Average, Subject1Tutorial, Subject1Total,Subject1GPA"
                    + "Subject2Examiner1, Subject2Examiner2, Subject2Examiner3, Subject2Average, Subject2Tutorial, Subject2Total,Subject2GPA"
                    + "Subject3Examiner1, Subject3Examiner2, Subject3Examiner3, Subject3Average, Subject3Tutorial, Subject3Total,Subject3GPA"
                    + "Subject6Examiner1, Subject6Examiner2, Subject6Examiner3, Subject6Average, Subject6Tutorial, Subject6Total,Subject6GPA FROM finalgradesheet where adminId='" + identification + "' and studentSession='" + studentSession + "' and semesterNo='" + semesterNo + "'";*/


            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    
    
    public ResultSet loadFourYear2ndSemesterExaminedSheet(String identification, String studentSession, String semesterNo) {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {
            /* String sql = "SELECT studentExamRoll,Subject1Examiner1,Subject1Examiner2,Subject1Examiner3,Subject1Average,Subject1Tutorial,Subject1Total,"
            + "                          Subject2Examiner1,Subject2Examiner2,Subject2Examiner3,Subject2Average,Subject2Tutorial,Subject2Total,"
            + "                          Subject3Examiner1,Subject3Examiner2,Subject3Examiner3,Subject3Average,Subject3Tutorial,Subject3Total,"
            + "                          Subject4Examiner1,Subject4Examiner2,Subject4Examiner3,Subject4Average,Subject4Tutorial,Subject4Total,"
            + "                          Subject5Examiner1,Subject5Examiner2,Subject5Examiner3,Subject5Average,Subject5Tutorial,Subject5Total,"
            + "                          Subject6Examiner1,Subject6Examiner2,Subject6Examiner3,Subject6Average,Subject6Tutorial,Subject6Total,"
            + "                          Subject7Examiner1,Subject7Examiner2,Subject7Examiner3,Subject7Average,Subject7Tutorial,Subject7Total,"
            + "                          Subject8Examiner1,Subject8Examiner2,Subject8Examiner3,Subject8Average,Subject8Tutorial,Subject8Total,"
            + "                          Subject9Examiner1,Subject9Examiner2,Subject9Examiner3,Subject9Average,Subject9Tutorial,Subject9Total,"
            + "                          Subject10Examiner1,Subject10Examiner2,Subject10Examiner3,Subject10Average,Subject10Tutorial,Subject10Total FROM finalgradesheet where adminId='"+identification+"' and adminSession='"+studentSession+"' and semesterNo='"+semesterNo+"'";*/



            String sql = "SELECT studentExamRoll, "
                    + "Subject1Examiner1, Subject1Examiner2, Subject1Examiner3, Subject1Average, Subject1Tutorial, Subject1Total,Subject1GPA,"
                    + "Subject2Examiner1, Subject2Examiner2, Subject2Examiner3, Subject2Average, Subject2Tutorial, Subject2Total,Subject2GPA,"
                    + "Subject3Examiner1, Subject3Examiner2, Subject3Examiner3, Subject3Average, Subject3Tutorial, Subject3Total,Subject3GPA,"
                    + "Subject6Examiner1, Subject6Examiner2, Subject6Examiner3, Subject6Average, Subject6Tutorial, Subject6Total,Subject6GPA ,"
                    + "Subject8Tutorial, Subject8LabFinal,Subject8Total,Subject8GPA, "
                    + "Subject9Tutorial, Subject9LabFinal,Subject9Total,Subject9GPA,  "
                    + "Subject14Project, Subject14Viva,Subject14Total,Subject14GPA,TotalCGPA FROM finalgradesheet where adminId='" + identification + "' and studentSession='" + studentSession + "' and semesterNo='" + semesterNo + "'";


            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadTempTheoryTableUploadSheet() {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {

            String sql = "SELECT * FROM `temptheorygradeexaminedsheet`";

            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadTempLabTableUploadSheet() {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {

            String sql = "SELECT * FROM `templabgradeexaminedsheet`";

            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }


    }

    public ResultSet loadTeacherUploadSheet() {
      Statement stmt = null;
        ResultSet resultSetObj = null;
        try {


            String sql = "SELECT * FROM `teacher`";

            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }

    }

    public ResultSet loadStudentUploadSheet() {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {


            String sql = "SELECT * FROM `student`";

            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadAdminUploadSheet() {
       Statement stmt = null;
        ResultSet resultSetObj = null;
        try {


            String sql = "SELECT * FROM `admin`";

            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadSemesterUploadSheet() {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {


            String sql = "SELECT * FROM `semester`";

            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadCourseUploadSheet() {
       Statement stmt = null;
        ResultSet resultSetObj = null;
        try {


            String sql = "SELECT * FROM `course`";

            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadTeacherYearUploadSheet() {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {


            String sql = "SELECT * FROM `yearselection`";

            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadAdminSessionUploadSheet() {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {


            String sql = "SELECT * FROM `adminSession`";

            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadTheoryKeyGeneratedUploadSheet() {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {

            String sql = "SELECT * FROM `keygeneratedassignmenttable`";

            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }

    public ResultSet loadLabKeyGeneratedUploadSheet() {
        Statement stmt = null;
        ResultSet resultSetObj = null;
        try {

            String sql = "SELECT * FROM `labkeygeneratedassignmenttable`";

            System.out.println(sql);
            stmt = connectionObj.createStatement();
            resultSetObj = stmt.executeQuery(sql);
            return resultSetObj;
        } catch (SQLException ex) {
            return resultSetObj;
        }
    }
}
