/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * AssignLabCoursePanel.java
 *
 * Created on Oct 4, 2013, 3:07:47 AM
 */
package UI.Panel;

import Database.DatabaseConnection;
import UI.Database.DatabaseInsertion;
import UI.Database.DatabaseRetrivation;
import UI.Database.NewInfoDatabaseRetrivation;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author SHAHRIAR
 */
public class AssignLabCourseTeacherPanel extends javax.swing.JPanel {

    /** Creates new form AssignLabCoursePanel */
    String session,semester,courseteacherid,adminId;
    static DefaultTableModel tablemodel = null;
    String courseId[]=new String[500];
    String teacherId[] = new String[500];
    String teacherName[]= new String[500];
    String courseName[]= new String[500];
    JLabel courseIdlabel[]=new JLabel[100];
    JLabel courseNamelabel[]=new JLabel[100];
    JComboBox firstExaminercombobox[]=new JComboBox[100];
    int courseCount,teacherCount,rowCount,rowCount1;
    String[][] existingTeachers= new String[500][10];
    String[][] clonedExistingTeachers = new String[500][10];
    String labTeacherId,assignYear;
    String courseType="lab";
    boolean labExaminerResult;
    
    public AssignLabCourseTeacherPanel(String session,String semester,String adminId) {
        
            this.session=session;
            this.semester=semester;
           
            initComponents();
            
            try{
            
            studentSessionTextField.setText(session);
            try {

                    Connection connectionObj = DatabaseConnection.getConnectionObject();
                    DatabaseRetrivation obj = new DatabaseRetrivation(connectionObj);
                    ResultSet resultSetObj = obj.semesterNameByAdminId(adminId, semester);

                    while (resultSetObj.next()) {
                        studentSemesterTextField.setText(resultSetObj.getString("a.semesterName"));
                    }

                } catch (SQLException ex) {
                    Logger.getLogger(GradeSheetAccessPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
           
            
            Connection conn = DatabaseConnection.getConnectionObject();
            NewInfoDatabaseRetrivation assignTeacherobj=new NewInfoDatabaseRetrivation(conn);
            ResultSet rs=assignTeacherobj.getLabAssignTeacherIdTable(semester);

            while (rs.next()) {
                assignIdComboBox.addItem(rs.getString("assignTeacherId"));
                assignYear=rs.getString("assignYear");
            }
            
                       
            NewInfoDatabaseRetrivation obj=new NewInfoDatabaseRetrivation(conn);
            ResultSet teacherrs=obj.loadTeacherIdTableInfo();

            while (teacherrs.next()) {
            
                teacherId[rowCount] = teacherrs.getString("teacherId");
                System.out.println(teacherId[rowCount]);
                rowCount++;
            }

            System.out.println(rowCount);

            for (int i = 0; i < rowCount; i++) {

                DatabaseRetrivation obj1=new DatabaseRetrivation(conn);
                ResultSet teacherrs1=obj1.teacherNameByteacherId(teacherId[i]);

                while (teacherrs1.next()) {
                    teacherNameComboBox.addItem(teacherrs1.getString("teacherName"));
                }
            }

            
        }catch (SQLException ex) {
           // Logger.getLogger(AssignTeacherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.loadTheTable();
       
    }
    
      private void loadTheTable() {
        rowCount1 = 0;
        try {

            for (int i = 0; i < jTable1.getRowCount();) {
                
                tablemodel.removeRow(i);
            }
            
           
            Connection connectionObj = DatabaseConnection.getConnectionObject();
            NewInfoDatabaseRetrivation obj=new NewInfoDatabaseRetrivation(connectionObj);
            ResultSet rs=obj.loadLabAssignTeacherTable(session,semester,courseType);
           

            
              while (rs.next()) {
                
                existingTeachers[rowCount1][0] = rs.getString("courseId");
                existingTeachers[rowCount1][1] = rs.getString("teacherId");
               
                DatabaseRetrivation obj1=new DatabaseRetrivation(connectionObj);
                ResultSet teacherrs1=obj1.teacherNameByteacherId(existingTeachers[rowCount1][1]);

                while (teacherrs1.next()) {
                 existingTeachers[rowCount1][2] = teacherrs1.getString("teacherName");
                }
                
                String[] rowStrings = {existingTeachers[rowCount1][0], existingTeachers[rowCount1][1],existingTeachers[rowCount1][2]};
                tablemodel.addRow(rowStrings);
                rowCount1++;

            } 
            clonedExistingTeachers = existingTeachers.clone();


        } catch (Exception ex) {
            //JOptionPane.showMessageDialog(null, "Exception :" + ex);
            Logger.getLogger(AssignTheoryCourseTeacherPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        assignIdComboBox = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        courseIdTextField = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        courseNameTextField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        assignYearTextField = new javax.swing.JTextField();
        teacherNameComboBox = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        addButton = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        studentSessionTextField = new javax.swing.JTextField();
        studentSemesterTextField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(89, 13, 23));

        jPanel3.setBackground(new java.awt.Color(51, 51, 0));
        jPanel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel3.setForeground(new java.awt.Color(51, 49, 37));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("AssignId");

        assignIdComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                assignIdComboBoxItemStateChanged(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Course Id");

        courseIdTextField.setEditable(false);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Course Title");

        courseNameTextField.setEditable(false);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Assign Year");

        assignYearTextField.setEditable(false);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Teacher Name");

        addButton.setFont(new java.awt.Font("Tahoma", 1, 11));
        addButton.setText("Add");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addGap(31, 31, 31)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(teacherNameComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(assignYearTextField, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(assignIdComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(courseNameTextField, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(courseIdTextField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(assignIdComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(courseIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(courseNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(assignYearTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(teacherNameComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 283, Short.MAX_VALUE)
                .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56))
        );

        jPanel4.setBackground(java.awt.Color.darkGray);
        jPanel4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jTable1.setModel(tablemodel=new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null,null},
                {null, null,null},
                {null, null,null},
                {null, null,null}
            },
            new String [] {
                "Course Id", "Teacher Id","Teacher Name"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 523, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32, Short.MAX_VALUE))
        );

        studentSessionTextField.setEditable(false);

        studentSemesterTextField.setEditable(false);
        studentSemesterTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentSemesterTextFieldActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Student Session");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Student Semester");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(199, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(46, 46, 46)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(studentSessionTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(jLabel7)
                        .addGap(31, 31, 31)
                        .addComponent(studentSemesterTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(40, 40, 40))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(studentSemesterTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(studentSessionTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void assignIdComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_assignIdComboBoxItemStateChanged
        // TODO add your handling code here:
        try {
            
            Connection conn=DatabaseConnection.getConnectionObject();
            DatabaseRetrivation obj1=new DatabaseRetrivation(conn);
            ResultSet rs=obj1.getLabCourseIdNameYear(semester,assignIdComboBox.getSelectedItem());
            
            while(rs.next()){
                courseIdTextField.setText(rs.getString("a.courseId"));
                courseNameTextField.setText(rs.getString("c.courseName"));
                assignYearTextField.setText(rs.getString("a.assignYear"));
            }
        } catch (SQLException ex) {
            // Logger.getLogger(AssignTeacherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
}//GEN-LAST:event_assignIdComboBoxItemStateChanged

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            String resultIdentification=assignIdComboBox.getSelectedItem()+assignYearTextField.getText().toString();
            System.out.print(resultIdentification);
            
            Connection conn = DatabaseConnection.getConnectionObject();
            DatabaseRetrivation obj1=new DatabaseRetrivation(conn);
            ResultSet rs=obj1.teacherIdFromTeacherName(teacherNameComboBox.getSelectedItem());
            while(rs.next()){
                labTeacherId=rs.getString("teacherId");
            }
            
            
            DatabaseInsertion dbInsert = new DatabaseInsertion(conn);
            if (dbInsert.insertLabCourseExaminerAssignInfo(resultIdentification,courseIdTextField.getText().toString(),labTeacherId,session,semester,courseType,assignYear)) {
                this.labExaminerResult = true;
                System.out.println("Insertion sucessfull T1");
                
            }else{
                this.labExaminerResult=false;
            }
            
            if (dbInsert.insertLabExaminerStatus("LE",resultIdentification,"NO")) {
                this.labExaminerResult = true;
                System.out.println("Insertion sucessfull T2");
                
            }else{
                this.labExaminerResult=false;
            }
            
            if (dbInsert.insertLabClassTestStatus("LCT",resultIdentification,"NO")) {
                this.labExaminerResult = true;
                System.out.println("Insertion sucessfull T3");
                
            }else{
                this.labExaminerResult=false;
            }
            
            this.loadTheTable();
            
            
            
        }catch (SQLException ex) {
            // Logger.getLogger(AssignTeacherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
}//GEN-LAST:event_addButtonActionPerformed

    private void studentSemesterTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentSemesterTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentSemesterTextFieldActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JComboBox assignIdComboBox;
    private javax.swing.JTextField assignYearTextField;
    private javax.swing.JTextField courseIdTextField;
    private javax.swing.JTextField courseNameTextField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField studentSemesterTextField;
    private javax.swing.JTextField studentSessionTextField;
    private javax.swing.JComboBox teacherNameComboBox;
    // End of variables declaration//GEN-END:variables
}
