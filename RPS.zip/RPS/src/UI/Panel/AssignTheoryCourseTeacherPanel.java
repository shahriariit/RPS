/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * AssignTheoryCourseTeacherPanel.java
 *
 * Created on Oct 4, 2013, 3:07:26 AM
 */
package UI.Panel;

import Database.DatabaseConnection;
import UI.Database.DatabaseInsertion;
import UI.Database.DatabaseRetrivation;
import UI.Database.NewInfoDatabaseRetrivation;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

/**
 *
 * @author SHAHRIAR
 */
public class AssignTheoryCourseTeacherPanel extends javax.swing.JPanel {

    /** Creates new form AssignTheoryCourseTeacherPanel */
    String session, semester, courseteacherid, adminId;
    String courseId[] = new String[500];
    String teacherId[] = new String[500];
    String teacherName[] = new String[500];
    String courseName[] = new String[500];
    JLabel courseIdlabel[] = new JLabel[100];
    JLabel courseNamelabel[] = new JLabel[100];
    JComboBox firstExaminercombobox[] = new JComboBox[100];
    JComboBox secondExaminercombobox[] = new JComboBox[100];
    int courseCount, teacherCount;
    String firstTeacherId, secondTeacherId;
    boolean firstExaminerresult, secondExaminerresult;
    int rowCount, rowCount1;
    static DefaultTableModel model = null;
    static DefaultTableModel tablemodel = null;
    static DefaultTableModel tablemodel1 = null;
    String[][] existingTeachers = new String[500][10];
    String[][] clonedExistingTeachers = new String[500][10];
    String[][] existingTeachers1 = new String[500][10];
    String[][] clonedExistingTeachers1 = new String[500][10];
    String courseType = "theory";
    String teacherId1, teacherId2;
    boolean result;
    String assignYear, assignYear1;

    public AssignTheoryCourseTeacherPanel(String session, String semester, String adminId) {

        this.session = session;
        this.semester = semester;

        initComponents();

        try {

            studentSessionTextField.setText(session);
            studentSessionTextField1.setText(session);

            try {

                Connection connectionObj = DatabaseConnection.getConnectionObject();
                DatabaseRetrivation obj = new DatabaseRetrivation(connectionObj);
                ResultSet resultSetObj = obj.semesterNameByAdminId(adminId, semester);

                while (resultSetObj.next()) {
                    studentSemesterTextField.setText(resultSetObj.getString("a.semesterName"));
                    studentSemesterTextField1.setText(resultSetObj.getString("a.semesterName"));
                }

            } catch (SQLException ex) {
                Logger.getLogger(GradeSheetAccessPanel.class.getName()).log(Level.SEVERE, null, ex);
            }



            Connection conn = DatabaseConnection.getConnectionObject();
            NewInfoDatabaseRetrivation assignTeacherobj = new NewInfoDatabaseRetrivation(conn);
            ResultSet rs = assignTeacherobj.getAssignTeacherIdTable(semester);

            while (rs.next()) {
                assignIdComboBox.addItem(rs.getString("assignTeacherId"));
                assignYear = rs.getString("assignYear");
            }


            ResultSet rs1 = assignTeacherobj.getAssignTeacherIdTable(semester);

            while (rs1.next()) {
                assignIdComboBox1.addItem(rs1.getString("assignTeacherId"));
                assignYear1 = rs1.getString("assignYear");
            }



            NewInfoDatabaseRetrivation obj = new NewInfoDatabaseRetrivation(conn);
            ResultSet teacherrs = obj.loadTeacherIdTableInfo();

            while (teacherrs.next()) {

                teacherId[rowCount] = teacherrs.getString("teacherId");
                System.out.println(teacherId[rowCount]);
                rowCount++;
            }

            System.out.println(rowCount);

            for (int i = 0; i < rowCount; i++) {

                DatabaseRetrivation obj1 = new DatabaseRetrivation(conn);
                ResultSet teacherrs1 = obj1.teacherNameByteacherId(teacherId[i]);

                while (teacherrs1.next()) {
                    teacherNameComboBox.addItem(teacherrs1.getString("teacherName"));
                }
            }

            for (int i = 0; i < rowCount; i++) {

                DatabaseRetrivation obj1 = new DatabaseRetrivation(conn);
                ResultSet teacherrs1 = obj1.teacherNameByteacherId(teacherId[i]);

                while (teacherrs1.next()) {
                    teacherNameComboBox1.addItem(teacherrs1.getString("teacherName"));
                }
            }


        } catch (SQLException ex) {
            // Logger.getLogger(AssignTeacherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.loadFirstTheTable();
        setUpSportColumn(jTable1,jTable1.getColumnModel().getColumn(1));
        this.loadSecondTheTable();
    }

     public void setUpSportColumn(JTable table,TableColumn sportColumn) {
        try {
            //Set up the editor for the sport cells.
              final JComboBox comboBox = new JComboBox();
              
                Connection conn = DatabaseConnection.getConnectionObject();
                NewInfoDatabaseRetrivation obj = new NewInfoDatabaseRetrivation(conn);
                ResultSet teacherrs = obj.loadTeacherIdTableInfo();

                
                while (teacherrs.next()) {

                    comboBox.addItem(teacherrs.getString("teacherId"));
                   
                }
              
               
                
                  try {
                        DatabaseRetrivation obj1 = new DatabaseRetrivation(conn);
                        ResultSet teacherrs1 = obj1.teacherNameByteacherId(comboBox.getSelectedItem().toString());
                        
                        System.out.println(teacherrs1.getString("teacherName"));
                        
                        String s=null;
                        
                       while (teacherrs1.next()) {
                              s=teacherrs1.getString("teacherName");
                              System.out.println(s);
                        }
                        
                        final String ss=s;
                        
                       comboBox.addItemListener(new java.awt.event.ItemListener() {

                          public void itemStateChanged(java.awt.event.ItemEvent evt) {
                              jTable1.setValueAt(ss, jTable1.getSelectedRow(), 2);

                          }
                      });
                       // 
                    } catch (SQLException ex) {
                        Logger.getLogger(AssignTheoryCourseTeacherPanel.class.getName()).log(Level.SEVERE, null, ex);
                    }
                
                
           
                
              sportColumn.setCellEditor(new DefaultCellEditor(comboBox));

              //Set up tool tips for the sport cells.
              DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
              renderer.setToolTipText("Click for combo box");
              sportColumn.setCellRenderer(renderer);
        } catch (SQLException ex) {
            Logger.getLogger(AssignTheoryCourseTeacherPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void loadFirstTheTable() {
        rowCount1 = 0;
        try {

            for (int i = 0; i < jTable1.getRowCount();) {

                tablemodel.removeRow(i);
            }


            Connection connectionObj = DatabaseConnection.getConnectionObject();
            NewInfoDatabaseRetrivation obj = new NewInfoDatabaseRetrivation(connectionObj);
            ResultSet rs = obj.loadAssignTeacherTable(session, semester, courseType);



            while (rs.next()) {

                existingTeachers[rowCount1][0] = rs.getString("courseId");
                existingTeachers[rowCount1][1] = rs.getString("teacherId");

                DatabaseRetrivation obj1 = new DatabaseRetrivation(connectionObj);
                ResultSet teacherrs1 = obj1.teacherNameByteacherId(existingTeachers[rowCount1][1]);

                while (teacherrs1.next()) {
                    existingTeachers[rowCount1][2] = teacherrs1.getString("teacherName");
                }

                String[] rowStrings = {existingTeachers[rowCount1][0], existingTeachers[rowCount1][1], existingTeachers[rowCount1][2]};
                tablemodel.addRow(rowStrings);
                rowCount1++;

            }
            clonedExistingTeachers = existingTeachers.clone();


        } catch (Exception ex) {
            //JOptionPane.showMessageDialog(null, "Exception :" + ex);
            Logger.getLogger(AssignTheoryCourseTeacherPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void loadSecondTheTable() {
        rowCount1 = 0;
        try {

            for (int i = 0; i < jTable2.getRowCount();) {

                tablemodel1.removeRow(i);
            }


            Connection connectionObj = DatabaseConnection.getConnectionObject();
            NewInfoDatabaseRetrivation obj = new NewInfoDatabaseRetrivation(connectionObj);
            ResultSet rs = obj.loadAssignTeacherTwoTable(session, semester, courseType);

            while (rs.next()) {

                existingTeachers1[rowCount1][0] = rs.getString("courseId");
                existingTeachers1[rowCount1][1] = rs.getString("teacherId");

                DatabaseRetrivation obj1 = new DatabaseRetrivation(connectionObj);
                ResultSet teacherrs1 = obj1.teacherNameByteacherId(existingTeachers1[rowCount1][1]);

                while (teacherrs1.next()) {
                    existingTeachers1[rowCount1][2] = teacherrs1.getString("teacherName");
                }

                String[] rowStrings = {existingTeachers1[rowCount1][0], existingTeachers1[rowCount1][1], existingTeachers1[rowCount1][2]};
                tablemodel1.addRow(rowStrings);
                rowCount1++;

            }

            clonedExistingTeachers1 = existingTeachers1.clone();


        } catch (Exception ex) {
            //JOptionPane.showMessageDialog(null, "Exception :" + ex);
            Logger.getLogger(AssignTheoryCourseTeacherPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        assignIdComboBox = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        courseIdTextField = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        courseNameTextField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        assignYearTextField = new javax.swing.JTextField();
        teacherNameComboBox = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        addButton = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        studentSessionTextField = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        studentSemesterTextField = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        assignIdComboBox1 = new javax.swing.JComboBox();
        jLabel9 = new javax.swing.JLabel();
        courseIdTextField1 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        courseNameTextField1 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        assignYearTextField1 = new javax.swing.JTextField();
        teacherNameComboBox1 = new javax.swing.JComboBox();
        jLabel12 = new javax.swing.JLabel();
        addButton1 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        studentSessionTextField1 = new javax.swing.JTextField();
        studentSemesterTextField1 = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();

        jTabbedPane1.setBackground(new java.awt.Color(89, 13, 23));
        jTabbedPane1.setForeground(new java.awt.Color(51, 51, 51));

        jPanel1.setBackground(new java.awt.Color(89, 13, 23));

        jPanel3.setBackground(new java.awt.Color(51, 51, 0));
        jPanel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("AssignId");

        assignIdComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                assignIdComboBoxItemStateChanged(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Course Id");

        courseIdTextField.setEditable(false);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Course Title");

        courseNameTextField.setEditable(false);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Assign Year");

        assignYearTextField.setEditable(false);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Teacher Name");

        addButton.setFont(new java.awt.Font("Tahoma", 1, 11));
        addButton.setText("Add");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addGap(31, 31, 31)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(teacherNameComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(assignYearTextField, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(assignIdComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(courseNameTextField, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(courseIdTextField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(assignIdComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(courseIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(courseNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(assignYearTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(teacherNameComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(77, 77, 77)
                .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(208, Short.MAX_VALUE))
        );

        jPanel4.setBackground(java.awt.Color.darkGray);
        jPanel4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jTable1.setModel(tablemodel=new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null,null},
                {null, null,null},
                {null, null,null},
                {null, null,null}
            },
            new String [] {
                "Course Id", "Teacher Id","Teacher Name"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 599, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 481, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Student Session");

        studentSessionTextField.setEditable(false);

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Student Semester");

        studentSemesterTextField.setEditable(false);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(169, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(studentSessionTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addComponent(studentSemesterTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(24, 24, 24))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(studentSessionTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(studentSemesterTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(85, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Select First Examiner", jPanel1);

        jPanel2.setBackground(new java.awt.Color(89, 13, 23));

        jPanel5.setBackground(new java.awt.Color(51, 51, 0));
        jPanel5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("AssignId");

        assignIdComboBox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                assignIdComboBox1ItemStateChanged(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Course Id");

        courseIdTextField1.setEditable(false);

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Course Title");

        courseNameTextField1.setEditable(false);

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Assign Year");

        assignYearTextField1.setEditable(false);

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Teacher Name");

        addButton1.setFont(new java.awt.Font("Tahoma", 1, 11));
        addButton1.setText("Add");
        addButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12))
                .addGap(31, 31, 31)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(addButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(teacherNameComboBox1, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(assignYearTextField1, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(assignIdComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(courseNameTextField1, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(courseIdTextField1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(assignIdComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(courseIdTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(courseNameTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(assignYearTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(teacherNameComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addGap(77, 77, 77)
                .addComponent(addButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(248, Short.MAX_VALUE))
        );

        jPanel6.setBackground(java.awt.Color.darkGray);
        jPanel6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jTable2.setModel(tablemodel1=new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null,null},
                {null, null,null},
                {null, null,null},
                {null, null,null}
            },
            new String [] {
                "Course Id", "Teacher Id","Teacher Name"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 599, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 518, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        studentSessionTextField1.setEditable(false);

        studentSemesterTextField1.setEditable(false);

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Student Session");

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Student Semester");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(643, 643, 643)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                        .addComponent(studentSessionTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(jLabel14)
                        .addGap(29, 29, 29)
                        .addComponent(studentSemesterTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(36, 36, 36))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(studentSemesterTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14)
                    .addComponent(studentSessionTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(43, 43, 43))
        );

        jTabbedPane1.addTab("Select Second Examiner", jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1256, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            String resultIdentification = assignIdComboBox.getSelectedItem() + assignYearTextField.getText().toString();
            System.out.print(resultIdentification);

            Connection conn = DatabaseConnection.getConnectionObject();
            DatabaseRetrivation obj1 = new DatabaseRetrivation(conn);
            ResultSet rs = obj1.teacherIdFromTeacherName(teacherNameComboBox.getSelectedItem());
            while (rs.next()) {
                teacherId1 = rs.getString("teacherId");
            }

            int response = JOptionPane.showConfirmDialog(null, "Do you want to submit?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

            if (response == JOptionPane.NO_OPTION) {
                System.out.println("No button clicked");

            } else if (response == JOptionPane.YES_OPTION) {


                DatabaseInsertion dbInsert = new DatabaseInsertion(conn);
                if (dbInsert.insertCourseFirstExaminerAssignInfo(resultIdentification, courseIdTextField.getText().toString(), teacherId1, session, semester, courseType, assignYear)) {
                    this.result = true;
                    System.out.println("Insertion sucessfull T1");

                } else {
                    this.result = false;
                }

                if (dbInsert.insertFirstExaminerStatus("EF", resultIdentification, "NO")) {
                    this.result = true;
                    System.out.println("Insertion sucessfull T2");

                } else {
                    this.result = false;
                }

                if (dbInsert.insertClassTestStatus("CT", resultIdentification, "NO")) {
                    this.result = true;
                    System.out.println("Insertion sucessfull T3");

                } else {
                    this.result = false;
                }

                this.loadFirstTheTable();

            } else if (response == JOptionPane.CLOSED_OPTION) {
                System.out.println("JOptionPane closed");
            }

        } catch (SQLException ex) {
            // Logger.getLogger(AssignTeacherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_addButtonActionPerformed

    private void assignIdComboBox1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_assignIdComboBox1ItemStateChanged
        // TODO add your handling code here:
        try {

            Connection conn = DatabaseConnection.getConnectionObject();
            DatabaseRetrivation obj1 = new DatabaseRetrivation(conn);
            ResultSet rs = obj1.getCourseIdNameYear(semester, assignIdComboBox1.getSelectedItem());

            while (rs.next()) {
                courseIdTextField1.setText(rs.getString("a.courseId"));
                courseNameTextField1.setText(rs.getString("c.courseName"));
                assignYearTextField1.setText(rs.getString("a.assignYear"));
            }
        } catch (SQLException ex) {
            // Logger.getLogger(AssignTeacherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_assignIdComboBox1ItemStateChanged

    private void addButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButton1ActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            String resultIdentification = assignIdComboBox1.getSelectedItem() + assignYearTextField1.getText().toString();
            System.out.println(resultIdentification);

            Connection conn = DatabaseConnection.getConnectionObject();
            DatabaseRetrivation obj1 = new DatabaseRetrivation(conn);
            ResultSet rs = obj1.teacherIdFromTeacherName(teacherNameComboBox1.getSelectedItem());
            while (rs.next()) {
                teacherId2 = rs.getString("teacherId");
            }

             int response = JOptionPane.showConfirmDialog(null, "Do you want to submit?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

            if (response == JOptionPane.NO_OPTION) {
                System.out.println("No button clicked");

            }else if (response == JOptionPane.YES_OPTION) {  
            
            DatabaseInsertion dbInsert = new DatabaseInsertion(conn);
            if (dbInsert.insertCourseSecondExaminerAssignInfo(resultIdentification, courseIdTextField1.getText().toString(), teacherId2, session, semester, courseType, assignYear1)) {
                this.result = true;
                System.out.println("Insertion sucessfull T1");

            } else {
                this.result = false;
            }

            if (dbInsert.insertSecondExaminerStatus("ES", resultIdentification, "NO")) {
                this.result = true;
                System.out.println("Insertion sucessfull T2");

            } else {
                this.result = false;
            }

            this.loadSecondTheTable(); 
            
            }else if (response == JOptionPane.CLOSED_OPTION) {
                 System.out.println("JOptionPane closed");
            }

        } catch (SQLException ex) {
            // Logger.getLogger(AssignTeacherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_addButton1ActionPerformed

    private void assignIdComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_assignIdComboBoxItemStateChanged
        // TODO add your handling code here:
        try {

            Connection conn = DatabaseConnection.getConnectionObject();
            DatabaseRetrivation obj1 = new DatabaseRetrivation(conn);
            ResultSet rs = obj1.getCourseIdNameYear(semester, assignIdComboBox.getSelectedItem());

            while (rs.next()) {
                courseIdTextField.setText(rs.getString("a.courseId"));
                courseNameTextField.setText(rs.getString("c.courseName"));
                assignYearTextField.setText(rs.getString("a.assignYear"));
            }
        } catch (SQLException ex) {
            // Logger.getLogger(AssignTeacherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
}//GEN-LAST:event_assignIdComboBoxItemStateChanged
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JButton addButton1;
    private javax.swing.JComboBox assignIdComboBox;
    private javax.swing.JComboBox assignIdComboBox1;
    private javax.swing.JTextField assignYearTextField;
    private javax.swing.JTextField assignYearTextField1;
    private javax.swing.JTextField courseIdTextField;
    private javax.swing.JTextField courseIdTextField1;
    private javax.swing.JTextField courseNameTextField;
    private javax.swing.JTextField courseNameTextField1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField studentSemesterTextField;
    private javax.swing.JTextField studentSemesterTextField1;
    private javax.swing.JTextField studentSessionTextField;
    private javax.swing.JTextField studentSessionTextField1;
    private javax.swing.JComboBox teacherNameComboBox;
    private javax.swing.JComboBox teacherNameComboBox1;
    // End of variables declaration//GEN-END:variables
}
