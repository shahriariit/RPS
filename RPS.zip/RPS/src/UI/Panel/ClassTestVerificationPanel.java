/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * classTestVeirficationPanel.java
 *
 * Created on Oct 17, 2013, 4:02:13 PM
 */
package UI.Panel;

import Database.DatabaseConnection;
import Database.ReportLocation;
import UI.Database.DatabaseInsertion;
import UI.Database.DatabaseRetrivation;
import UI.Database.NewInfoDatabaseRetrivation;
import java.awt.Dimension;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author SHAHRIAR
 */
public class ClassTestVerificationPanel extends javax.swing.JPanel {

    /** Creates new form classTestVeirficationPanel */
    String s[] = new String[1000];
    double test[] = new double[100];
    double finaltest[] = new double[100];
    int count;
    int fullmarks = 40;
    static Vector headers = new Vector();
    static DefaultTableModel model = null;
    static DefaultTableModel tablemodel = null;
    static Vector data = new Vector();
    static JFileChooser jChooser;
    static int tableWidth = 0; // set the tableWidth
    static int tableHeight = 0;
    int sheetSelection, rowCount1;
    private SpinnerModel model1;
    String[][] existingStudents = new String[500][10];
    String[][] existingClassTest = new String[500][10];
    String[][] clonedexistingClassTest = new String[500][10];
    boolean result;
    private String[][] dataNames;
    private String[] columnNames;
    NumberFormat nf;
    String examinerOneTagId;
    int examinerserialId;
    String courseId, semesterNo, studentSession, assignFirstExaminerId, identification, teacherName, teacherDesignation, courseName;
    String resultIdentification, adminId, status;
    ReportLocation location = new ReportLocation();

    public ClassTestVerificationPanel(String identification, String assignFirstExaminerId, String courseId, String semesterNo, String studentSession) {
        try {
            //resultIdentification="EF00000001";
            this.identification = identification;
            this.courseId = courseId;
            this.semesterNo = semesterNo;
            this.studentSession = studentSession;
            this.assignFirstExaminerId = assignFirstExaminerId;

            jChooser = new JFileChooser();
            model1 = new SpinnerNumberModel(0, 0, 20, 1);

            Connection conn = DatabaseConnection.getConnectionObject();
            DatabaseRetrivation obj = new DatabaseRetrivation(conn);

            String sql1 = "select concat(classTestTagId,classTestSerialId) as classTestExaminerId from classteststatus where assignId='" + assignFirstExaminerId + "'";
            Statement stmt1 = conn.prepareStatement(sql1);
            ResultSet rs1 = stmt1.executeQuery(sql1);

            while (rs1.next()) {
                resultIdentification = rs1.getString("classTestExaminerId");
                System.out.println("E1:" + resultIdentification);
            }


            String sql4 = "select classTestTagId,classTestSerialId from classteststatus where assignId='" + assignFirstExaminerId + "'";
            Statement stmt4 = conn.prepareStatement(sql4);
            ResultSet rs4 = stmt1.executeQuery(sql4);

            while (rs4.next()) {
                examinerOneTagId = rs4.getString("classTestTagId");
                System.out.println(examinerOneTagId);
                examinerserialId = rs4.getInt("classTestSerialId");
                System.out.println(examinerserialId);
            }




            String sql = "select studentExamRoll from student where studentSemester='" + semesterNo + "'";
            System.out.println(sql);


            Statement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {

                s[count] = rs.getString("studentExamRoll");
                System.out.println(rs.getString("studentExamRoll"));

                count++;
            }


            String sql2 = "select distinct adminId from temptheorygradeexaminedsheet where studentSession='" + studentSession + "' and semesterNo='" + semesterNo + "' and courseId='" + courseId + "'";
            System.out.println(sql2);

            ResultSet rs2 = stmt.executeQuery(sql2);

            while (rs2.next()) {
                adminId = rs2.getString("adminId");
            }

            initComponents();
            teacherIdTextField.setText(identification);
            courseIdTextField.setText(courseId);
            studentSessionTextField.setText(studentSession);
            studentSemesterTextField.setText(semesterNo);
            assignFirstExaminerIdTextField.setText(assignFirstExaminerId);
            classTestIdTextField.setText(resultIdentification);
            groupButton();

            ResultSet resultSetObj2 = obj.courseNameByCourseId(courseId);

            while (resultSetObj2.next()) {
                courseName = resultSetObj2.getString("courseName");
            }


            ResultSet resultSetObj3 = obj.teacherNameteacherDesignationByteacherId(identification);


            while (resultSetObj3.next()) {

                teacherName = resultSetObj3.getString("teacherName");
                teacherDesignation = resultSetObj3.getString("teacherDesignation");
            }


            //checking status about teacher verification after submission

            String statussql = "select classTestStatus from classteststatus where assignId='" + assignFirstExaminerId + "'";
            System.out.println(statussql);
            Statement stmt3 = conn.prepareStatement(statussql);
            ResultSet rs3 = stmt3.executeQuery(statussql);
            while (rs3.next()) {
                status = rs3.getString("classTestStatus");

            }


            System.out.println(status);
            if (status.equals("YES")) {
                submitButton.setEnabled(false);
            } else {
                System.out.println("Sorry");
            }


            studentList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            studentList.addListSelectionListener(new ListSelectionListener() {

                @Override
                public void valueChanged(ListSelectionEvent e) {
                    try {
                        int idx = studentList.getSelectedIndex();
                        studentExamRollTextField.setText(String.valueOf(studentList.getSelectedValue()));
                        String sql = "select studentClassRoll from student where studentExamRoll='" + studentList.getSelectedValue() + "'";
                        Connection conn = DatabaseConnection.getConnectionObject();
                        Statement stmt = conn.prepareStatement(sql);
                        ResultSet rs = stmt.executeQuery(sql);

                        while (rs.next()) {
                            studentClassRollTextField.setText(rs.getString("studentClassRoll"));
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(ClassTestVerificationPanel.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });

            this.loadTheTable(); 
         
            for (int i = 0; i < mainTable.getRowCount(); i++) {
                final int row = i;
                convertTableButton.addActionListener(new java.awt.event.ActionListener() {

                    private boolean result;

                    public void actionPerformed(java.awt.event.ActionEvent evt) {

                        try {

                             double baseValue = Double.parseDouble(baseTableComboBox.getSelectedItem().toString());
                             double convertedValue = Double.parseDouble(convertedTableComboBox.getSelectedItem().toString());

                            if (mainTable.getSelectedColumn() == 2 || mainTable.getSelectedColumn() == 3 || mainTable.getSelectedColumn() == 4) {
                                int column = mainTable.convertColumnIndexToModel(mainTable.getSelectedColumn());
                                double currentValue = Double.parseDouble(tablemodel.getValueAt(row, column).toString());
                                tablemodel.setValueAt(new Double((currentValue * convertedValue / baseValue)), row, column);
                            }
                        } catch (Exception ex) {
                            this.result = false;
                             //JOptionPane.showMessageDialog(null, "Please Select a column" + ex.getMessage());
                            //Logger.getLogger(ClassTestVerificationPanel.class.getName()).log(Level.SEVERE, null, ex);
                        
                        }

                    }
                });

            }
            
            

        } catch (SQLException ex) {
            Logger.getLogger(ClassTestVerificationPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
       
    }

    private void groupButton() {

        ButtonGroup bg1 = new ButtonGroup();

        bg1.add(bestRadioButton);
        bg1.add(averageRadioButton);


    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        excelLoadTable = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        browseExcelButton = new javax.swing.JButton();
        sheetSpinner = new javax.swing.JSpinner(model1);
        excelsaveButton = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        baseTableComboBox = new javax.swing.JComboBox();
        convertedTableComboBox = new javax.swing.JComboBox();
        convertTableButton = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        saveEntryButton = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        bestRadioButton = new javax.swing.JRadioButton();
        averageRadioButton = new javax.swing.JRadioButton();
        jPanel5 = new javax.swing.JPanel();
        tutorialComboBox = new javax.swing.JComboBox();
        baseComboBox = new javax.swing.JComboBox();
        convertedComboBox = new javax.swing.JComboBox();
        convertButton = new javax.swing.JButton();
        createReportButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        submitButton = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        studentClassRollTextField = new javax.swing.JTextField();
        studentExamRollTextField = new javax.swing.JTextField();
        T1TextField = new javax.swing.JTextField();
        T2TextField = new javax.swing.JTextField();
        T3TextField = new javax.swing.JTextField();
        tutorialTextField = new javax.swing.JTextField();
        assignmentTextField = new javax.swing.JTextField();
        attendanceTextField = new javax.swing.JTextField();
        presentationTextField = new javax.swing.JTextField();
        totalTextField = new javax.swing.JTextField();
        countTextField = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        studentList = new javax.swing.JList(s);
        jScrollPane3 = new javax.swing.JScrollPane();
        mainTable = new javax.swing.JTable(){

            public boolean isCellEditable(int row,int column){

                switch(column){
                    case 0:
                    case 1:
                    case 5:
                    case 9:
                    return false;
                    default:
                    return true;

                }

            }}
            ;
            jPanel6 = new javax.swing.JPanel();
            courseIdTextField = new javax.swing.JTextField();
            teacherIdTextField = new javax.swing.JTextField();
            studentSessionTextField = new javax.swing.JTextField();
            studentSemesterTextField = new javax.swing.JTextField();
            assignFirstExaminerIdTextField = new javax.swing.JTextField();
            classTestIdTextField = new javax.swing.JTextField();

            setBackground(new java.awt.Color(89, 13, 23));

            excelLoadTable.setModel(new javax.swing.table.DefaultTableModel(
                new Object [][] {
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null}
                },
                new String [] {
                    "Student Exam Roll", "Tutorial1", "Tutorial2", "Tutorial3", "TutorialFinal", "Assignment", "Attendance", "Total"
                }
            ));
            jScrollPane2.setViewportView(excelLoadTable);

            jPanel1.setBackground(new java.awt.Color(26, 60, 26));
            jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

            browseExcelButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            browseExcelButton.setText("select Excel file");
            browseExcelButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    browseExcelButtonActionPerformed(evt);
                }
            });

            excelsaveButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            excelsaveButton.setText("Save");
            excelsaveButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    excelsaveButtonActionPerformed(evt);
                }
            });

            updateButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            updateButton.setText("Update");
            updateButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    updateButtonActionPerformed(evt);
                }
            });

            deleteButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            deleteButton.setText("Delete All");
            deleteButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    deleteButtonActionPerformed(evt);
                }
            });

            jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

            baseTableComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "10", "15", "20", "25", "30", "35", "40" }));

            convertedTableComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "10", "15", "20", "25", "30", "35", "40" }));

            convertTableButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            convertTableButton.setText("Convert");
            convertTableButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    convertTableButtonActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
            jPanel7.setLayout(jPanel7Layout);
            jPanel7Layout.setHorizontalGroup(
                jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel7Layout.createSequentialGroup()
                    .addGap(26, 26, 26)
                    .addComponent(baseTableComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(convertedTableComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(convertTableButton)
                    .addContainerGap(40, Short.MAX_VALUE))
            );
            jPanel7Layout.setVerticalGroup(
                jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel7Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(baseTableComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(convertedTableComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(convertTableButton))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );

            javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
            jPanel1.setLayout(jPanel1Layout);
            jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(browseExcelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(37, 37, 37)
                    .addComponent(sheetSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(27, 27, 27)
                    .addComponent(excelsaveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(30, 30, 30)
                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(228, Short.MAX_VALUE))
            );
            jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addContainerGap())
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(browseExcelButton, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                                .addComponent(sheetSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(excelsaveButton, javax.swing.GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
                                .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(28, 28, 28))))
            );

            jPanel2.setBackground(new java.awt.Color(26, 60, 26));
            jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

            saveEntryButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            saveEntryButton.setText("Save Entry");
            saveEntryButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    saveEntryButtonActionPerformed(evt);
                }
            });

            jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Tutorial Calculation"));

            bestRadioButton.setText("Best");
            bestRadioButton.addChangeListener(new javax.swing.event.ChangeListener() {
                public void stateChanged(javax.swing.event.ChangeEvent evt) {
                    bestRadioButtonStateChanged(evt);
                }
            });
            bestRadioButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    bestRadioButtonActionPerformed(evt);
                }
            });

            averageRadioButton.setText("Average");
            averageRadioButton.addChangeListener(new javax.swing.event.ChangeListener() {
                public void stateChanged(javax.swing.event.ChangeEvent evt) {
                    averageRadioButtonStateChanged(evt);
                }
            });
            averageRadioButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    averageRadioButtonActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
            jPanel4.setLayout(jPanel4Layout);
            jPanel4Layout.setHorizontalGroup(
                jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bestRadioButton)
                    .addGap(12, 12, 12)
                    .addComponent(averageRadioButton)
                    .addContainerGap())
            );
            jPanel4Layout.setVerticalGroup(
                jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(bestRadioButton)
                        .addComponent(averageRadioButton))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );

            jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Convert value"));

            tutorialComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "T1", "T2", "T3" }));

            baseComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "10", "15", "20", "25", "30", "35", "40" }));

            convertedComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "10", "15", "20", "25", "30", "35", "40" }));

            convertButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            convertButton.setText("Convert");
            convertButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    convertButtonActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
            jPanel5.setLayout(jPanel5Layout);
            jPanel5Layout.setHorizontalGroup(
                jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel5Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(tutorialComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(baseComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(convertedComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(convertButton)
                    .addContainerGap(20, Short.MAX_VALUE))
            );
            jPanel5Layout.setVerticalGroup(
                jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tutorialComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(baseComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(convertedComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(convertButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
            );

            createReportButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            createReportButton.setText("Create Report");
            createReportButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    createReportButtonActionPerformed(evt);
                }
            });

            backButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            backButton.setText("Back");
            backButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    backButtonActionPerformed(evt);
                }
            });

            submitButton.setText("Submit");
            submitButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    submitButtonActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
            jPanel2.setLayout(jPanel2Layout);
            jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(saveEntryButton, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(createReportButton, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(29, 29, 29)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(28, 28, 28)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(31, 31, 31)
                    .addComponent(submitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(26, 26, 26)
                    .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );
            jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(createReportButton, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(saveEntryButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addContainerGap()
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(submitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );

            jPanel3.setBackground(new java.awt.Color(153, 153, 0));
            jPanel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

            studentClassRollTextField.setEditable(false);

            studentExamRollTextField.setEditable(false);

            T1TextField.setText("0");
            T1TextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    T1TextFieldKeyReleased(evt);
                }
            });

            T2TextField.setText("0");
            T2TextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    T2TextFieldKeyReleased(evt);
                }
            });

            T3TextField.setText("0");
            T3TextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    T3TextFieldKeyReleased(evt);
                }
            });

            tutorialTextField.setEditable(false);
            tutorialTextField.setText("0");
            tutorialTextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    tutorialTextFieldKeyReleased(evt);
                }
            });

            assignmentTextField.setText("0");
            assignmentTextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    assignmentTextFieldKeyReleased(evt);
                }
            });

            attendanceTextField.setText("0");
            attendanceTextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    attendanceTextFieldKeyReleased(evt);
                }
            });

            presentationTextField.setText("0");
            presentationTextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    presentationTextFieldKeyReleased(evt);
                }
            });

            totalTextField.setEditable(false);
            totalTextField.setText("0");

            countTextField.setEditable(false);

            javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
            jPanel3.setLayout(jPanel3Layout);
            jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGap(12, 12, 12)
                    .addComponent(studentClassRollTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(studentExamRollTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(T1TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(T2TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(T3TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(tutorialTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(assignmentTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(attendanceTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(presentationTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(totalTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(countTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 196, Short.MAX_VALUE)
                    .addContainerGap())
            );
            jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(studentExamRollTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(T1TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(T2TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(T3TextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tutorialTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(assignmentTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(attendanceTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(presentationTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(totalTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(studentClassRollTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(26, Short.MAX_VALUE))
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(countTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap())
            );

            studentList.setFont(new java.awt.Font("Times New Roman", 0, 24));
            studentList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
            jScrollPane1.setViewportView(studentList);

            mainTable.setModel(tablemodel=new javax.swing.table.DefaultTableModel(
                new Object [][] {
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null}
                },
                new String [] {
                    "StudentClassRoll", "StudentExamRoll", "Tutorial1", "Tutorial2", "Tutorial3", "TutorialFinal", "Assignment", "Attendance", "Presentation", "Total"
                }
            ));
            mainTable.setColumnSelectionAllowed(true);
            mainTable.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    mainTableKeyReleased(evt);
                }
            });
            jScrollPane3.setViewportView(mainTable);
            mainTable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);

            jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Info"));

            courseIdTextField.setEditable(false);

            teacherIdTextField.setEditable(false);

            studentSessionTextField.setEditable(false);

            studentSemesterTextField.setEditable(false);

            assignFirstExaminerIdTextField.setEditable(false);

            javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
            jPanel6.setLayout(jPanel6Layout);
            jPanel6Layout.setHorizontalGroup(
                jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel6Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(teacherIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(courseIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(studentSessionTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                        .addComponent(studentSemesterTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                        .addComponent(assignFirstExaminerIdTextField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE))
                    .addContainerGap())
            );
            jPanel6Layout.setVerticalGroup(
                jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel6Layout.createSequentialGroup()
                    .addComponent(courseIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(teacherIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(studentSessionTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(studentSemesterTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(assignFirstExaminerIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(21, Short.MAX_VALUE))
            );

            classTestIdTextField.setEditable(false);

            javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
            this.setLayout(layout);
            layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addGap(45, 45, 45)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(classTestIdTextField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1067, Short.MAX_VALUE))
                            .addGap(18, 18, 18)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(8, 8, 8))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                                    .addGap(18, 18, 18)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 938, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGap(136, 136, 136)))
                    .addContainerGap())
            );
            layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(classTestIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );
        }// </editor-fold>//GEN-END:initComponents

    private void browseExcelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_browseExcelButtonActionPerformed
        // TODO add your handling code here:
        jChooser.showOpenDialog(null);

        try {

            File file = jChooser.getSelectedFile();
            if (!file.getName().endsWith("xls")) {
                JOptionPane.showMessageDialog(null, "Please select only Excel file.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                fillData(file);
                model = new DefaultTableModel(data, headers);
                tableWidth = model.getColumnCount() * 150;
                tableHeight = model.getRowCount() * 25;
                excelLoadTable.setPreferredSize(new Dimension(tableWidth, tableHeight));
                excelLoadTable.setModel(model);
            }
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(null, "Thank you", "Message", JOptionPane.INFORMATION_MESSAGE);
        }
}//GEN-LAST:event_browseExcelButtonActionPerformed

    public void averageDBInsert() {

        try {
            Connection connectionObj = DatabaseConnection.getConnectionObject();
            DatabaseInsertion dbInsert = new DatabaseInsertion(connectionObj);

            String[] options = {"Best", "Average"};
            int s = JOptionPane.showOptionDialog(null, "Please Choose an option:", "Option", 2, 1, null, options, excelLoadTable);


            for (int i = 0; i < excelLoadTable.getRowCount(); i++) {

                double v1 = Double.parseDouble(excelLoadTable.getValueAt(i, 1).toString());
                double v2 = Double.parseDouble(excelLoadTable.getValueAt(i, 2).toString());
                double v3 = Double.parseDouble(excelLoadTable.getValueAt(i, 3).toString());
                double v5 = Double.parseDouble(excelLoadTable.getValueAt(i, 5).toString());
                double v6 = Double.parseDouble(excelLoadTable.getValueAt(i, 6).toString());
                double v7 = Double.parseDouble(excelLoadTable.getValueAt(i, 7).toString());
                double v8 = Double.parseDouble(excelLoadTable.getValueAt(i, 8).toString());
                
                if (s == 1) {

                    double avg = Average(v1, v2, v3); 
                    double sum =avg+v5+v6+v7+v8;

                    if (dbInsert.insertClassTestInfo(resultIdentification, excelLoadTable.getValueAt(i, 0).toString(), excelLoadTable.getValueAt(i, 1).toString(), excelLoadTable.getValueAt(i, 2).toString(), excelLoadTable.getValueAt(i, 3).toString(), String.valueOf(avg), excelLoadTable.getValueAt(i, 5).toString(), excelLoadTable.getValueAt(i, 6).toString(), excelLoadTable.getValueAt(i, 7).toString(), excelLoadTable.getValueAt(i, 8).toString(),String.valueOf(sum))) {
                        this.result = true;
                    } else {
                        this.result = false;
                    }

                } else if (s == 0) {
                
                }



            }

            if (result) {
                JOptionPane.showMessageDialog(null, "Data Inserted database Sucessfully");
                this.loadTheTable();
            } else {
                JOptionPane.showMessageDialog(null, "Data already exist");
                System.out.println("Data already Exist in the database");
            }
        } catch (ArrayIndexOutOfBoundsException ex) {
            JOptionPane.showMessageDialog(null, "Excel file can not adjust by required field");
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(null, "Data have to selected");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Data already exist in the Database");
        }

    }

    private void excelsaveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_excelsaveButtonActionPerformed
        // TODO add your handling code here:
        try {

            Connection connectionObj = DatabaseConnection.getConnectionObject();
            DatabaseInsertion dbInsert = new DatabaseInsertion(connectionObj);

 
            for (int i = 0; i < excelLoadTable.getRowCount(); i++) {


               

                    if (dbInsert.insertClassTestInfo(resultIdentification, excelLoadTable.getValueAt(i, 0).toString(), excelLoadTable.getValueAt(i, 1).toString(), excelLoadTable.getValueAt(i, 2).toString(), excelLoadTable.getValueAt(i, 3).toString(),excelLoadTable.getValueAt(i,4).toString(), excelLoadTable.getValueAt(i, 5).toString(), excelLoadTable.getValueAt(i, 6).toString(), excelLoadTable.getValueAt(i, 7).toString(), excelLoadTable.getValueAt(i, 8).toString(),excelLoadTable.getValueAt(i, 8).toString())) {
                        this.result = true;
                    } else {
                        this.result = false;
                    }

                

            }

            if (result) {
                JOptionPane.showMessageDialog(null, "Data Inserted database Sucessfully");
                this.loadTheTable();
            } else {
                JOptionPane.showMessageDialog(null, "Data already exist");
                System.out.println("Data already Exist in the database");
            }



        } catch (ArrayIndexOutOfBoundsException ex) {
            JOptionPane.showMessageDialog(null, "Excel file can not adjust");
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(null, "Data have to selected");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Data already exist in the Database");
        }

    }//GEN-LAST:event_excelsaveButtonActionPerformed

    private void saveEntryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveEntryButtonActionPerformed
        // TODO add your handling code here:
        try {

            Connection connectionObj = DatabaseConnection.getConnectionObject();
            DatabaseInsertion dbInsert = new DatabaseInsertion(connectionObj);


            if (studentExamRollTextField.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Please Select Exam Roll");
            } else {
                double value = Double.parseDouble(totalTextField.getText());
                if (value >= 0 && value <= fullmarks) {
                    if (dbInsert.insertClassTestInfo(resultIdentification, studentClassRollTextField.getText(), studentExamRollTextField.getText(), T1TextField.getText(), T2TextField.getText(), T3TextField.getText(), tutorialTextField.getText(), assignmentTextField.getText(), attendanceTextField.getText(), presentationTextField.getText(), totalTextField.getText())) {
                        this.result = true;
                    } else {
                        this.result = false;
                    }

                    if (result) {
                        JOptionPane.showMessageDialog(null, "Data Inserted database Sucessfully");
                        this.loadTheTable();
                    } else {
                        JOptionPane.showMessageDialog(null, "Data already exist in the database");
                    }

                } else {
                    JOptionPane.showMessageDialog(null, "Full Marks is greater than " + fullmarks);
                }


            }

        } catch (ArrayIndexOutOfBoundsException ex) {
            JOptionPane.showMessageDialog(null, "Excel file can not adjust");
        }
}//GEN-LAST:event_saveEntryButtonActionPerformed

    private void bestRadioButtonStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_bestRadioButtonStateChanged
        // TODO add your handling code here:
        try {
            double total = Double.parseDouble(tutorialTextField.getText()) + Double.parseDouble(assignmentTextField.getText()) + Double.parseDouble(attendanceTextField.getText()) + Double.parseDouble(presentationTextField.getText());
            totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_bestRadioButtonStateChanged

    private void bestRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bestRadioButtonActionPerformed
        // TODO add your handling code here:
        int number = 0;


        try {
            String num_of_tutorial = javax.swing.JOptionPane.showInputDialog("How many best Tutorial marks\ndo you want to take");
            number = Integer.parseInt(num_of_tutorial);
        } catch (NumberFormatException ne) {
            javax.swing.JOptionPane.showMessageDialog(null, "Bad Format", "Warning Message", javax.swing.JOptionPane.WARNING_MESSAGE);
            // SetData(new String("0"), i, cols + 1);

        }

        if (number <= 3) {

            nf = NumberFormat.getInstance();
            nf.setMinimumFractionDigits(2);
            nf.setMaximumFractionDigits(2);
            Quicksort quicksort = new Quicksort();

            test[0] = Double.parseDouble(T1TextField.getText());
            test[1] = Double.parseDouble(T2TextField.getText());
            test[2] = Double.parseDouble(T3TextField.getText());

            quicksort.quicksort(test, 0, 2);

            int v = 0;

            for (int k = 2; k >= 0; k--) {

                finaltest[v] = test[k];

                System.out.print(test[k] + ",");

                v++;
            }

            double sum = 0;

            for (int i = 0; i < number; i++) {
                sum += finaltest[i];
                System.out.print(test[i]);
            }

            System.out.println();
            System.out.println(sum);
            double avg = sum / number;
            System.out.println(avg);

            tutorialTextField.setText(String.valueOf(nf.format(avg)));

        } else {
            JOptionPane.showMessageDialog(null, "unsupported data where " + "\n" + "Tutorial :" + 3 + "\n" + "Best Count :" + number);
        }

        //avg1 = String.valueOf(nf.format(avg));
    }//GEN-LAST:event_bestRadioButtonActionPerformed

    private void averageRadioButtonStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_averageRadioButtonStateChanged
        // TODO add your handling code here:
        try {
            double total = Double.parseDouble(tutorialTextField.getText()) + Double.parseDouble(assignmentTextField.getText()) + Double.parseDouble(attendanceTextField.getText()) + Double.parseDouble(presentationTextField.getText());
            totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_averageRadioButtonStateChanged

  

    private void averageRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_averageRadioButtonActionPerformed
        // TODO add your handling code here:
        nf = NumberFormat.getInstance();
        nf.setMinimumFractionDigits(2);
        nf.setMaximumFractionDigits(2);

        double t1 = Double.parseDouble(T1TextField.getText().toString());
        double t2 = Double.parseDouble(T2TextField.getText().toString());
        double t3 = Double.parseDouble(T3TextField.getText().toString());
        double average = Average(t1, t2, t3);

        tutorialTextField.setText(nf.format(average));
    }//GEN-LAST:event_averageRadioButtonActionPerformed

    private void convertButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_convertButtonActionPerformed
        // TODO add your handling code here:
        try {
            nf = NumberFormat.getInstance();
            nf.setMinimumFractionDigits(2);
            nf.setMaximumFractionDigits(2);


            if (tutorialComboBox.getSelectedItem().equals("T1")) {
                double t1 = Double.parseDouble(T1TextField.getText());
                double b = Double.parseDouble(baseComboBox.getSelectedItem().toString());
                double c = Double.parseDouble(convertedComboBox.getSelectedItem().toString());
                double result = (t1 * c) / b;
                T1TextField.setText(nf.format(result));
            } else if (tutorialComboBox.getSelectedItem().equals("T2")) {
                double t2 = Double.parseDouble(T2TextField.getText());
                double b = Double.parseDouble(baseComboBox.getSelectedItem().toString());
                double c = Double.parseDouble(convertedComboBox.getSelectedItem().toString());
                double result = (t2 * c) / b;
                T2TextField.setText(nf.format(result));

            } else if (tutorialComboBox.getSelectedItem().equals("T3")) {
                double t3 = Double.parseDouble(T3TextField.getText());
                double b = Double.parseDouble(baseComboBox.getSelectedItem().toString());
                double c = Double.parseDouble(convertedComboBox.getSelectedItem().toString());
                double result = (t3 * c) / b;
                T3TextField.setText(nf.format(result));

            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "It is not number");
        }
}//GEN-LAST:event_convertButtonActionPerformed

    private void tutorialTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tutorialTextFieldKeyReleased
        // TODO add your handling code here:
        try {

            double total = Double.parseDouble(tutorialTextField.getText()) + Double.parseDouble(assignmentTextField.getText()) + Double.parseDouble(attendanceTextField.getText()) + Double.parseDouble(presentationTextField.getText());
            totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_tutorialTextFieldKeyReleased

    private void assignmentTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_assignmentTextFieldKeyReleased
        // TODO add your handling code here:
        try {
            double total = Double.parseDouble(tutorialTextField.getText()) + Double.parseDouble(assignmentTextField.getText()) + Double.parseDouble(attendanceTextField.getText()) + Double.parseDouble(presentationTextField.getText());
            totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_assignmentTextFieldKeyReleased

    private void attendanceTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_attendanceTextFieldKeyReleased
        // TODO add your handling code here:
        try {
            double total = Double.parseDouble(tutorialTextField.getText()) + Double.parseDouble(assignmentTextField.getText()) + Double.parseDouble(attendanceTextField.getText()) + Double.parseDouble(presentationTextField.getText());
            totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_attendanceTextFieldKeyReleased

    private void presentationTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_presentationTextFieldKeyReleased
        // TODO add your handling code here:
        try {
            double total = Double.parseDouble(tutorialTextField.getText()) + Double.parseDouble(assignmentTextField.getText()) + Double.parseDouble(attendanceTextField.getText()) + Double.parseDouble(presentationTextField.getText());
            totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_presentationTextFieldKeyReleased

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        // TODO add your handling code here:
        if (mainTable.getEditingColumn() == -1) {
            int i = 0;
            for (i = 0; i < mainTable.getRowCount(); i++) {
                try {

                    Connection connectionObj = DatabaseConnection.getConnectionObject();

                    String sql = "select * from classperformancetable where classTestId = '" + resultIdentification + "' and studentClassRoll='" + clonedexistingClassTest[i][0] + "' and studentExamRoll='" + clonedexistingClassTest[i][1] + "'";
                    System.out.println("sql: " + sql);

                    Statement stmt = connectionObj.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    ResultSet rs = stmt.executeQuery(sql);

                    rs.next();

                    rs.updateString("classTestId", resultIdentification);

                    rs.updateString("studentExamRoll", clonedexistingClassTest[i][0]);

                    rs.updateString("studentExamRoll", clonedexistingClassTest[i][1]);


                    rs.updateString("classTestOne", (String) mainTable.getValueAt(i, 2));

                    rs.updateString("classTestTwo", (String) mainTable.getValueAt(i, 3));

                    rs.updateString("classTestThree", (String) mainTable.getValueAt(i, 4));

                    rs.updateString("classTestFinal", (String) mainTable.getValueAt(i, 5));

                    rs.updateString("classAssignment", (String) mainTable.getValueAt(i, 6));

                    rs.updateString("classAttendance", (String) mainTable.getValueAt(i, 7));

                    rs.updateString("classPresentation", (String) mainTable.getValueAt(i, 8));

                    rs.updateString("total", (String) mainTable.getValueAt(i, 9));

                    rs.updateRow();



                } catch (SQLException ex) {
                    // JOptionPane.showMessageDialog(null, ex.getMessage());
                    //Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (NullPointerException ex) {
                    // JOptionPane.showMessageDialog(null, ex.getMessage());
                    //Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (i == rowCount1) {
                JOptionPane.showMessageDialog(this, "class Test info updated successfully.");
                this.loadTheTable();
            }

        } else {
            JOptionPane.showMessageDialog(this, "Editing item cant be updated.");
        }
}//GEN-LAST:event_updateButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        // TODO add your handling code here:
        Connection connectionObj = DatabaseConnection.getConnectionObject();
        try {
            Statement stmt = connectionObj.createStatement();
            String query = "DELETE FROM classperformancetable where classTestId = '" + resultIdentification + "'";
            int deletedRows = stmt.executeUpdate(query);
            if (deletedRows > 0) {
                System.out.println("Deleted All Rows In The Table Successfully...");
                JOptionPane.showMessageDialog(null, "Deleted All Rows In The Table Successfully...");
                this.loadTheTable();
            } else {
                System.out.println("Table already empty.");
                JOptionPane.showMessageDialog(null, "Table already empty.");
                this.loadTheTable();
            }

        } catch (SQLException s) {
            System.out.println("Deleted All Rows In  Table Error. ");
            s.printStackTrace();
        }


}//GEN-LAST:event_deleteButtonActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // TODO add your handling code here:
        ExaminerOneAccessPanel obj = new ExaminerOneAccessPanel(identification, assignFirstExaminerId, courseId, semesterNo, studentSession);
        this.removeAll();
        BoxLayout boxlayoutObj = new BoxLayout(this, BoxLayout.Y_AXIS);
        this.setLayout(boxlayoutObj);
        this.setPreferredSize(obj.getPreferredSize());
        this.add(obj);
        this.validate();
        this.repaint();
        obj.setVisible(true);
    }//GEN-LAST:event_backButtonActionPerformed

    private void T1TextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_T1TextFieldKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_T1TextFieldKeyReleased

    private void T2TextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_T2TextFieldKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_T2TextFieldKeyReleased

    private void T3TextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_T3TextFieldKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_T3TextFieldKeyReleased

    private void createReportButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createReportButtonActionPerformed
        // TODO add your handling code here:
        Connection connection = null;
        JasperReport jasperReport = null;
        JasperPrint jasperPrint = null;

        try {

            //String reportSource = "C:/Users/Setu/Documents/NetBeansProjects/RPS/src/UI/Report/theoryClassTestReport.jrxml";

            String reportSource = location.TheoryClassTestVerificationReportLocation();

            Map map = new HashMap();
            map.put("resultparam", resultIdentification);
            map.put("teacherNameparam", teacherName);
            map.put("teacherDesignationparam", teacherDesignation);
            map.put("courseIdparam", courseIdTextField.getText());
            map.put("courseNameparam", courseName);
            Class.forName("com.mysql.jdbc.Driver");
            connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/rpsdbms", "root", "");

            jasperReport = (JasperReport) JasperCompileManager.compileReport(reportSource);
            jasperPrint = JasperFillManager.fillReport(jasperReport, map, connection);

            connection.close();

            JasperViewer.viewReport(jasperPrint, false);

        } catch (Exception ex) {
            System.err.println(ex.getMessage());
        }
    }//GEN-LAST:event_createReportButtonActionPerformed

    private void submitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitButtonActionPerformed
        // TODO add your handling code here:
        int response = JOptionPane.showConfirmDialog(null, "Are you want to submit this result?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

        if (response == JOptionPane.NO_OPTION) {
            System.out.println("No button clicked");

        } else if (response == JOptionPane.YES_OPTION) {
            if (mainTable.getEditingColumn() == -1) {
                Connection connectionObj = DatabaseConnection.getConnectionObject();
                int i;
                for (i = 0; i < mainTable.getRowCount(); i++) {


                    String sql = "UPDATE `rpsdbms`.`temptheorygradeexaminedsheet` SET `TutorialMarks` = '" + mainTable.getValueAt(i, 9).toString() + "' WHERE `temptheorygradeexaminedsheet`.`SubmissionId` = '" + adminId + "#" + studentSession + "#" + semesterNo + "#" + courseId + "#" + mainTable.getValueAt(i, 1).toString() + "'";


                    System.out.println(sql);
                    Statement statementObj;

                    try {

                        statementObj = connectionObj.prepareStatement(sql);
                        statementObj.executeUpdate(sql);


                    } catch (SQLException ex) {
                        Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                    }


                }

                if (i == rowCount1) {
                    JOptionPane.showMessageDialog(this, "Class Test info send to admin table successfully.");
                    this.loadTheTable();

                    String sql = "UPDATE  classteststatus SET ClassTestStatus = 'YES' WHERE classTestTagId= '" + examinerOneTagId + "' AND ClassTestSerialId = " + examinerserialId + "";
                    System.out.println(sql);
                    Statement statementObj;

                    try {

                        statementObj = connectionObj.prepareStatement(sql);
                        statementObj.executeUpdate(sql);
                        submitButton.setEnabled(false);

                    } catch (SQLException ex) {
                        Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Class Test info can not send successfully.");
            }

        }

    }//GEN-LAST:event_submitButtonActionPerformed

    public double BestAverage(double v1,double v2,double v3, int number) {
       
        Quicksort quicksort = new Quicksort();

        test[0]=v1;
        test[1]=v2;
        test[2]=v3;
        
        quicksort.quicksort(test, 0, 2);

        int v = 0;

        for (int k = 2; k >= 0; k--) {

            finaltest[v] = test[k];

            System.out.print(test[k] + ",");

            v++;
        }

        double sum = 0;

        for (int i = 0; i < number; i++) {
            sum += finaltest[i];
            System.out.print(test[i]);
        }

        System.out.println();
        System.out.println(sum);
        double avg = sum / number;
        System.out.println(avg);
       
        return avg;

    }

    
    
    public double Average(double t1, double t2, double t3) {
        return (t1 + t2 + t3) / 3;
    }
    
    private void mainTableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mainTableKeyReleased
        // TODO add your handling code here:
        try {

            if(mainTable.getSelectedColumn()==2||mainTable.getSelectedColumn()==3||mainTable.getSelectedColumn()==4){
                String[] options={"Best","Average"};
                int value=JOptionPane.showOptionDialog(null,"Choose an option","Average",0,1, null, options, mainTable);
                
                double v1 = Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 2).toString());
                double v2 = Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 3).toString());
                double v3=Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 4).toString()); 
                
                 if(value==0){
                    
                     int number = 0;


                     try {
                         String num_of_tutorial = javax.swing.JOptionPane.showInputDialog("How many best Tutorial marks\ndo you want to take");
                         number = Integer.parseInt(num_of_tutorial);
                     } catch (NumberFormatException ne) {
                         javax.swing.JOptionPane.showMessageDialog(null, "Bad Format", "Warning Message", javax.swing.JOptionPane.WARNING_MESSAGE);
                         // SetData(new String("0"), i, cols + 1);

                     }

                     if (number <= 3) {
                         mainTable.setValueAt(String.valueOf(BestAverage(v1,v2,v3,number)),mainTable.getSelectedRow(), 5);
                     }else{
                         
                     }
                     
                 }else if(value==1){
                        mainTable.setValueAt(String.valueOf(Average(v1,v2,v3)),mainTable.getSelectedRow(), 5);
                 }
            
            }
            
            double total = Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 5).toString())
                    + Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 6).toString())
                    + Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 7).toString())
                    + Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 8).toString());

            if (total >= 0 && total <= fullmarks) {
                mainTable.setValueAt(String.valueOf(total), mainTable.getSelectedRow(), 9);
            } else {
                JOptionPane.showMessageDialog(null, "Full Marks is out of range");
                mainTable.setValueAt("0.00", mainTable.getSelectedRow(), mainTable.getSelectedColumn());
            }


        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }

    }//GEN-LAST:event_mainTableKeyReleased

    private void convertTableButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_convertTableButtonActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_convertTableButtonActionPerformed

    private void loadTheTable() {
        rowCount1 = 0;
        try {

            for (int i = 0; i < mainTable.getRowCount();) {

                tablemodel.removeRow(i);
            }


            Connection connectionObj = DatabaseConnection.getConnectionObject();
            NewInfoDatabaseRetrivation obj = new NewInfoDatabaseRetrivation(connectionObj);
            ResultSet rs = obj.loadClasstestSheet(resultIdentification);

            System.out.println("E2 :" + resultIdentification);

            while (rs.next()) {

                existingClassTest[rowCount1][0] = rs.getString("studentClassRoll");
                existingClassTest[rowCount1][1] = rs.getString("studentExamRoll");
                //System.out.println("student:"+existingStudents1[rowCount1][0]);
                existingClassTest[rowCount1][2] = rs.getString("classTestOne");
                existingClassTest[rowCount1][3] = rs.getString("classTestTwo");
                existingClassTest[rowCount1][4] = rs.getString("classTestThree");
                existingClassTest[rowCount1][5] = rs.getString("classTestFinal");
                existingClassTest[rowCount1][6] = rs.getString("classAssignment");
                existingClassTest[rowCount1][7] = rs.getString("classAttendance");
                existingClassTest[rowCount1][8] = rs.getString("classPresentation");
                existingClassTest[rowCount1][9] = rs.getString("total");


                String[] rowStrings = {existingClassTest[rowCount1][0], existingClassTest[rowCount1][1], existingClassTest[rowCount1][2], existingClassTest[rowCount1][3], existingClassTest[rowCount1][4], existingClassTest[rowCount1][5], existingClassTest[rowCount1][6], existingClassTest[rowCount1][7], existingClassTest[rowCount1][8], existingClassTest[rowCount1][9]};
                tablemodel.addRow(rowStrings);
                rowCount1++;

            }
            clonedexistingClassTest = existingClassTest.clone();
            countTextField.setText(String.valueOf(rowCount1 + "/" + count));

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Exception :" + ex);

        }
    }

    void fillData(File file) {

        Workbook workbook = null;
        try {
            try {
                workbook = Workbook.getWorkbook(file);
            } catch (IOException ex) {
                Logger.getLogger(ClassTestVerificationPanel.class.getName()).log(Level.SEVERE, null, ex);
            }

            sheetSelection = (int) sheetSpinner.getValue();
            Sheet sheet = workbook.getSheet(sheetSelection);

            headers.clear();
            for (int i = 0; i < sheet.getColumns(); i++) {
                Cell cell1 = sheet.getCell(i, 0);
                headers.add(cell1.getContents());
            }

            data.clear();
            for (int j = 1; j < sheet.getRows(); j++) {
                Vector d = new Vector();
                for (int i = 0; i < sheet.getColumns(); i++) {

                    Cell cell = sheet.getCell(i, j);

                    d.add(cell.getContents());

                }
                d.add("\n");
                data.add(d);
            }
        } catch (BiffException e) {
            e.printStackTrace();
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField T1TextField;
    private javax.swing.JTextField T2TextField;
    private javax.swing.JTextField T3TextField;
    private javax.swing.JTextField assignFirstExaminerIdTextField;
    private javax.swing.JTextField assignmentTextField;
    private javax.swing.JTextField attendanceTextField;
    private javax.swing.JRadioButton averageRadioButton;
    private javax.swing.JButton backButton;
    private javax.swing.JComboBox baseComboBox;
    private javax.swing.JComboBox baseTableComboBox;
    private javax.swing.JRadioButton bestRadioButton;
    private javax.swing.JButton browseExcelButton;
    private javax.swing.JTextField classTestIdTextField;
    private javax.swing.JButton convertButton;
    private javax.swing.JButton convertTableButton;
    private javax.swing.JComboBox convertedComboBox;
    private javax.swing.JComboBox convertedTableComboBox;
    private javax.swing.JTextField countTextField;
    private javax.swing.JTextField courseIdTextField;
    private javax.swing.JButton createReportButton;
    private javax.swing.JButton deleteButton;
    private javax.swing.JTable excelLoadTable;
    private javax.swing.JButton excelsaveButton;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable mainTable;
    private javax.swing.JTextField presentationTextField;
    private javax.swing.JButton saveEntryButton;
    private javax.swing.JSpinner sheetSpinner;
    private javax.swing.JTextField studentClassRollTextField;
    private javax.swing.JTextField studentExamRollTextField;
    private javax.swing.JList studentList;
    private javax.swing.JTextField studentSemesterTextField;
    private javax.swing.JTextField studentSessionTextField;
    private javax.swing.JButton submitButton;
    private javax.swing.JTextField teacherIdTextField;
    private javax.swing.JTextField totalTextField;
    private javax.swing.JComboBox tutorialComboBox;
    private javax.swing.JTextField tutorialTextField;
    private javax.swing.JButton updateButton;
    // End of variables declaration//GEN-END:variables
}
