/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * ErrorousResultCalculationPanel.java
 *
 * Created on Oct 22, 2013, 9:05:09 PM
 */
package UI.Panel;

import Database.DatabaseConnection;
import Database.ReportLocation;
import UI.Database.DatabaseRetrivation;
import UI.Database.NewInfoDatabaseRetrivation;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author SHAHRIAR
 */
public class ErrorousResultCalculationPanel extends javax.swing.JPanel {

    /** Creates new form ErrorousResultCalculationPanel */
    static Vector headers = new Vector();
    NumberFormat nf;
    static DefaultTableModel model = null;
    static DefaultTableModel tablemodel = null;
    static Vector data = new Vector();
    static JFileChooser jChooser;
    static int tableWidth = 0;
    static int tableHeight = 0;
    double[] getDoubleData = new double[100];
    int u, rowCount1;
    private SpinnerModel model1;
    String[][] existingStudents = new String[500][20];
    String[][] existingTheoryFinalMarks = new String[500][20];
    String[][] clonedexistingTheoryFinalMarks = new String[500][20];
    double[][] FirstExaminerMarks = new double[500][10];
    double[][] SecondExaminerMarks = new double[500][10];
    double[][] differences = new double[500][10];
    String[][] errorousStudentExamRolls = new String[500][10];
    double[] errorousFirstExaminerMarks = new double[800];
    double[] errorousSecondExaminerMarks = new double[800];
    double[] errorousThirdExaminerMarks = new double[800];
    double[] errorousDifferences1 = new double[800];
    double[] errorousDifferences2 = new double[800];
    double[] errorousDifferences3 = new double[800];
    double[] averages = new double[800];
    double[] summation=new double[800];
    double[] FinalMarks = new double[800];
    double[] FinalMarks1 = new double[800];
    double[] TutorialMarks = new double[800];
    double[] TotalMarks = new double[800];
    double[] gradepoints = new double[800];
    String[] letters=new String[800];
    String[][] errorousTutorialMarks = new String[500][10];
    String[][] errorousTotal = new String[500][10];
    boolean result, errorousResult;
    JTable Table1;
    private String[][] dataNames;
    private String[] columnNames;
    String courseIdList[] = new String[1000];
    String courseList[] = new String[1000];
    String t[] = new String[100];
    int count, rowCount;
    int marks_per_answer = 100;
    int fullmarks = 100;
    String semesterNo, studentSession, assignlabExaminerId, identification;
    String resultIdentification, assignYear, teacherName, teacherDesignation, courseName, courseId;
    ReportLocation location=new ReportLocation();
    
    
    public ErrorousResultCalculationPanel(String identification, String courseId, String semesterNo, String studentSession) {
        try {

            this.identification = identification;
            this.semesterNo = semesterNo;
            this.studentSession = studentSession;
            this.courseId = courseId;


            jChooser = new JFileChooser();
            model1 = new SpinnerNumberModel(0, 0, 20, 1);

            Connection conn = DatabaseConnection.getConnectionObject();
            DatabaseRetrivation obj = new DatabaseRetrivation(conn);
            ResultSet resultSetObj1 = obj.loadOtherAssignTeacherYear(identification);

            while (resultSetObj1.next()) {
                assignYear = resultSetObj1.getString("adminAssignYear");
            }



            initComponents();

            ResultSet resultSetObj2 = obj.courseNameByCourseId(courseId);

            while (resultSetObj2.next()) {
                courseName = resultSetObj2.getString("courseName");

            }

            ResultSet resultSetObj3 = obj.adminNameDesignationByadminId(identification);

            while (resultSetObj3.next()) {
                teacherName = resultSetObj3.getString("a.teacherName");
                teacherDesignation = resultSetObj3.getString("a.teacherDesignation");
            }

            resultIdentification = "TGS0000" + identification + assignYear + courseId;
            System.out.println(resultIdentification);
            resultIdTextField.setText(resultIdentification);
            studentSessionTextField.setText(studentSession);
            studentSemesterTextField.setText(semesterNo);
            courseIdTextField.setText(courseId);
            courseNameTextField.setText(courseName);

            this.loadTheTable();

        } catch (SQLException ex) {
            Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void loadTheTable() {
        rowCount1 = 0;
        try {

            for (int i = 0; i < mainTable.getRowCount();) {

                tablemodel.removeRow(i);
            }


            Connection connectionObj = DatabaseConnection.getConnectionObject();
            NewInfoDatabaseRetrivation obj = new NewInfoDatabaseRetrivation(connectionObj);
            ResultSet rs = obj.loadErrorousTheoryGradeExaminedSheet(identification,studentSession,semesterNo,courseId);
                           

            while (rs.next()) {
                existingTheoryFinalMarks[rowCount1][0] = rs.getString("studentExamRoll");
                System.out.println("student:" + existingTheoryFinalMarks[rowCount1][0]);
                existingTheoryFinalMarks[rowCount1][1] = rs.getString("firstExaminerMarks");
                existingTheoryFinalMarks[rowCount1][2] = rs.getString("secondExaminerMarks");
                existingTheoryFinalMarks[rowCount1][3] = rs.getString("differences");
                existingTheoryFinalMarks[rowCount1][4] = rs.getString("thirdExaminerMarks");
                existingTheoryFinalMarks[rowCount1][5] = rs.getString("averages");
                existingTheoryFinalMarks[rowCount1][6] = rs.getString("finalMarks");
                existingTheoryFinalMarks[rowCount1][7] = rs.getString("tutorialMarks");
                existingTheoryFinalMarks[rowCount1][8] = rs.getString("total");
                existingTheoryFinalMarks[rowCount1][9] = rs.getString("GPA");
                existingTheoryFinalMarks[rowCount1][10] = rs.getString("LetterGrade");
                

                String[] rowStrings = {existingTheoryFinalMarks[rowCount1][0], existingTheoryFinalMarks[rowCount1][1], existingTheoryFinalMarks[rowCount1][2], existingTheoryFinalMarks[rowCount1][3], existingTheoryFinalMarks[rowCount1][4], existingTheoryFinalMarks[rowCount1][5], existingTheoryFinalMarks[rowCount1][6], existingTheoryFinalMarks[rowCount1][7], existingTheoryFinalMarks[rowCount1][8], existingTheoryFinalMarks[rowCount1][9], existingTheoryFinalMarks[rowCount1][10]};
                tablemodel.addRow(rowStrings);
                rowCount1++; 
                
                

            }

            clonedexistingTheoryFinalMarks = existingTheoryFinalMarks.clone();
            NumberOfStudentTextField.setText(String.valueOf(rowCount1));

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Exception :" + ex);
            Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        mainTable = new javax.swing.JTable(){

            public boolean isCellEditable(int row,int column){

                switch(column){
                    case 0:

                    return false;
                    default:
                    return true;

                }

            }};
            jPanel6 = new javax.swing.JPanel();
            courseIdTextField = new javax.swing.JTextField();
            resultIdTextField = new javax.swing.JTextField();
            studentSessionTextField = new javax.swing.JTextField();
            studentSemesterTextField = new javax.swing.JTextField();
            courseNameTextField = new javax.swing.JTextField();
            actionPanel = new javax.swing.JPanel();
            backButton = new javax.swing.JButton();
            createReportButton = new javax.swing.JButton();
            updateButton = new javax.swing.JButton();
            deleteButton = new javax.swing.JButton();
            updateGradeSheetButton = new javax.swing.JButton();
            NumberOfStudentLabel = new javax.swing.JLabel();
            NumberOfStudentTextField = new javax.swing.JTextField();

            setBackground(new java.awt.Color(89, 13, 23));
            setAutoscrolls(true);

            mainTable.setBackground(new java.awt.Color(198, 244, 245));
            mainTable.setModel(tablemodel=new javax.swing.table.DefaultTableModel(
                new Object [][] {
                    {null, null, null, null, null, null, null, null,null,null},
                    {null, null, null, null, null, null, null, null,null,null},
                    {null, null, null, null, null, null, null, null,null,null},
                    {null, null, null, null, null, null, null, null,null,null}
                },
                new String [] {
                    "Student Exam Roll ", "First Examiner Marks", "Second Examiner Marks", "Differences", "Third Examiner Marks", "Averages", "Final Marks","Tutorial", "Total","GPA","Letter"
                }
            ));
            mainTable.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    mainTableKeyReleased(evt);
                }
            });
            jScrollPane1.setViewportView(mainTable);

            jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Info"));

            courseIdTextField.setEditable(false);

            resultIdTextField.setEditable(false);

            studentSessionTextField.setEditable(false);

            studentSemesterTextField.setEditable(false);

            courseNameTextField.setEditable(false);

            javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
            jPanel6.setLayout(jPanel6Layout);
            jPanel6Layout.setHorizontalGroup(
                jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel6Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(studentSessionTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
                        .addComponent(studentSemesterTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
                        .addComponent(courseNameTextField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
                        .addComponent(resultIdTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
                        .addComponent(courseIdTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE))
                    .addContainerGap())
            );
            jPanel6Layout.setVerticalGroup(
                jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel6Layout.createSequentialGroup()
                    .addComponent(courseIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(resultIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(studentSessionTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(studentSemesterTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(courseNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(19, Short.MAX_VALUE))
            );

            actionPanel.setBackground(new java.awt.Color(26, 60, 26));
            actionPanel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

            backButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            backButton.setText("Back");
            backButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    backButtonActionPerformed(evt);
                }
            });

            createReportButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            createReportButton.setText("Create Report");
            createReportButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    createReportButtonActionPerformed(evt);
                }
            });

            updateButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            updateButton.setText("Update");
            updateButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    updateButtonActionPerformed(evt);
                }
            });

            deleteButton.setFont(new java.awt.Font("Tahoma", 1, 13));
            deleteButton.setText("Delete All");
            deleteButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    deleteButtonActionPerformed(evt);
                }
            });

            updateGradeSheetButton.setFont(new java.awt.Font("Tahoma", 1, 13));
            updateGradeSheetButton.setText("Update Grade Sheet");
            updateGradeSheetButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    updateGradeSheetButtonActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout actionPanelLayout = new javax.swing.GroupLayout(actionPanel);
            actionPanel.setLayout(actionPanelLayout);
            actionPanelLayout.setHorizontalGroup(
                actionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(actionPanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(createReportButton, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(deleteButton, javax.swing.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)
                    .addGap(198, 198, 198)
                    .addComponent(updateGradeSheetButton, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(23, 23, 23))
            );
            actionPanelLayout.setVerticalGroup(
                actionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(actionPanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(actionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(createReportButton, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(updateGradeSheetButton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap())
            );

            NumberOfStudentLabel.setForeground(new java.awt.Color(255, 255, 255));
            NumberOfStudentLabel.setText("Total Student");

            javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
            this.setLayout(layout);
            layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(33, 33, 33)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 874, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(NumberOfStudentLabel)
                            .addGap(27, 27, 27)
                            .addComponent(NumberOfStudentTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(actionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(24, 24, 24))
            );
            layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(35, 35, 35)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(NumberOfStudentTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(NumberOfStudentLabel)))
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(31, 31, 31)
                    .addComponent(actionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(305, Short.MAX_VALUE))
            );
        }// </editor-fold>//GEN-END:initComponents

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // TODO add your handling code here:
        // TODO add your handling code here:
        TheoryGradeSheetVerificationPanel obj = new TheoryGradeSheetVerificationPanel(identification, courseId, semesterNo, studentSession);
        this.removeAll();
        BoxLayout boxlayoutObj = new BoxLayout(this, BoxLayout.Y_AXIS);
        this.setLayout(boxlayoutObj);
        this.setPreferredSize(obj.getPreferredSize());
        this.add(obj);
        this.validate();
        this.repaint();
        obj.setVisible(true);
    }//GEN-LAST:event_backButtonActionPerformed

    
     public double Difference(double a,double b){
         return Math.abs(a-b);
    } 
    
    public double Average(double a,double b,double c){
       return (a+b+c)/3;
    } 
    
    public double Sum(double a,double b,double c){
       return a+b+c;
    }
    
    public double ErrorousFinalMarks(double a,double b,double c){
       return ((a+b+c)-Math.max(a,Math.max(b,c)))/2;
    } 
    
    public double FinalTotalMarks(double a,double b){
       return (a+b);
    }
    
    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        // TODO add your handling code here:
        Connection connectionObj = DatabaseConnection.getConnectionObject();
        int i;
        for (i = 0; i < mainTable.getRowCount(); i++) {
            try {
                errorousFirstExaminerMarks[i] = Double.parseDouble(mainTable.getValueAt(i, 1).toString());
                errorousSecondExaminerMarks[i] = Double.parseDouble(mainTable.getValueAt(i,2).toString());
                errorousThirdExaminerMarks[i] = Double.parseDouble(mainTable.getValueAt(i, 4).toString());
               
                averages[i]=Average( errorousFirstExaminerMarks[i],errorousSecondExaminerMarks[i],errorousThirdExaminerMarks[i]);
                System.out.println(averages[i]);
                summation[i]=Sum(errorousFirstExaminerMarks[i],errorousSecondExaminerMarks[i],errorousThirdExaminerMarks[i]); 
                System.out.println(summation[i]);
                FinalMarks[i]= ErrorousFinalMarks(errorousFirstExaminerMarks[i],errorousSecondExaminerMarks[i],errorousThirdExaminerMarks[i]);
                System.out.println(FinalMarks[i]);
                TutorialMarks[i]=Double.parseDouble(mainTable.getValueAt(i,7).toString());
              
                TotalMarks[i]=FinalTotalMarks(TutorialMarks[i],FinalMarks[i]); 
                
                gradepoints[i]=gradeCalculate(TotalMarks[i]);
                letters[i]=letterCalculate(TotalMarks[i]);
                
               /* String sql="update theorygradeexaminedsheet set "
                        + "averages='"+averages[i]+"'"
                        + ",finalMarks='"+FinalMarks[i]
                        + "',total='"+TotalMarks[i]+"' "
                        + ",GPA ='"+gradepoints[i]+"', "
                        + " LetterGrade='"+letters[i]+"' where theoryGradeExaminedId='"+resultIdentification+"' and studentExamRoll='"+mainTable.getValueAt(i,0)+"' and status='Error'" ;
                
                
                System.out.println(sql);
                
               
                Statement statementObj;

                    try {

                        statementObj = connectionObj.prepareStatement(sql);
                        statementObj.executeUpdate(sql);


                    } catch (SQLException ex) {
                        Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                    }*/ 
                
                        String sql = "select * from theorygradeexaminedsheet where theoryGradeExaminedId = '" + resultIdentification + "' and studentExamRoll='"+mainTable.getValueAt(i,0)+"' AND status='Error'";
                        
                        System.out.println("sql: " + sql);

                        Statement stmt = connectionObj.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                        ResultSet rs = stmt.executeQuery(sql);


                        rs.next();

                        rs.updateString("theoryGradeExaminedId", resultIdentification);

                        rs.updateString("studentExamRoll", (String) mainTable.getValueAt(i, 0));

                        rs.updateString("firstExaminerMarks", (String) mainTable.getValueAt(i, 1));

                        rs.updateString("secondExaminerMarks", (String) mainTable.getValueAt(i, 2));

                        rs.updateString("differences", (String) mainTable.getValueAt(i, 3)); 
                        
                        rs.updateString("thirdExaminerMarks", (String) mainTable.getValueAt(i, 4));

                        rs.updateString("averages", String.valueOf(averages[i]));

                        rs.updateString("finalMarks", String.valueOf(FinalMarks[i]));

                        rs.updateString("tutorialMarks", (String) mainTable.getValueAt(i, 7));

                        rs.updateString("total", String.valueOf(TotalMarks[i]));
                        
                        rs.updateString("GPA", String.valueOf(gradepoints[i])); 
                        
                        rs.updateString("LetterGrade",letters[i]);

                        rs.updateRow(); 
                        
            } catch (SQLException ex) {
                Logger.getLogger(ErrorousResultCalculationPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        
        if(i==rowCount1){
          JOptionPane.showMessageDialog(null,"Final Marks inserted sucessfully");
          this.loadTheTable();
        }
    }//GEN-LAST:event_updateButtonActionPerformed

    public double gradeCalculate(double value) {

        if (value <= 100 && value >= 80) {
            return 4.00;

        } else if (value <= 79.99 && value >= 75) {
            return 3.75;

        } else if (value <= 74.99 && value >= 70) {
            return 3.50;

        } else if (value <= 69.99 && value >= 65) {
            return 3.25;

        } else if (value <= 64.99 && value >= 60) {
            return 3.00;

        } else if (value <= 59.99 && value >= 55) {
            return 2.75;

        } else if (value <= 54.99 && value >= 50) {
            return 2.50;

        } else if (value <= 49.99 && value >= 45) {
            return 2.25;

        } else if (value <= 44.99 && value >= 40) {
            return 2.00;

        } else {
            return 0.00;

        }
    }
  
    public String letterCalculate(double value) {
        if (value <= 100 && value >= 80) {

            return "A+";
        } else if (value <= 79.99 && value >= 75) {

            return "A";
        } else if (value <= 74.99 && value >= 70) {

            return "A-";
        } else if (value <= 69.99 && value >= 65) {

            return "B+";
        } else if (value <= 64.99 && value >= 60) {

            return "B";
        } else if (value <= 59.99 && value >= 55) {

            return "B-";
        } else if (value <= 54.99 && value >= 50) {

            return "C+";
        } else if (value <= 49.99 && value >= 45) {

            return "C";
        } else if (value <= 44.99 && value >= 40) {

            return "D";
        } else {

            return "F";
        }

    } 
    
    
    private void createReportButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createReportButtonActionPerformed
        // TODO add your handling code here:
        Connection connection = null;
        JasperReport jasperReport = null;
        JasperPrint jasperPrint = null;
        
        try {
            
            
            //String reportSource = "C:/Users/SHAHRIAR/Documents/NetBeansProjects/RPS/src/UI/Report/ErrorousTheoryGradeReport.jrxml";
            
            String reportSource=location.ErrorousTheoryGradeSheetReportLocation();
            
            Map map = new HashMap();
            map.put("resultparam",resultIdentification); 
            map.put("statusparam","Error");
            map.put("teacherNameparam",teacherName);
            map.put("teacherDesignationparam",teacherDesignation);
            map.put("courseIdparam",courseIdTextField.getText());
            map.put("courseNameparam",courseName);
            Class.forName("com.mysql.jdbc.Driver");
            connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/rpsdbms", "root", "");
            
            jasperReport = (JasperReport) JasperCompileManager.compileReport(reportSource);
            jasperPrint = JasperFillManager.fillReport(jasperReport, map, connection);
            
            connection.close();
            
            JasperViewer.viewReport(jasperPrint, false);
            
        } catch (Exception ex) {
            System.err.println(ex.getMessage());
        }
    }//GEN-LAST:event_createReportButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
       // TODO add your handling code here:
         Connection connectionObj = DatabaseConnection.getConnectionObject();
        try {
            Statement stmt = connectionObj.createStatement();
            String query = "DELETE FROM theorygradeexaminedsheet where theoryGradeExaminedId = '" + resultIdentification + "' AND status='Error'";
            int deletedRows = stmt.executeUpdate(query);
            if (deletedRows > 0) {
                System.out.println("Deleted All Rows In The Table Successfully...");
                JOptionPane.showMessageDialog(null, "Deleted All Rows In The Table Successfully...");
                this.loadTheTable();
            } else {
                System.out.println("Table already empty.");
                JOptionPane.showMessageDialog(null, "Table already empty.");
                this.loadTheTable();
            }

        } catch (SQLException s) {
            System.out.println("Deleted All Rows In  Table Error. ");
            s.printStackTrace();
        }
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void updateGradeSheetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateGradeSheetButtonActionPerformed
        // TODO add your handling code here: 
          Connection connectionObj = DatabaseConnection.getConnectionObject();
        char lastdigitofcI = courseId.charAt(courseId.length() - 1);
        char secondlastdigitofcI = courseId.charAt(courseId.length() - 2);

        if (secondlastdigitofcI == '0' && lastdigitofcI == '1') {

            System.out.println("YES 01");
            for (int i = 0; i < mainTable.getRowCount(); i++) {
                String sql = "UPDATE `rpsdbms`.`finalgradesheet` SET "
                        + "`Subject1Examiner1` = '" + mainTable.getValueAt(i, 1) + "',"
                        + "`Subject1Examiner2` = '" + mainTable.getValueAt(i, 2) + "',"
                        + "`Subject1Examiner3` = '" + mainTable.getValueAt(i, 4) + "',"
                        + "`Subject1Average` = '" + mainTable.getValueAt(i, 6) + "',"
                        + "`Subject1Tutorial`='" + mainTable.getValueAt(i, 7) + "',"
                        + "`Subject1Total` = '" + mainTable.getValueAt(i, 8) + "',"
                        + "`Subject1GPA` = '" + mainTable.getValueAt(i, 9) + "' "
                        + "WHERE `finalgradesheet`.`adminId` = '" + identification + "' AND `finalgradesheet`.`studentSession` = '" + studentSession + "' AND `finalgradesheet`.`semesterNo` = '" + semesterNo + "' AND `finalgradesheet`.`studentExamRoll` = '" + mainTable.getValueAt(i, 0) + "'";

                      System.out.println(sql);
                
                Statement statementObj;

                try {

                    statementObj = connectionObj.prepareStatement(sql);
                    statementObj.executeUpdate(sql);


                } catch (SQLException ex) {
                    Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }



            }

        } else if (secondlastdigitofcI == '0' && lastdigitofcI == '3') { 
             for (int i = 0; i < mainTable.getRowCount(); i++) {
                String sql = "UPDATE `rpsdbms`.`finalgradesheet` SET "
                        + "`Subject2Examiner1` = '" + mainTable.getValueAt(i, 1) + "',"
                        + "`Subject2Examiner2` = '" + mainTable.getValueAt(i, 2) + "',"
                        + "`Subject2Examiner3` = '" + mainTable.getValueAt(i, 4) + "',"
                        + "`Subject2Average` = '" + mainTable.getValueAt(i, 6) + "',"
                        + "`Subject2Tutorial`='" + mainTable.getValueAt(i, 7) + "',"
                        + "`Subject2Total` = '" + mainTable.getValueAt(i, 8) + "',"
                        + "`Subject2GPA` = '" + mainTable.getValueAt(i, 9) + "' "
                        + "WHERE `finalgradesheet`.`adminId` = '" + identification + "' AND `finalgradesheet`.`studentSession` = '" + studentSession + "' AND `finalgradesheet`.`semesterNo` = '" + semesterNo + "' AND `finalgradesheet`.`studentExamRoll` = '" + mainTable.getValueAt(i, 0) + "'";


                      System.out.println(sql);

                Statement statementObj;

                try {

                    statementObj = connectionObj.prepareStatement(sql);
                    statementObj.executeUpdate(sql);


                } catch (SQLException ex) {
                    Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }



            }
            
        } else if (secondlastdigitofcI == '0' && lastdigitofcI == '5') {
             for (int i = 0; i < mainTable.getRowCount(); i++) {
                String sql = "UPDATE `rpsdbms`.`finalgradesheet` SET "
                        + "`Subject3Examiner1` = '" + mainTable.getValueAt(i, 1) + "',"
                        + "`Subject3Examiner2` = '" + mainTable.getValueAt(i, 2) + "',"
                        + "`Subject3Examiner3` = '" + mainTable.getValueAt(i, 4) + "',"
                        + "`Subject3Average` = '" + mainTable.getValueAt(i, 6) + "',"
                        + "`Subject3Tutorial`='" + mainTable.getValueAt(i, 7) + "',"
                        + "`Subject3Total` = '" + mainTable.getValueAt(i, 8) + "',"
                        + "`Subject3GPA` = '" + mainTable.getValueAt(i, 9) + "' "
                        + "WHERE `finalgradesheet`.`adminId` = '" + identification + "' AND `finalgradesheet`.`studentSession` = '" + studentSession + "' AND `finalgradesheet`.`semesterNo` = '" + semesterNo + "' AND `finalgradesheet`.`studentExamRoll` = '" + mainTable.getValueAt(i, 0) + "'";


                      System.out.println(sql);

                Statement statementObj;

                try {

                    statementObj = connectionObj.prepareStatement(sql);
                    statementObj.executeUpdate(sql);


                } catch (SQLException ex) {
                    Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }



            }
        } else if (secondlastdigitofcI == '0' && lastdigitofcI == '7') { 
             for (int i = 0; i < mainTable.getRowCount(); i++) {
                String sql = "UPDATE `rpsdbms`.`finalgradesheet` SET "
                        + "`Subject4Examiner1` = '" + mainTable.getValueAt(i, 1) + "',"
                        + "`Subject4Examiner2` = '" + mainTable.getValueAt(i, 2) + "',"
                        + "`Subject4Examiner3` = '" + mainTable.getValueAt(i, 4) + "',"
                        + "`Subject4Average` = '" + mainTable.getValueAt(i, 6) + "',"
                        + "`Subject4Tutorial`='" + mainTable.getValueAt(i, 7) + "',"
                        + "`Subject4Total` = '" + mainTable.getValueAt(i, 8) + "',"
                        + "`Subject4GPA` = '" + mainTable.getValueAt(i, 9) + "' "
                        + "WHERE `finalgradesheet`.`adminId` = '" + identification + "' AND `finalgradesheet`.`studentSession` = '" + studentSession + "' AND `finalgradesheet`.`semesterNo` = '" + semesterNo + "' AND `finalgradesheet`.`studentExamRoll` = '" + mainTable.getValueAt(i, 0) + "'";


                      System.out.println(sql);

                Statement statementObj;

                try {

                    statementObj = connectionObj.prepareStatement(sql);
                    statementObj.executeUpdate(sql);


                } catch (SQLException ex) {
                    Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }



            }
        } else if (secondlastdigitofcI == '0' && lastdigitofcI == '9') { 
             for (int i = 0; i < mainTable.getRowCount(); i++) {
                String sql = "UPDATE `rpsdbms`.`finalgradesheet` SET "
                        + "`Subject5Examiner1` = '" + mainTable.getValueAt(i, 1) + "',"
                        + "`Subject5Examiner2` = '" + mainTable.getValueAt(i, 2) + "',"
                        + "`Subject5Examiner3` = '" + mainTable.getValueAt(i, 4) + "',"
                        + "`Subject5Average` = '" + mainTable.getValueAt(i, 6) + "',"
                        + "`Subject5Tutorial`='" + mainTable.getValueAt(i, 7) + "',"
                        + "`Subject5Total` = '" + mainTable.getValueAt(i, 8) + "',"
                        + "`Subject5GPA` = '" + mainTable.getValueAt(i, 9) + "' "
                        + "WHERE `finalgradesheet`.`adminId` = '" + identification + "' AND `finalgradesheet`.`studentSession` = '" + studentSession + "' AND `finalgradesheet`.`semesterNo` = '" + semesterNo + "' AND `finalgradesheet`.`studentExamRoll` = '" + mainTable.getValueAt(i, 0) + "'";


                      System.out.println(sql);

                Statement statementObj;

                try {

                    statementObj = connectionObj.prepareStatement(sql);
                    statementObj.executeUpdate(sql);


                } catch (SQLException ex) {
                    Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }



            }
        } else if (secondlastdigitofcI == '1' && lastdigitofcI == '1') { 
        } else if (secondlastdigitofcI == '1' && lastdigitofcI == '3') {
        } else if (secondlastdigitofcI == '1' && lastdigitofcI == '5') {
        } else if (secondlastdigitofcI == '1' && lastdigitofcI == '7') { 
             for (int i = 0; i < mainTable.getRowCount(); i++) {
                String sql = "UPDATE `rpsdbms`.`finalgradesheet` SET "
                        + "`Subject6Examiner1` = '" + mainTable.getValueAt(i, 1) + "',"
                        + "`Subject6Examiner2` = '" + mainTable.getValueAt(i, 2) + "',"
                        + "`Subject6Examiner3` = '" + mainTable.getValueAt(i, 4) + "',"
                        + "`Subject6Average` = '" + mainTable.getValueAt(i, 6) + "',"
                        + "`Subject6Tutorial`='" + mainTable.getValueAt(i, 7) + "',"
                        + "`Subject6Total` = '" + mainTable.getValueAt(i, 8) + "',"
                        + "`Subject6GPA` = '" + mainTable.getValueAt(i, 9) + "' "
                        + "WHERE `finalgradesheet`.`adminId` = '" + identification + "' AND `finalgradesheet`.`studentSession` = '" + studentSession + "' AND `finalgradesheet`.`semesterNo` = '" + semesterNo + "' AND `finalgradesheet`.`studentExamRoll` = '" + mainTable.getValueAt(i, 0) + "'";


                      System.out.println(sql);

                Statement statementObj;

                try {

                    statementObj = connectionObj.prepareStatement(sql);
                    statementObj.executeUpdate(sql);


                } catch (SQLException ex) {
                    Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }



            }
        } else if (secondlastdigitofcI == '1' && lastdigitofcI == '9') {
        } else if (secondlastdigitofcI == '2' && lastdigitofcI == '1') {
        } else if (secondlastdigitofcI == '2' && lastdigitofcI == '3') {
        } else if (secondlastdigitofcI == '2' && lastdigitofcI == '5') {
        } else if (secondlastdigitofcI == '2' && lastdigitofcI == '7') {
        } else if (secondlastdigitofcI == '2' && lastdigitofcI == '9') {
        } else if (secondlastdigitofcI == '3' && lastdigitofcI == '1') {
        } else if (secondlastdigitofcI == '3' && lastdigitofcI == '3') {
        } else if (secondlastdigitofcI == '3' && lastdigitofcI == '5') {
        } else if (secondlastdigitofcI == '3' && lastdigitofcI == '7') {
        } else if (secondlastdigitofcI == '3' && lastdigitofcI == '9') {
        } else if (secondlastdigitofcI == '4' && lastdigitofcI == '1') {
        } else if (secondlastdigitofcI == '4' && lastdigitofcI == '3') {
        } else if (secondlastdigitofcI == '4' && lastdigitofcI == '5') {
        } else if (secondlastdigitofcI == '4' && lastdigitofcI == '7') {
        } else if (secondlastdigitofcI == '4' && lastdigitofcI == '9') {
        } else if (secondlastdigitofcI == '5' && lastdigitofcI == '1') {
        } else if (secondlastdigitofcI == '5' && lastdigitofcI == '3') {
        } else if (secondlastdigitofcI == '5' && lastdigitofcI == '5') {
        } else if (secondlastdigitofcI == '5' && lastdigitofcI == '7') {
        } else if (secondlastdigitofcI == '5' && lastdigitofcI == '9') {
        } else if (secondlastdigitofcI == '6' && lastdigitofcI == '1') {
        } else if (secondlastdigitofcI == '6' && lastdigitofcI == '3') {
        } else if (secondlastdigitofcI == '6' && lastdigitofcI == '5') {
        } else if (secondlastdigitofcI == '6' && lastdigitofcI == '7') {
        } else if (secondlastdigitofcI == '4' && lastdigitofcI == '9') {
        }
    }//GEN-LAST:event_updateGradeSheetButtonActionPerformed

    
    public void changeValue(double difference, double average, double finalmarks, double total, double grade, String letter) {
        mainTable.setValueAt(String.valueOf(difference), mainTable.getSelectedRow(), 3);
        mainTable.setValueAt(String.valueOf(average), mainTable.getSelectedRow(), 5);
        mainTable.setValueAt(String.valueOf(finalmarks), mainTable.getSelectedRow(), 6);
        mainTable.setValueAt(String.valueOf(total), mainTable.getSelectedRow(), 8);
        mainTable.setValueAt(String.valueOf(grade), mainTable.getSelectedRow(), 9);
        mainTable.setValueAt(letter, mainTable.getSelectedRow(), 10);
    }
    
    private void mainTableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mainTableKeyReleased
        // TODO add your handling code here:
         try {
             
            double value1=Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 1).toString()); 
            double value2=Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 2).toString()); 
            double value3=Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 4).toString()); 
            double tutorial=Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 7).toString());
            
            double difference=Difference(value1,value2);

            double average=Average(value1,value2,value3);
            
            double finalmarks = ErrorousFinalMarks(value1,value2,value3);
             
            double total = FinalTotalMarks(finalmarks,tutorial);
            
           
            if (total >= 0 && total <= fullmarks) {
               
                double grade = gradeCalculate(total);
                String letter = letterCalculate(total);
                changeValue(difference,average,finalmarks,total,grade,letter);
                  
            } else {
                JOptionPane.showMessageDialog(null, "Full Marks is out of range");
                 mainTable.setValueAt("0.00", mainTable.getSelectedRow(),mainTable.getSelectedColumn());
            }


        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
    }//GEN-LAST:event_mainTableKeyReleased

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel NumberOfStudentLabel;
    private javax.swing.JTextField NumberOfStudentTextField;
    private javax.swing.JPanel actionPanel;
    private javax.swing.JButton backButton;
    private javax.swing.JTextField courseIdTextField;
    private javax.swing.JTextField courseNameTextField;
    private javax.swing.JButton createReportButton;
    private javax.swing.JButton deleteButton;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable mainTable;
    private javax.swing.JTextField resultIdTextField;
    private javax.swing.JTextField studentSemesterTextField;
    private javax.swing.JTextField studentSessionTextField;
    private javax.swing.JButton updateButton;
    private javax.swing.JButton updateGradeSheetButton;
    // End of variables declaration//GEN-END:variables
}
