/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * FinalExamTwoResultPanel.java
 *
 * Created on Oct 18, 2013, 7:10:40 PM
 */
package UI.Panel;

import Database.DatabaseConnection;
import Database.ReportLocation;
import UI.Database.DatabaseInsertion;
import UI.Database.DatabaseRetrivation;
import UI.Database.NewInfoDatabaseRetrivation;
import java.awt.Dimension;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

public class FinalExamTwoResultPanel extends javax.swing.JPanel {

      static Vector headers = new Vector();
    // Model is used to construct JTable
    static DefaultTableModel model = null;
    static DefaultTableModel tablemodel = null;
    // data is Vector contains Data from Excel File
    static Vector data = new Vector();
    static JFileChooser jChooser;
    static int tableWidth = 0; // set the tableWidth
    static int tableHeight = 0;
    int u,rowCount1;
    private SpinnerModel model1;
    String[][] existingStudents = new String[500][10];
    String[][] existingExaminerTwoMarks = new String[500][10];
    String[][] clonedexistingExaminerOneMarks = new String[500][10];
    boolean result;
    JTable Table1;
    private String[][] dataNames;
    private String[] columnNames;
    String s[]=new String[1000];
    String t[]=new String[100]; 
    String examinerTwoTagId;
    int examinerserialId; 
    int count;
    int marks_per_answer=12;
    int fullmarks=60;
    String courseId,semesterNo,studentSession,assignSecondExaminerId,identification,courseName,teacherName,teacherDesignation;
    String resultIdentification,adminId,status;
    ReportLocation location=new ReportLocation();
    
    public FinalExamTwoResultPanel(String identification,String assignSecondExaminerId,String courseId,String semesterNo,String studentSession) {
        try {
           
            this.identification = identification;
            this.courseId = courseId;
            this.semesterNo = semesterNo;
            this.studentSession = studentSession;
            this.assignSecondExaminerId = assignSecondExaminerId;
            
            jChooser = new JFileChooser();
            model1 = new SpinnerNumberModel(0, 0, 20, 1);
            
            Connection conn = DatabaseConnection.getConnectionObject();
            DatabaseRetrivation obj = new DatabaseRetrivation(conn);
            
            String sql1="select concat(examinerTwoTagId,examinerserialId) as secondExaminerId from secondexaminedstatus where assignId='"+assignSecondExaminerId+"'";
            Statement stmt1 = conn.prepareStatement(sql1);
            ResultSet rs1 = stmt1.executeQuery(sql1);
            
              while (rs1.next()) {
                  resultIdentification = rs1.getString("secondExaminerId");
                  System.out.println("E1:"+resultIdentification);
              }
 
           String sql4 = "select examinerTwoTagId,examinerserialId from secondexaminedstatus where assignId='" + assignSecondExaminerId + "'";
           Statement stmt4 = conn.prepareStatement(sql4);
           ResultSet rs4 = stmt1.executeQuery(sql4);

           while (rs4.next()) {
               examinerTwoTagId = rs4.getString("examinerTwoTagId");
               System.out.println(examinerTwoTagId);
               examinerserialId = rs4.getInt("examinerserialId");
               System.out.println(examinerserialId);
           }
              
              
              
            String sql = "select studentExamRoll from student where studentSemester='"+semesterNo+"'";
            System.out.println(sql);

          
            Statement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {

                s[count] = rs.getString("studentExamRoll");
                System.out.println(rs.getString("studentExamRoll"));
                count++;
            } 
            
            
            
            String sql2 = "select distinct adminId from temptheorygradeexaminedsheet where studentSession='"+studentSession+"' and semesterNo='"+semesterNo+"' and courseId='"+courseId+"'";
            System.out.println(sql2);
            
             ResultSet rs2 = stmt.executeQuery(sql2);
             
             while(rs2.next()){
                adminId=rs2.getString("adminId");
             }

            initComponents();
            teacherIdTextField.setText(courseId);
            courseIdTextField.setText(identification); 
            studentSessionTextField.setText(studentSession); 
            studentSemesterTextField.setText(semesterNo); 
            assignSecondExaminerIdTextField.setText(assignSecondExaminerId); 
            secondExaminerIdTextField.setText(resultIdentification);
            
            
             ResultSet resultSetObj2 = obj.courseNameByCourseId(courseId);

            while (resultSetObj2.next()) {
               courseName=resultSetObj2.getString("courseName");
            }
            
            
             ResultSet resultSetObj3 = obj.teacherNameteacherDesignationByteacherId(identification); 
             
            
             while (resultSetObj3.next()) {

                teacherName = resultSetObj3.getString("teacherName");
                teacherDesignation=resultSetObj3.getString("teacherDesignation");
            }

            
             //checking status about teacher verification after submission
             
           String statussql = "select ExaminerTwoStatus from secondexaminedstatus where assignId='" + assignSecondExaminerId + "'";
           System.out.println(statussql);
           Statement stmt3 = conn.prepareStatement(statussql);
           ResultSet rs3 = stmt3.executeQuery(statussql);
           while(rs3.next()){
                 status=rs3.getString("ExaminerTwoStatus");
                 
           } 
           
           
          System.out.println(status); 
          if(status.equals("YES")){ 
              submitButton.setEnabled(false); 
           }else{
              System.out.println("Sorry"); 
           }
             
             
            studentList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            studentList.addListSelectionListener(new ListSelectionListener() {

                @Override
                public void valueChanged(ListSelectionEvent e) {
                    int idx = studentList.getSelectedIndex();
                    studentExamRollTextField.setText(String.valueOf(studentList.getSelectedValue()));

                }
            });
            
          this.loadTheTable();
     
        } catch (SQLException ex) {
            Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        excelTable = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        courseIdTextField = new javax.swing.JTextField();
        teacherIdTextField = new javax.swing.JTextField();
        studentSessionTextField = new javax.swing.JTextField();
        studentSemesterTextField = new javax.swing.JTextField();
        assignSecondExaminerIdTextField = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        selectExcelButton = new javax.swing.JButton();
        jSpinner1 = new javax.swing.JSpinner(model1);
        excelSaveButton = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        studentList = new javax.swing.JList(s);
        jPanel3 = new javax.swing.JPanel();
        saveButton = new javax.swing.JButton();
        createReportButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        submitButton = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        studentExamRollTextField = new javax.swing.JTextField();
        oneTextField = new javax.swing.JTextField(0);
        sixTextField = new javax.swing.JTextField(0);
        fiveTextField = new javax.swing.JTextField(0);
        fourTextField = new javax.swing.JTextField(0);
        twoTextField = new javax.swing.JTextField(0);
        sevenTextField = new javax.swing.JTextField(0);
        eightTextField = new javax.swing.JTextField(0);
        threeTextField = new javax.swing.JTextField(0);
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        totalTextField = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        mainTable = new javax.swing.JTable(){

            public boolean isCellEditable(int row,int column){

                switch(column){
                    case 0:
                    case 9:
                    return false;
                    default:
                    return true;

                }

            }}
            ;
            secondExaminerIdTextField = new javax.swing.JTextField();
            countTextField = new javax.swing.JTextField();

            setBackground(new java.awt.Color(89, 13, 23));

            excelTable.setBackground(new java.awt.Color(198, 244, 245));
            excelTable.setModel(new javax.swing.table.DefaultTableModel(
                new Object [][] {
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null}
                },
                new String [] {
                    "Student Exam Roll", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "eight"
                }
            ));
            jScrollPane1.setViewportView(excelTable);

            jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Info"));

            courseIdTextField.setEditable(false);

            teacherIdTextField.setEditable(false);

            studentSessionTextField.setEditable(false);

            studentSemesterTextField.setEditable(false);

            assignSecondExaminerIdTextField.setEditable(false);

            javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
            jPanel6.setLayout(jPanel6Layout);
            jPanel6Layout.setHorizontalGroup(
                jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel6Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(teacherIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(courseIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(studentSessionTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                        .addComponent(studentSemesterTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                        .addComponent(assignSecondExaminerIdTextField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE))
                    .addContainerGap())
            );
            jPanel6Layout.setVerticalGroup(
                jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel6Layout.createSequentialGroup()
                    .addComponent(courseIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(teacherIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(studentSessionTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(studentSemesterTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(assignSecondExaminerIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(19, Short.MAX_VALUE))
            );

            jPanel1.setBackground(new java.awt.Color(26, 60, 26));
            jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

            selectExcelButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            selectExcelButton.setText("select Excel file");
            selectExcelButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    selectExcelButtonActionPerformed(evt);
                }
            });

            excelSaveButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            excelSaveButton.setText("save");
            excelSaveButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    excelSaveButtonActionPerformed(evt);
                }
            });

            updateButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            updateButton.setText("Update");
            updateButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    updateButtonActionPerformed(evt);
                }
            });

            deleteButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            deleteButton.setText("Delete All");
            deleteButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    deleteButtonActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
            jPanel1.setLayout(jPanel1Layout);
            jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(26, 26, 26)
                    .addComponent(selectExcelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(31, 31, 31)
                    .addComponent(excelSaveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(703, Short.MAX_VALUE))
            );
            jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap(14, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(excelSaveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(selectExcelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap())
            );

            studentList.setFont(new java.awt.Font("Times New Roman", 0, 24));
            studentList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
            jScrollPane4.setViewportView(studentList);

            jPanel3.setBackground(new java.awt.Color(26, 60, 26));
            jPanel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

            saveButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            saveButton.setText("Save Entry");
            saveButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    saveButtonActionPerformed(evt);
                }
            });

            createReportButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            createReportButton.setText("Create Report");
            createReportButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    createReportButtonActionPerformed(evt);
                }
            });

            backButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            backButton.setText("Back");
            backButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    backButtonActionPerformed(evt);
                }
            });

            submitButton.setText("Submit");
            submitButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    submitButtonActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
            jPanel3.setLayout(jPanel3Layout);
            jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGap(98, 98, 98)
                    .addComponent(saveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(createReportButton, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(submitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(340, Short.MAX_VALUE))
            );
            jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGap(19, 19, 19)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(createReportButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(saveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(submitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );

            jPanel2.setBackground(new java.awt.Color(153, 153, 0));
            jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

            studentExamRollTextField.setEditable(false);

            oneTextField.setText("0");
            oneTextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    oneTextFieldKeyReleased(evt);
                }
            });

            sixTextField.setText("0");
            sixTextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    sixTextFieldKeyReleased(evt);
                }
            });

            fiveTextField.setText("0");
            fiveTextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    fiveTextFieldKeyReleased(evt);
                }
            });

            fourTextField.setText("0");
            fourTextField.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    fourTextFieldActionPerformed(evt);
                }
            });
            fourTextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    fourTextFieldKeyReleased(evt);
                }
            });

            twoTextField.setText("0");
            twoTextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    twoTextFieldKeyReleased(evt);
                }
            });

            sevenTextField.setText("0");
            sevenTextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    sevenTextFieldKeyReleased(evt);
                }
            });

            eightTextField.setText("0");
            eightTextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    eightTextFieldKeyReleased(evt);
                }
            });

            threeTextField.setText("0");
            threeTextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    threeTextFieldKeyReleased(evt);
                }
            });

            jLabel2.setText("Student Exam Roll");

            jLabel3.setText("Two");

            jLabel4.setText("One");

            jLabel5.setText("Three");

            jLabel6.setText("Four");

            jLabel7.setText("Five");

            jLabel8.setText("Six");

            jLabel9.setText("Eight");

            jLabel10.setText("Seven");

            totalTextField.setEditable(false);
            totalTextField.setText("0");

            jLabel11.setText("Total");

            javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
            jPanel2.setLayout(jPanel2Layout);
            jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel2)
                        .addComponent(studentExamRollTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGap(26, 26, 26)
                            .addComponent(oneTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGap(54, 54, 54)
                            .addComponent(jLabel4)))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGap(35, 35, 35)
                            .addComponent(jLabel3)
                            .addGap(54, 54, 54)
                            .addComponent(jLabel5)
                            .addGap(66, 66, 66)
                            .addComponent(jLabel6)
                            .addGap(63, 63, 63)
                            .addComponent(jLabel7)
                            .addGap(67, 67, 67)
                            .addComponent(jLabel8)
                            .addGap(59, 59, 59)
                            .addComponent(jLabel10)
                            .addGap(60, 60, 60)
                            .addComponent(jLabel9)
                            .addGap(72, 72, 72)
                            .addComponent(jLabel11))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGap(13, 13, 13)
                            .addComponent(twoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(threeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(fourTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(fiveTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(sixTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(sevenTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(eightTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(totalTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addContainerGap(101, Short.MAX_VALUE))
            );
            jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(jLabel4)
                        .addComponent(jLabel3)
                        .addComponent(jLabel5)
                        .addComponent(jLabel6)
                        .addComponent(jLabel7)
                        .addComponent(jLabel8)
                        .addComponent(jLabel10)
                        .addComponent(jLabel9)
                        .addComponent(jLabel11))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(studentExamRollTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(oneTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(twoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(threeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(fourTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(fiveTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(sixTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(sevenTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(eightTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(totalTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );

            mainTable.setBackground(new java.awt.Color(198, 244, 245));
            mainTable.setModel(tablemodel=new javax.swing.table.DefaultTableModel(
                new Object [][] {
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null},
                    {null, null, null, null, null, null, null, null, null, null}
                },
                new String [] {
                    "Student Exam Roll", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Total"
                }
            ));
            mainTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
            mainTable.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    mainTableKeyReleased(evt);
                }
            });
            jScrollPane2.setViewportView(mainTable);

            secondExaminerIdTextField.setEditable(false);

            countTextField.setEditable(false);

            javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
            this.setLayout(layout);
            layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(28, 28, 28)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(secondExaminerIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(countTextField)))
                                        .addGap(46, 46, 46))
                                    .addComponent(jScrollPane1)))
                            .addGap(18, 18, 18)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );
            layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(44, 44, 44)
                    .addComponent(secondExaminerIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 346, Short.MAX_VALUE)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(26, 26, 26)
                                            .addComponent(countTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                    .addContainerGap())
            );
        }// </editor-fold>//GEN-END:initComponents

    private void selectExcelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectExcelButtonActionPerformed
        // TODO add your handling code here:
        jChooser.showOpenDialog(null);
        
        try{
            
            File file = jChooser.getSelectedFile();
            if (!file.getName().endsWith("xls")) {
                JOptionPane.showMessageDialog(null,"Please select only Excel file.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                fillData(file);
                model = new DefaultTableModel(data,headers);
                tableWidth = model.getColumnCount()* 150;
                tableHeight = model.getRowCount()* 25;
                excelTable.setPreferredSize(new Dimension(tableWidth, tableHeight));
                excelTable.setModel(model);
            }
        }catch(NullPointerException ex){
            JOptionPane.showMessageDialog(null,"Thank you","Message",JOptionPane.INFORMATION_MESSAGE);
        }
}//GEN-LAST:event_selectExcelButtonActionPerformed

  public double sum(double v1,double v2,double v3,double v4,double v5,double v6,double v7,double v8){
      return (v1+v2+v3+v4+v5+v6+v7+v8);
  }    
    
    
    private void excelSaveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_excelSaveButtonActionPerformed
        // TODO add your handling code here:
        
        try {
            
            Connection connectionObj = DatabaseConnection.getConnectionObject();
            DatabaseInsertion dbInsert = new DatabaseInsertion(connectionObj);
            
            for (int i = 0; i < excelTable.getRowCount(); i++) {
                
                double v1 = Double.parseDouble(excelTable.getValueAt(i, 1).toString());
                double v2 = Double.parseDouble(excelTable.getValueAt(i, 2).toString());
                double v3 = Double.parseDouble(excelTable.getValueAt(i, 3).toString());
                double v4 = Double.parseDouble(excelTable.getValueAt(i, 4).toString());
                double v5 = Double.parseDouble(excelTable.getValueAt(i, 5).toString());
                double v6 = Double.parseDouble(excelTable.getValueAt(i, 6).toString());
                double v7 = Double.parseDouble(excelTable.getValueAt(i, 7).toString());
                double v8 = Double.parseDouble(excelTable.getValueAt(i, 8).toString());

                double add=sum(v1,v2,v3,v4,v5,v6,v7,v8);
                               
                if(dbInsert.insertfinalResultTwoInfo(resultIdentification,excelTable.getValueAt(i,0).toString(),excelTable.getValueAt(i,1).toString(),excelTable.getValueAt(i,2).toString(),excelTable.getValueAt(i,3).toString(),excelTable.getValueAt(i,4).toString(),excelTable.getValueAt(i,5).toString(),excelTable.getValueAt(i,6).toString(),excelTable.getValueAt(i,7).toString(),excelTable.getValueAt(i,8).toString(),String.valueOf(add))) {
                    this.result = true;
                }else{
                    this.result=false;
                }
                
            }
            
            if(result){
                JOptionPane.showMessageDialog(null, "Data Inserted database Sucessfully");
                this.loadTheTable();
            }else{
                JOptionPane.showMessageDialog(null, "Data already exist");
            }
            
            
            
        }catch(ArrayIndexOutOfBoundsException ex){
            JOptionPane.showMessageDialog(null,"Excel file can not adjust");
        }
    }//GEN-LAST:event_excelSaveButtonActionPerformed

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        // TODO add your handling code here:
        if (mainTable.getEditingColumn() == -1) {
            int i = 0;
            for (i = 0; i < mainTable.getRowCount(); i++) {
                try {
                    
                    Connection connectionObj = DatabaseConnection.getConnectionObject();
                    
                    String sql = "select * from secondexaminedsheet where secondExaminedId = '" + resultIdentification + "' and studentExamRoll='"+clonedexistingExaminerOneMarks[i][0]+"'";
                    System.out.println("sql: " + sql);
                    
                    Statement stmt = connectionObj.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    ResultSet rs = stmt.executeQuery(sql);
                    
                    rs.next();
                    
                    rs.updateString("secondExaminedId",resultIdentification);
                    
                    rs.updateString("studentExamRoll",clonedexistingExaminerOneMarks[i][0]);
                    
                    
                    rs.updateString("one", (String) mainTable.getValueAt(i, 1));
                    
                    rs.updateString("two", (String) mainTable.getValueAt(i, 2));
                    
                    rs.updateString("three", (String) mainTable.getValueAt(i, 3));
                    
                    rs.updateString("four", (String) mainTable.getValueAt(i, 4));
                    
                    rs.updateString("five", (String) mainTable.getValueAt(i, 5));
                    
                    rs.updateString("six", (String) mainTable.getValueAt(i, 6));
                    
                    rs.updateString("seven", (String) mainTable.getValueAt(i, 7));
                    
                    rs.updateString("eight", (String) mainTable.getValueAt(i, 8));
                    
                    rs.updateString("total", (String) mainTable.getValueAt(i, 9));
                    
                    rs.updateRow();
                    
                    
                    
                }catch (SQLException ex) {
                    // JOptionPane.showMessageDialog(null, ex.getMessage());
                    Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }catch (NullPointerException ex) {
                    // JOptionPane.showMessageDialog(null, ex.getMessage());
                    Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (i == rowCount1) {
                JOptionPane.showMessageDialog(this, "Second Examiner info updated successfully.");
                this.loadTheTable();
            }
            
        }else {
            JOptionPane.showMessageDialog(this, "Editing item cant be updated.");
        }
}//GEN-LAST:event_updateButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        // TODO add your handling code here:
        Connection connectionObj = DatabaseConnection.getConnectionObject();
        try {
            Statement stmt = connectionObj.createStatement();
            String query = "DELETE FROM secondexaminedsheet where secondExaminedId = '" + resultIdentification + "'";
            int deletedRows = stmt.executeUpdate(query);
            if (deletedRows > 0) {
                System.out.println("Deleted All Rows In The Table Successfully...");
                JOptionPane.showMessageDialog(null, "Deleted All Rows In The Table Successfully...");
                this.loadTheTable();
            } else {
                System.out.println("Table already empty.");
                JOptionPane.showMessageDialog(null, "Table already empty.");
                this.loadTheTable();
            }
            
        } catch (SQLException s) {
            System.out.println("Deleted All Rows In  Table Error. ");
            s.printStackTrace();
        }
        
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveButtonActionPerformed
        // TODO add your handling code here:
        try {
            
            Connection connectionObj = DatabaseConnection.getConnectionObject();
            DatabaseInsertion dbInsert = new DatabaseInsertion(connectionObj);
            
            if (studentExamRollTextField.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Please Select Exam Roll");
            }else {
                
                double value = Double.parseDouble(totalTextField.getText());
                if (value >= 0 && value <= fullmarks) {
                    if (dbInsert.insertfinalResultTwoInfo(resultIdentification, studentExamRollTextField.getText(), oneTextField.getText(), twoTextField.getText(), threeTextField.getText(), fourTextField.getText(), fiveTextField.getText(), sixTextField.getText(), sevenTextField.getText(), eightTextField.getText(), totalTextField.getText())) {
                        this.result = true;
                    } else {
                        this.result = false;
                    }
                    
                    if (result) {
                        JOptionPane.showMessageDialog(null, "Data Inserted database Sucessfully");
                        this.loadTheTable();
                    } else {
                        JOptionPane.showMessageDialog(null, "Data already exist");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Full Marks is greater then " + fullmarks);
                }
                
            }
            
        }catch(ArrayIndexOutOfBoundsException ex){
            JOptionPane.showMessageDialog(null,"Excel file can not adjust");
        }
}//GEN-LAST:event_saveButtonActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // TODO add your handling code here:
        ExaminerTwoAccessPanel obj = new ExaminerTwoAccessPanel(identification, assignSecondExaminerId, courseId, semesterNo, studentSession);
        this.removeAll();
        BoxLayout boxlayoutObj = new BoxLayout(this, BoxLayout.Y_AXIS);
        this.setLayout(boxlayoutObj);
        this.setPreferredSize(obj.getPreferredSize());
        this.add(obj);
        this.validate();
        this.repaint();
        obj.setVisible(true);
}//GEN-LAST:event_backButtonActionPerformed

    private void oneTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_oneTextFieldKeyReleased
        // TODO add your handling code here:
        try {
            double value=Double.parseDouble(oneTextField.getText());
            if(value>=0 && value<=marks_per_answer){
                
            }else{
                JOptionPane.showMessageDialog(null,"Value is out of range");
                oneTextField.setText("0");
            }
            
            
            double total = Double.parseDouble(oneTextField.getText()) + Double.parseDouble(twoTextField.getText()) + Double.parseDouble(threeTextField.getText()) + Double.parseDouble(fourTextField.getText()) + Double.parseDouble(fiveTextField.getText()) + Double.parseDouble(sixTextField.getText()) + Double.parseDouble(sevenTextField.getText()) + Double.parseDouble(eightTextField.getText());
            totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_oneTextFieldKeyReleased

    private void sixTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_sixTextFieldKeyReleased
        // TODO add your handling code here:
        try {
            double value=Double.parseDouble(sixTextField.getText());
            if(value>=0 && value<=marks_per_answer){
                
            }else{
                JOptionPane.showMessageDialog(null,"Value is out of range");
                sixTextField.setText("0");
            }
            
            double total = Double.parseDouble(oneTextField.getText()) + Double.parseDouble(twoTextField.getText()) + Double.parseDouble(threeTextField.getText()) + Double.parseDouble(fourTextField.getText()) + Double.parseDouble(fiveTextField.getText()) + Double.parseDouble(sixTextField.getText()) + Double.parseDouble(sevenTextField.getText()) + Double.parseDouble(eightTextField.getText());
            totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_sixTextFieldKeyReleased

    private void fiveTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fiveTextFieldKeyReleased
        // TODO add your handling code here:
        try {
            double value=Double.parseDouble(fiveTextField.getText());
            if(value>=0 && value<=marks_per_answer){
                
            }else{
                JOptionPane.showMessageDialog(null,"Value is out of range");
                fiveTextField.setText("0");
            }
            
            double total = Double.parseDouble(oneTextField.getText()) + Double.parseDouble(twoTextField.getText()) + Double.parseDouble(threeTextField.getText()) + Double.parseDouble(fourTextField.getText()) + Double.parseDouble(fiveTextField.getText()) + Double.parseDouble(sixTextField.getText()) + Double.parseDouble(sevenTextField.getText()) + Double.parseDouble(eightTextField.getText());
            totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_fiveTextFieldKeyReleased

    private void fourTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fourTextFieldActionPerformed
        // TODO add your handling code here:
}//GEN-LAST:event_fourTextFieldActionPerformed

    private void fourTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fourTextFieldKeyReleased
        // TODO add your handling code here:
        try {
            double value=Double.parseDouble(fourTextField.getText());
            if(value>=0 && value<=marks_per_answer){
                
            }else{
                JOptionPane.showMessageDialog(null,"Value is out of range");
                fourTextField.setText("0");
            }
            
            double total = Double.parseDouble(oneTextField.getText()) + Double.parseDouble(twoTextField.getText()) + Double.parseDouble(threeTextField.getText()) + Double.parseDouble(fourTextField.getText()) + Double.parseDouble(fiveTextField.getText()) + Double.parseDouble(sixTextField.getText()) + Double.parseDouble(sevenTextField.getText()) + Double.parseDouble(eightTextField.getText());
            totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_fourTextFieldKeyReleased

    private void twoTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_twoTextFieldKeyReleased
        // TODO add your handling code here:
        try {
            
            double value=Double.parseDouble(twoTextField.getText());
            if(value>=0 && value<=marks_per_answer){
                
            }else{
                JOptionPane.showMessageDialog(null,"Value is out of range");
                twoTextField.setText("0");
            }
            
            double total = Double.parseDouble(oneTextField.getText()) + Double.parseDouble(twoTextField.getText()) + Double.parseDouble(threeTextField.getText()) + Double.parseDouble(fourTextField.getText()) + Double.parseDouble(fiveTextField.getText()) + Double.parseDouble(sixTextField.getText()) + Double.parseDouble(sevenTextField.getText()) + Double.parseDouble(eightTextField.getText());
            totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_twoTextFieldKeyReleased

    private void sevenTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_sevenTextFieldKeyReleased
        // TODO add your handling code here:
        try {
            double value=Double.parseDouble(sevenTextField.getText());
            if(value>=0 && value<=marks_per_answer){
                
            }else{
                JOptionPane.showMessageDialog(null,"Value is out of range");
                sevenTextField.setText("0");
            }
            
            double total = Double.parseDouble(oneTextField.getText()) + Double.parseDouble(twoTextField.getText()) + Double.parseDouble(threeTextField.getText()) + Double.parseDouble(fourTextField.getText()) + Double.parseDouble(fiveTextField.getText()) + Double.parseDouble(sixTextField.getText()) + Double.parseDouble(sevenTextField.getText()) + Double.parseDouble(eightTextField.getText());
            totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_sevenTextFieldKeyReleased

    private void eightTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_eightTextFieldKeyReleased
        // TODO add your handling code here:
        try {
            double value=Double.parseDouble(eightTextField.getText());
            if(value>=0 && value<=marks_per_answer){
                
            }else{
                JOptionPane.showMessageDialog(null,"Value is out of range");
                eightTextField.setText("0");
            }
            
            double total = Double.parseDouble(oneTextField.getText()) + Double.parseDouble(twoTextField.getText()) + Double.parseDouble(threeTextField.getText()) + Double.parseDouble(fourTextField.getText()) + Double.parseDouble(fiveTextField.getText()) + Double.parseDouble(sixTextField.getText()) + Double.parseDouble(sevenTextField.getText()) + Double.parseDouble(eightTextField.getText());
            totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_eightTextFieldKeyReleased

    private void threeTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_threeTextFieldKeyReleased
        // TODO add your handling code here:
        try {
            double value=Double.parseDouble(threeTextField.getText());
            if(value>=0 && value<=marks_per_answer){
                
            }else{
                JOptionPane.showMessageDialog(null,"Value is out of range");
                threeTextField.setText("0");
            }
            
            double total = Double.parseDouble(oneTextField.getText()) + Double.parseDouble(twoTextField.getText()) + Double.parseDouble(threeTextField.getText()) + Double.parseDouble(fourTextField.getText()) + Double.parseDouble(fiveTextField.getText()) + Double.parseDouble(sixTextField.getText()) + Double.parseDouble(sevenTextField.getText()) + Double.parseDouble(eightTextField.getText());
            totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_threeTextFieldKeyReleased

    private void createReportButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createReportButtonActionPerformed
        // TODO add your handling code here:
            Connection connection = null;
            JasperReport jasperReport = null;
            JasperPrint jasperPrint = null;

            try {
              
                //String reportSource = "C:/Users/Setu/Documents/NetBeansProjects/RPS/src/UI/Report/SecondExaminerReport.jrxml";
               
                String reportSource=location.SecondExaminerReportLocation();
                
                Map map = new HashMap();
                map.put("resultparam",resultIdentification);
                map.put("teacherNameparam",teacherName);
                map.put("teacherDesignationparam",teacherDesignation);
                map.put("courseIdparam",courseIdTextField.getText()); 
                map.put("courseNameparam",courseName);
                Class.forName("com.mysql.jdbc.Driver");
                connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/rpsdbms", "root", "");
                
                jasperReport = (JasperReport) JasperCompileManager.compileReport(reportSource);
                jasperPrint = JasperFillManager.fillReport(jasperReport, map, connection);
                
                connection.close();
                
                JasperViewer.viewReport(jasperPrint, false);

            } catch (Exception ex) {
                 System.err.println(ex.getMessage());
            }
    }//GEN-LAST:event_createReportButtonActionPerformed

    private void submitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitButtonActionPerformed
        // TODO add your handling code here: 
         int response = JOptionPane.showConfirmDialog(null, "Are you want to submit this result?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE); 
        
         if (response == JOptionPane.NO_OPTION) {
                System.out.println("No button clicked");

         } else if (response == JOptionPane.YES_OPTION) {
        
     
         if (mainTable.getEditingColumn() == -1) {
            Connection connectionObj = DatabaseConnection.getConnectionObject();
            int i;
            for (i = 0; i < mainTable.getRowCount(); i++) {
               
                String sql="UPDATE `rpsdbms`.`temptheorygradeexaminedsheet` SET `SecondExaminerMarks` = '" + mainTable.getValueAt(i, 9).toString() + "' WHERE `temptheorygradeexaminedsheet`.`SubmissionId` = '"+adminId+"#"+studentSession+"#"+semesterNo+"#"+courseId+"#"+mainTable.getValueAt(i, 0).toString()+"'";
                
                
                System.out.println(sql);
                Statement statementObj;

                try {

                    statementObj = connectionObj.prepareStatement(sql);
                    statementObj.executeUpdate(sql);


                } catch (SQLException ex) {
                    Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }

                
            }
            
            if (i == rowCount1) {
                 JOptionPane.showMessageDialog(this, "Second Examiner info send to admin table successfully.");
                 this.loadTheTable();

                String sql = "UPDATE  secondexaminedstatus SET ExaminerTwoStatus = 'YES' WHERE examinerTwoTagId= '" + examinerTwoTagId + "' AND examinerserialId = " + examinerserialId + "";
                System.out.println(sql);
                Statement statementObj;

                try {

                    statementObj = connectionObj.prepareStatement(sql);
                    statementObj.executeUpdate(sql);
                    submitButton.setEnabled(false); 

                } catch (SQLException ex) {
                    Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Second Examiner info can not send successfully.");
        } 
      }
    }//GEN-LAST:event_submitButtonActionPerformed

    private void mainTableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mainTableKeyReleased
        // TODO add your handling code here:
              // TODO add your handling code here: 
        try {
            double value=Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(),mainTable.getSelectedColumn()).toString());
            if(value>=0 && value<=marks_per_answer){
                
            }else{
                JOptionPane.showMessageDialog(null,"Value is out of range");
                mainTable.setValueAt("0.00",mainTable.getSelectedRow(),mainTable.getSelectedColumn());
            }
            
             
            double total = Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 1).toString())
                + Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 2).toString())
                + Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 3).toString())
                + Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 4).toString())
                + Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 5).toString())
                + Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 6).toString())
                + Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 7).toString())
                + Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 8).toString()); 
         
            if(total>=0 && total<=fullmarks){
                mainTable.setValueAt(String.valueOf(total),mainTable.getSelectedRow(),9); 
            }else{
               JOptionPane.showMessageDialog(null,"Full Marks is out of range");
               mainTable.setValueAt("0.00",mainTable.getSelectedRow(),mainTable.getSelectedColumn());
            }
            
           
       
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
        
    }//GEN-LAST:event_mainTableKeyReleased

void fillData(File file) {

        Workbook workbook = null;
        try {
            try {
                workbook = Workbook.getWorkbook(file);
            } catch (IOException ex) {
                Logger.getLogger(FinalExamTwoResultPanel.class.getName()).log(Level.SEVERE,null, ex);
            }
         
            u= (int) jSpinner1.getValue();
            Sheet sheet = workbook.getSheet(u);

            headers.clear();
            for (int i = 0; i < sheet.getColumns(); i++) {
                Cell cell1 = sheet.getCell(i, 0);
                headers.add(cell1.getContents());
            }

            data.clear();
            for (int j = 1; j < sheet.getRows(); j++) {
                Vector d = new Vector();
                for (int i = 0; i < sheet.getColumns(); i++) {

                    Cell cell = sheet.getCell(i, j);

                    d.add(cell.getContents());

                }
                d.add("\n");
                data.add(d);
            }
        } catch (BiffException e) {
            e.printStackTrace();
        } catch(IndexOutOfBoundsException e){
              JOptionPane.showMessageDialog(null,"Sheet can not be found");
        }
    }  


  private void loadTheTable() {
        rowCount1 = 0;
        try {

            for (int i = 0; i < mainTable.getRowCount();) {
                
                tablemodel.removeRow(i);
            }
            
           
            Connection connectionObj = DatabaseConnection.getConnectionObject();
            NewInfoDatabaseRetrivation obj=new NewInfoDatabaseRetrivation(connectionObj);
            ResultSet rs=obj.loadSecondExaminedSheet(resultIdentification);
           

          
            while (rs.next()) {
                
                existingExaminerTwoMarks[rowCount1][0] = rs.getString("studentExamRoll");
                System.out.println("student:"+existingExaminerTwoMarks[rowCount1][0]);
                existingExaminerTwoMarks[rowCount1][1] = rs.getString("one");
                existingExaminerTwoMarks[rowCount1][2] = rs.getString("two");
                existingExaminerTwoMarks[rowCount1][3] = rs.getString("three");
                existingExaminerTwoMarks[rowCount1][4] = rs.getString("four");
                existingExaminerTwoMarks[rowCount1][5] = rs.getString("five");
                existingExaminerTwoMarks[rowCount1][6] = rs.getString("six");
                existingExaminerTwoMarks[rowCount1][7] = rs.getString("seven");
                existingExaminerTwoMarks[rowCount1][8] = rs.getString("eight");
                existingExaminerTwoMarks[rowCount1][9] = rs.getString("total");
               
                
                String[] rowStrings = {existingExaminerTwoMarks[rowCount1][0],existingExaminerTwoMarks[rowCount1][1], existingExaminerTwoMarks[rowCount1][2], existingExaminerTwoMarks[rowCount1][3], existingExaminerTwoMarks[rowCount1][4],existingExaminerTwoMarks[rowCount1][5],existingExaminerTwoMarks[rowCount1][6], existingExaminerTwoMarks[rowCount1][7],existingExaminerTwoMarks[rowCount1][8],existingExaminerTwoMarks[rowCount1][9]};
                tablemodel.addRow(rowStrings);
                rowCount1++;

            } 
            
            clonedexistingExaminerOneMarks = existingExaminerTwoMarks.clone();
            countTextField.setText(String.valueOf(rowCount1+"/"+count));

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Exception :" + ex);
             Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField assignSecondExaminerIdTextField;
    private javax.swing.JButton backButton;
    private javax.swing.JTextField countTextField;
    private javax.swing.JTextField courseIdTextField;
    private javax.swing.JButton createReportButton;
    private javax.swing.JButton deleteButton;
    private javax.swing.JTextField eightTextField;
    private javax.swing.JButton excelSaveButton;
    private javax.swing.JTable excelTable;
    private javax.swing.JTextField fiveTextField;
    private javax.swing.JTextField fourTextField;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JTable mainTable;
    private javax.swing.JTextField oneTextField;
    private javax.swing.JButton saveButton;
    private javax.swing.JTextField secondExaminerIdTextField;
    private javax.swing.JButton selectExcelButton;
    private javax.swing.JTextField sevenTextField;
    private javax.swing.JTextField sixTextField;
    private javax.swing.JTextField studentExamRollTextField;
    private javax.swing.JList studentList;
    private javax.swing.JTextField studentSemesterTextField;
    private javax.swing.JTextField studentSessionTextField;
    private javax.swing.JButton submitButton;
    private javax.swing.JTextField teacherIdTextField;
    private javax.swing.JTextField threeTextField;
    private javax.swing.JTextField totalTextField;
    private javax.swing.JTextField twoTextField;
    private javax.swing.JButton updateButton;
    // End of variables declaration//GEN-END:variables
}
