/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * LabGardeSheetAccessPanel.java
 *
 * Created on Oct 18, 2013, 8:58:56 PM
 */
package UI.Panel;

import Database.DatabaseConnection;
import UI.Database.DatabaseRetrivation;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;

/**
 *
 * @author SHAHRIAR
 */
public class GradeSheetAccessPanel extends javax.swing.JPanel {

    /** Creates new form LabGardeSheetAccessPanel */
    String session, semester, courseteacherid, adminId;
    String theorycourse[] = new String[100];
    String labcourse[] = new String[100];
    String[] theorycourseTitle = new String[100];
    String[] labcourseTitle = new String[100];
    JButton[] theorybutton = new JButton[100];
    JButton[] labbutton = new JButton[100];
    JLabel[] courseTitlelabel = new JLabel[100];
    JLabel[] courseTitlelabel1 = new JLabel[100];
    int rowCount, rowCount1;
    JButton[] courseIdbutton = new JButton[100];
    String[] courseIdButton = new String[100];
    String[] courseTitleLabel = new String[100];
    String[] studentSession = new String[100];
    String[] semesterNo = new String[100];
    String[] assignFirstExaminerId = new String[100];
    String identification;
    String assignYear;
    
    public GradeSheetAccessPanel(final String adminId,final String session,final String semester) {
        this.session=session;
        this.semester=semester;
        this.adminId=adminId;
        
        initComponents();
        semesterNoTextField.setText(semester);
         try {

            Connection connectionObj = DatabaseConnection.getConnectionObject();
            DatabaseRetrivation obj=new DatabaseRetrivation(connectionObj);
            ResultSet resultSetObj =obj.semesterNameByAdminId(adminId,semester);


            while (resultSetObj.next()) {
               semesterNameTextField.setText(resultSetObj.getString("a.semesterName"));
            }

 
            ResultSet resultSetObj1 =obj.theoryCourseIdBySemester(semester);

            while (resultSetObj1.next()) {
                
                theorycourse[rowCount] = resultSetObj1.getString("courseId");
                theorycourseTitle[rowCount]=resultSetObj1.getString("courseName");
                rowCount++;
            }
            
            ResultSet resultSetObj2 =obj.labCourseIdBySemester(semester);

            while (resultSetObj2.next()) {
                
                labcourse[rowCount1] = resultSetObj2.getString("courseId");
                labcourseTitle[rowCount1]=resultSetObj2.getString("courseName");
                rowCount1++;
            }


        } catch (SQLException ex) {
            Logger.getLogger(GradeSheetAccessPanel.class.getName()).log(Level.SEVERE, null, ex);
        } 

          for (int i = 0, j = 100; i < rowCount; i++, j += 40) {
              theorybutton[i] = new JButton();
              courseTitlelabel[i]=new JLabel();
              theorybutton[i].setText(theorycourse[i]);
              theorybutton[i].setSize(80, 20);
              theorybutton[i].setLocation(150, j);
              courseTitlelabel[i].setText(theorycourseTitle[i]);
              courseTitlelabel[i].setSize(200, 20);
              courseTitlelabel[i].setLocation(250, j);
              theoryPanel.add(theorybutton[i]);
              theoryPanel.add(courseTitlelabel[i]);
            final int index = i;
            theorybutton[index].addActionListener(new java.awt.event.ActionListener() {

                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    TheoryGradeSheetVerificationPanel obj = new TheoryGradeSheetVerificationPanel(adminId, theorybutton[index].getText().toString(), semester, session);
                    mainPanel.removeAll();
                    BoxLayout boxlayoutObj = new BoxLayout(mainPanel, BoxLayout.Y_AXIS);
                    mainPanel.setLayout(boxlayoutObj);
                    mainPanel.setPreferredSize(obj.getPreferredSize());
                    mainPanel.add(obj);
                    mainPanel.validate();
                    mainPanel.repaint();
                    obj.setVisible(true);
                }
            });
        }
          
         for (int i = 0, j = 100; i < rowCount1; i++, j += 40) {
            labbutton[i] = new JButton();
            courseTitlelabel1[i]=new JLabel();
            labbutton[i].setText(labcourse[i]);
            labbutton[i].setSize(80, 20);
            labbutton[i].setLocation(150, j);
            courseTitlelabel1[i].setText(labcourseTitle[i]);
            courseTitlelabel1[i].setSize(200, 20);
            courseTitlelabel1[i].setLocation(250, j);
            labPanel.add(labbutton[i]);
            labPanel.add(courseTitlelabel1[i]);
            final int index = i;
            labbutton[index].addActionListener(new java.awt.event.ActionListener() {

                public void actionPerformed(java.awt.event.ActionEvent evt) {
                         LabGradeSheetVerificationPanel obj = new LabGradeSheetVerificationPanel(adminId, assignFirstExaminerId[index],labbutton[index].getText().toString(),semester,session);
                         mainPanel.removeAll();
                         BoxLayout boxlayoutObj = new BoxLayout(mainPanel, BoxLayout.Y_AXIS);
                         mainPanel.setLayout(boxlayoutObj);
                         mainPanel.setPreferredSize(obj.getPreferredSize());
                         mainPanel.add(obj);
                         mainPanel.validate();
                         mainPanel.repaint();
                         obj.setVisible(true);
                }
            });
        }  
        
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        semesterNoTextField = new javax.swing.JTextField();
        semesterNameTextField = new javax.swing.JTextField();
        theoryPanel = new javax.swing.JPanel();
        labPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        mainPanel.setBackground(new java.awt.Color(89, 13, 23));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Semester");

        semesterNoTextField.setEditable(false);

        semesterNameTextField.setEditable(false);

        theoryPanel.setBackground(new java.awt.Color(218, 206, 244));
        theoryPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Select Theory Course"));

        javax.swing.GroupLayout theoryPanelLayout = new javax.swing.GroupLayout(theoryPanel);
        theoryPanel.setLayout(theoryPanelLayout);
        theoryPanelLayout.setHorizontalGroup(
            theoryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 506, Short.MAX_VALUE)
        );
        theoryPanelLayout.setVerticalGroup(
            theoryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 557, Short.MAX_VALUE)
        );

        labPanel.setBackground(new java.awt.Color(218, 206, 244));
        labPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Select Lab Course"));

        javax.swing.GroupLayout labPanelLayout = new javax.swing.GroupLayout(labPanel);
        labPanel.setLayout(labPanelLayout);
        labPanelLayout.setHorizontalGroup(
            labPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 549, Short.MAX_VALUE)
        );
        labPanelLayout.setVerticalGroup(
            labPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 557, Short.MAX_VALUE)
        );

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18));
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Grade Sheet Assessment");

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addGap(424, 424, 424)
                .addComponent(jLabel1)
                .addContainerGap(537, Short.MAX_VALUE))
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainPanelLayout.createSequentialGroup()
                        .addComponent(theoryPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(labPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(semesterNoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(semesterNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(777, Short.MAX_VALUE))))
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(semesterNoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(semesterNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(39, 39, 39))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainPanelLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addGap(15, 15, 15)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(theoryPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(labPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel labPanel;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JTextField semesterNameTextField;
    private javax.swing.JTextField semesterNoTextField;
    private javax.swing.JPanel theoryPanel;
    // End of variables declaration//GEN-END:variables
}
