/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * LabFinalExaminerResultPanel.java
 *
 * Created on Oct 18, 2013, 4:17:34 PM
 */
package UI.Panel;

import Database.DatabaseConnection;
import Database.ReportLocation;
import UI.Database.DatabaseInsertion;
import UI.Database.DatabaseRetrivation;
import UI.Database.NewInfoDatabaseRetrivation;
import java.awt.Dimension;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

public class LabFinalExaminerResultPanel extends javax.swing.JPanel {

     static Vector headers = new Vector();
    // Model is used to construct JTable
    static DefaultTableModel model = null;
    static DefaultTableModel tablemodel = null;
    // data is Vector contains Data from Excel File
    static Vector data = new Vector();
    static JFileChooser jChooser;
    static int tableWidth = 0; // set the tableWidth
    static int tableHeight = 0;
    int u,rowCount1;
    private SpinnerModel model1;
    String[][] existingStudents = new String[500][10];
    String[][] existingLabFinalMarks = new String[500][10];
    String[][] clonedexistingLabFinalMarks = new String[500][10];
    boolean result;
    JTable Table1;
    private String[][] dataNames;
    private String[] columnNames;
    String s[]=new String[1000];
    String t[]=new String[100];
    int count;
    int marks_in_experiment=30;
    int marks_in_viva=10;
    int fullmarks=40;
    String courseId,semesterNo,studentSession,assignlabExaminerId,identification,teacherName,teacherDesignation,courseName;
    String resultIdentification,adminId,labfinalTestTagId,status;
    int labfinalTestSerialId;
    ReportLocation location=new ReportLocation(); 
    
    public LabFinalExaminerResultPanel(String identification,String assignlabExaminerId,String courseId,String semesterNo,String studentSession) {
       try {
           
           
            // Identification means teacherId 
           
            this.identification = identification;
            this.courseId = courseId;
            this.semesterNo = semesterNo;
            this.studentSession = studentSession;
            this.assignlabExaminerId = assignlabExaminerId;
            
            jChooser = new JFileChooser();
            model1 = new SpinnerNumberModel(0, 0, 20, 1);
            
            Connection conn = DatabaseConnection.getConnectionObject();
            DatabaseRetrivation obj = new DatabaseRetrivation(conn);
            
            String sql1="select concat(labfinalexaminerTagId,labfinalexaminerserialId) as labExaminerId from labfinalexaminedstatus where assignId='"+assignlabExaminerId+"'";
            Statement stmt1 = conn.prepareStatement(sql1);
            ResultSet rs1 = stmt1.executeQuery(sql1);
            
              while (rs1.next()) {
                  resultIdentification = rs1.getString("labExaminerId");
                  System.out.println("E1:"+resultIdentification);
              }
 
          
                   
           String sql4 = "select labfinalexaminerTagId,labfinalexaminerSerialId from labfinalexaminedstatus where assignId='" + assignlabExaminerId + "'";
           Statement stmt4 = conn.prepareStatement(sql4);
           ResultSet rs4 = stmt1.executeQuery(sql4);

           while (rs4.next()) {
               labfinalTestTagId = rs4.getString("labfinalexaminerTagId");
               System.out.println(labfinalTestTagId);
               labfinalTestSerialId = rs4.getInt("labfinalexaminerSerialId");
               System.out.println(labfinalTestSerialId);
           }
  
              
          
            String sql = "select studentExamRoll from student where studentSemester='"+semesterNo+"'";
            System.out.println(sql);

          
            Statement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {

                s[count] = rs.getString("studentExamRoll");
                System.out.println(rs.getString("studentExamRoll"));
                count++;
            }
            System.out.println(count); 
            
            String sql2 = "select distinct adminId from templabgradeexaminedsheet where studentSession='"+studentSession+"' and semesterNo='"+semesterNo+"' and courseId='"+courseId+"'";
            System.out.println(sql2);
            
             ResultSet rs2 = stmt.executeQuery(sql2);
             
             while(rs2.next()){
                adminId=rs2.getString("adminId");
             }
            
            
            initComponents();
            teacherIdTextField.setText(courseId);
            courseIdTextField.setText(identification); 
            studentSessionTextField.setText(studentSession); 
            studentSemesterTextField.setText(semesterNo); 
            assignFirstExaminerIdTextField.setText(assignlabExaminerId); 
            labExaminerIdTextField.setText(resultIdentification);

            ResultSet resultSetObj2 = obj.courseNameByCourseId(courseId);

            while (resultSetObj2.next()) {
               courseName=resultSetObj2.getString("courseName");
            }
            
            
             ResultSet resultSetObj3 = obj.teacherNameteacherDesignationByteacherId(identification); 
             
            
             while (resultSetObj3.next()) {

                teacherName = resultSetObj3.getString("teacherName");
                teacherDesignation=resultSetObj3.getString("teacherDesignation");
                System.out.println(teacherDesignation);
            }
            
           //checking status about teacher verification after submission

           String statussql = "select labfinalExaminerStatus from labfinalexaminedstatus where assignId='" + assignlabExaminerId + "'";
           System.out.println(statussql);
           Statement stmt3 = conn.prepareStatement(statussql);
           ResultSet rs3 = stmt3.executeQuery(statussql);
           while (rs3.next()) {
               status = rs3.getString("labfinalExaminerStatus");

           }

           System.out.println(status);
           if (status.equals("YES")) {
               submitButton.setEnabled(false);
           } else {
               System.out.println("Sorry");
           }
             
            
            studentList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            studentList.addListSelectionListener(new ListSelectionListener() {

                @Override
                public void valueChanged(ListSelectionEvent e) {
                    int idx = studentList.getSelectedIndex();
                    studentExamRollTextField.setText(String.valueOf(studentList.getSelectedValue()));

                }
            });
            
          this.loadTheTable();
     
        } catch (SQLException ex) {
            Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        selectExcelButton = new javax.swing.JButton();
        jSpinner1 = new javax.swing.JSpinner(model1);
        excelSaveButton = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        courseIdTextField = new javax.swing.JTextField();
        teacherIdTextField = new javax.swing.JTextField();
        studentSessionTextField = new javax.swing.JTextField();
        studentSemesterTextField = new javax.swing.JTextField();
        assignFirstExaminerIdTextField = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        saveButton = new javax.swing.JButton();
        createReportButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        submitButton = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        studentList = new javax.swing.JList(s);
        jPanel2 = new javax.swing.JPanel();
        studentExamRollTextField = new javax.swing.JTextField();
        experimentTextField = new javax.swing.JTextField(0);
        vivaTextField = new javax.swing.JTextField(0);
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        totalTextField = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        countTextField = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        mainTable = new javax.swing.JTable(){

            public boolean isCellEditable(int row,int column){

                switch(column){
                    case 0:
                    case 3:
                    return false;
                    default:
                    return true;

                }

            }}
            ;
            labExaminerIdTextField = new javax.swing.JTextField();

            setBackground(new java.awt.Color(89, 13, 23));

            jTable1.setBackground(new java.awt.Color(198, 244, 245));
            jTable1.setModel(new javax.swing.table.DefaultTableModel(
                new Object [][] {
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null}
                },
                new String [] {
                    "Student Exam Roll", "Experiment", "Viva", "Total"
                }
            ));
            jScrollPane1.setViewportView(jTable1);

            jPanel1.setBackground(new java.awt.Color(26, 60, 26));
            jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

            selectExcelButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            selectExcelButton.setText("select Excel file");
            selectExcelButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    selectExcelButtonActionPerformed(evt);
                }
            });

            excelSaveButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            excelSaveButton.setText("Save");
            excelSaveButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    excelSaveButtonActionPerformed(evt);
                }
            });

            updateButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            updateButton.setText("Update");
            updateButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    updateButtonActionPerformed(evt);
                }
            });

            deleteButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            deleteButton.setText("Delete All");
            deleteButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    deleteButtonActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
            jPanel1.setLayout(jPanel1Layout);
            jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(19, 19, 19)
                    .addComponent(selectExcelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(29, 29, 29)
                    .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(35, 35, 35)
                    .addComponent(excelSaveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(676, Short.MAX_VALUE))
            );
            jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(excelSaveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(selectExcelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );

            jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Info"));

            courseIdTextField.setEditable(false);

            teacherIdTextField.setEditable(false);

            studentSessionTextField.setEditable(false);

            studentSemesterTextField.setEditable(false);

            assignFirstExaminerIdTextField.setEditable(false);

            javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
            jPanel6.setLayout(jPanel6Layout);
            jPanel6Layout.setHorizontalGroup(
                jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel6Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(teacherIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(courseIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(studentSessionTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                        .addComponent(studentSemesterTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                        .addComponent(assignFirstExaminerIdTextField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE))
                    .addContainerGap())
            );
            jPanel6Layout.setVerticalGroup(
                jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel6Layout.createSequentialGroup()
                    .addComponent(courseIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(teacherIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(studentSessionTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(studentSemesterTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(assignFirstExaminerIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(19, Short.MAX_VALUE))
            );

            jPanel3.setBackground(new java.awt.Color(26, 60, 26));
            jPanel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

            saveButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            saveButton.setText("Save Entry");
            saveButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    saveButtonActionPerformed(evt);
                }
            });

            createReportButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            createReportButton.setText("Create Report");
            createReportButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    createReportButtonActionPerformed(evt);
                }
            });

            backButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            backButton.setText("Back");
            backButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    backButtonActionPerformed(evt);
                }
            });

            submitButton.setFont(new java.awt.Font("Tahoma", 1, 13));
            submitButton.setText("Submit");
            submitButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    submitButtonActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
            jPanel3.setLayout(jPanel3Layout);
            jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGap(97, 97, 97)
                    .addComponent(saveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(92, 92, 92)
                    .addComponent(createReportButton, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(97, 97, 97)
                    .addComponent(submitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 111, Short.MAX_VALUE)
                    .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(277, 277, 277))
            );
            jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(createReportButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(saveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(submitButton, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE))
                    .addContainerGap())
            );

            studentList.setFont(new java.awt.Font("Times New Roman", 0, 24));
            studentList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
            jScrollPane4.setViewportView(studentList);

            jPanel2.setBackground(new java.awt.Color(153, 153, 0));
            jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

            studentExamRollTextField.setEditable(false);

            experimentTextField.setText("0");
            experimentTextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    experimentTextFieldKeyReleased(evt);
                }
            });

            vivaTextField.setText("0");
            vivaTextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    vivaTextFieldKeyReleased(evt);
                }
            });

            jLabel2.setText("Student Exam Roll");

            jLabel3.setText("Viva");

            jLabel4.setText("Experiment");

            totalTextField.setEditable(false);
            totalTextField.setText("0");

            jLabel11.setText("Total");

            countTextField.setEditable(false);
            countTextField.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    countTextFieldActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
            jPanel2.setLayout(jPanel2Layout);
            jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel2)
                    .addGap(18, 18, 18)
                    .addComponent(studentExamRollTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jLabel4)
                    .addGap(18, 18, 18)
                    .addComponent(experimentTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jLabel3)
                    .addGap(18, 18, 18)
                    .addComponent(vivaTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jLabel11)
                    .addGap(18, 18, 18)
                    .addComponent(totalTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(countTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );
            jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(experimentTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4)
                        .addComponent(studentExamRollTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2)
                        .addComponent(jLabel3)
                        .addComponent(vivaTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel11)
                        .addComponent(totalTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(countTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(19, Short.MAX_VALUE))
            );

            mainTable.setBackground(new java.awt.Color(198, 244, 245));
            mainTable.setModel(tablemodel=new javax.swing.table.DefaultTableModel(
                new Object [][] {
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null}
                },
                new String [] {
                    "Student Exam Roll", "Experiment","Viva", "Total"
                }
            ));
            mainTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
            mainTable.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    mainTableKeyReleased(evt);
                }
            });
            jScrollPane2.setViewportView(mainTable);

            labExaminerIdTextField.setEditable(false);

            javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
            this.setLayout(layout);
            layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(37, 37, 37)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1266, Short.MAX_VALUE)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1158, Short.MAX_VALUE)
                                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(labExaminerIdTextField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(14, 14, 14))
            );
            layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(labExaminerIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(11, 11, 11)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 387, Short.MAX_VALUE))
                    .addContainerGap(39, Short.MAX_VALUE))
            );
        }// </editor-fold>//GEN-END:initComponents

    private void selectExcelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectExcelButtonActionPerformed
        // TODO add your handling code here:
        jChooser.showOpenDialog(null);
        
        try{
            
            File file = jChooser.getSelectedFile();
            if (!file.getName().endsWith("xls")) {
                JOptionPane.showMessageDialog(null,"Please select only Excel file.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                fillData(file);
                model = new DefaultTableModel(data,headers);
                tableWidth = model.getColumnCount()* 150;
                tableHeight = model.getRowCount()* 25;
                jTable1.setPreferredSize(new Dimension(tableWidth, tableHeight));
                jTable1.setModel(model);
            }
        }catch(NullPointerException ex){
            JOptionPane.showMessageDialog(null,"Thank you","Message",JOptionPane.INFORMATION_MESSAGE);
        }
}//GEN-LAST:event_selectExcelButtonActionPerformed

    private void excelSaveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_excelSaveButtonActionPerformed
        // TODO add your handling code here:
        
        try {
            
            Connection connectionObj = DatabaseConnection.getConnectionObject();
            DatabaseInsertion dbInsert = new DatabaseInsertion(connectionObj);
            
            for (int i = 0; i < jTable1.getRowCount(); i++) {
                
                
                if(dbInsert.insertLabfinalResultInfo(resultIdentification,jTable1.getValueAt(i,0).toString(),jTable1.getValueAt(i,1).toString(),jTable1.getValueAt(i,2).toString(),jTable1.getValueAt(i,3).toString())) {
                    this.result = true;
                }else{
                    this.result=false;
                }
                
            }
            
            if(result){
                JOptionPane.showMessageDialog(null, "Data Inserted database Sucessfully");
                this.loadTheTable();
            }else{
                JOptionPane.showMessageDialog(null, "Data already exist");
            }
            
            
            
        }catch(ArrayIndexOutOfBoundsException ex){
            JOptionPane.showMessageDialog(null,"Excel file can not adjust");
        }
    }//GEN-LAST:event_excelSaveButtonActionPerformed

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        // TODO add your handling code here:
        if (mainTable.getEditingColumn() == -1) {
            int i = 0;
            for (i = 0; i < mainTable.getRowCount(); i++) {
                try {
                    
                    Connection connectionObj = DatabaseConnection.getConnectionObject();
                    
                    String sql = "select * from labexaminedsheet where labfinalExaminedId = '" + resultIdentification + "' and studentExamRoll='"+clonedexistingLabFinalMarks[i][0]+"'";
                    System.out.println("sql: " + sql);
                    
                    Statement stmt = connectionObj.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    ResultSet rs = stmt.executeQuery(sql);
                    
                    rs.next();
                    
                    rs.updateString("labfinalExaminedId",resultIdentification);
                    
                    rs.updateString("studentExamRoll",clonedexistingLabFinalMarks[i][0]);
                    
                    rs.updateString("experiment", (String) mainTable.getValueAt(i, 1));
                    
                    rs.updateString("viva", (String) mainTable.getValueAt(i, 2));
                      
                    rs.updateString("total", (String) mainTable.getValueAt(i, 3));
                    
                    rs.updateRow();
                    
                    
                    
                }catch (SQLException ex) {
                    // JOptionPane.showMessageDialog(null, ex.getMessage());
                    Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }catch (NullPointerException ex) {
                    // JOptionPane.showMessageDialog(null, ex.getMessage());
                    Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (i == rowCount1) {
                JOptionPane.showMessageDialog(this, "Lab Final Info Updated Successfully.");
                this.loadTheTable();
            }
            
        }else {
            JOptionPane.showMessageDialog(this, "Editing item cant be updated.");
        }
}//GEN-LAST:event_updateButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        // TODO add your handling code here:
        Connection connectionObj = DatabaseConnection.getConnectionObject();
        try {
            Statement stmt = connectionObj.createStatement();
            String query = "DELETE FROM labexaminedsheet where labfinalExaminedId = '" + resultIdentification + "'";
            int deletedRows = stmt.executeUpdate(query);
            if (deletedRows > 0) {
                System.out.println("Deleted All Rows In The Table Successfully...");
                JOptionPane.showMessageDialog(null, "Deleted All Rows In The Table Successfully...");
                this.loadTheTable();
            } else {
                System.out.println("Table already empty.");
                JOptionPane.showMessageDialog(null, "Table already empty.");
                this.loadTheTable();
            }
            
        } catch (SQLException s) {
            System.out.println("Deleted All Rows In  Table Error. ");
            s.printStackTrace();
        }
        
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveButtonActionPerformed
        // TODO add your handling code here:
        try {
            
            Connection connectionObj = DatabaseConnection.getConnectionObject();
            DatabaseInsertion dbInsert = new DatabaseInsertion(connectionObj);
            
            if (studentExamRollTextField.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Please Select Exam Roll");
            }else {
                
                double value = Double.parseDouble(totalTextField.getText());
                if (value >= 0 && value <= fullmarks) {
                    if (dbInsert.insertLabfinalResultInfo(resultIdentification, studentExamRollTextField.getText(), experimentTextField.getText(), vivaTextField.getText(), totalTextField.getText())) {
                        this.result = true;
                    } else {
                        this.result = false;
                    }
                    
                    if (result) {
                        JOptionPane.showMessageDialog(null, "Data Inserted database Sucessfully");
                        this.loadTheTable();
                    } else {
                        JOptionPane.showMessageDialog(null, "Data already exist");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Full Marks is greater then " + fullmarks);
                }
                
            }
            
        }catch(ArrayIndexOutOfBoundsException ex){
            JOptionPane.showMessageDialog(null,"Excel file can not adjust");
        }
}//GEN-LAST:event_saveButtonActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // TODO add your handling code here:
        LabExaminerAccessPanel obj = new LabExaminerAccessPanel(identification, assignlabExaminerId, courseId, semesterNo, studentSession);
        this.removeAll();
        BoxLayout boxlayoutObj = new BoxLayout(this, BoxLayout.Y_AXIS);
        this.setLayout(boxlayoutObj);
        this.setPreferredSize(obj.getPreferredSize());
        this.add(obj);
        this.validate();
        this.repaint();
        obj.setVisible(true);
}//GEN-LAST:event_backButtonActionPerformed

    private void experimentTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_experimentTextFieldKeyReleased
        // TODO add your handling code here:
        try {
            double value=Double.parseDouble(experimentTextField.getText());
            if(value>=0 && value<=marks_in_experiment){
                
            }else{
                JOptionPane.showMessageDialog(null,"Value is out of range");
                experimentTextField.setText("0");
            }
            
            
            double total = Double.parseDouble(experimentTextField.getText()) + Double.parseDouble(vivaTextField.getText());
            totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_experimentTextFieldKeyReleased

    private void vivaTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_vivaTextFieldKeyReleased
        // TODO add your handling code here:
        try {
            
            double value=Double.parseDouble(vivaTextField.getText());
            if(value>=0 && value<=marks_in_viva){
                
            }else{
                JOptionPane.showMessageDialog(null,"Value is out of range");
                vivaTextField.setText("0");
            }
            
           double total = Double.parseDouble(experimentTextField.getText()) + Double.parseDouble(vivaTextField.getText());
           totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_vivaTextFieldKeyReleased

    private void createReportButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createReportButtonActionPerformed
            //TODO add your handling code here:
            Connection connection = null;
            JasperReport jasperReport = null;
            JasperPrint jasperPrint = null;

            try {
              
                //String reportSource = "C:/RPS/Report/labFinalReport.jrxml";
               
                String reportSource=location.LabFinalTestVerificationReportLocation();
                
                Map map = new HashMap();
                map.put("resultparam",resultIdentification);
                map.put("teacherNameparam",teacherName);
                map.put("teacherDesignationparam",teacherDesignation);
                map.put("courseIdparam",courseIdTextField.getText()); 
                map.put("courseNameparam",courseName);
                Class.forName("com.mysql.jdbc.Driver");
                connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/rpsdbms", "root", "");
                
                jasperReport = (JasperReport) JasperCompileManager.compileReport(reportSource);
                jasperPrint = JasperFillManager.fillReport(jasperReport, map, connection);
                
                connection.close();
                
                JasperViewer.viewReport(jasperPrint, false);

            } catch (Exception ex) {
                 System.err.println(ex.getMessage());
                  Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_createReportButtonActionPerformed

    private void countTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_countTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_countTextFieldActionPerformed

    private void submitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitButtonActionPerformed
        // TODO add your handling code here:
         int response = JOptionPane.showConfirmDialog(null, "Are you want to submit this result?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE); 
        
         if (response == JOptionPane.NO_OPTION) {
                System.out.println("No button clicked");

         } else if (response == JOptionPane.YES_OPTION) {
        
        if (mainTable.getEditingColumn() == -1) {
            Connection connectionObj = DatabaseConnection.getConnectionObject();
            int i;
            for (i = 0; i < mainTable.getRowCount(); i++) {
            
                String sql="UPDATE `rpsdbms`.`templabgradeexaminedsheet` SET `LabFinalExam` = '" + mainTable.getValueAt(i,3).toString() + "' WHERE `templabgradeexaminedsheet`.`SubmissionId` = '"+adminId+"#"+studentSession+"#"+semesterNo+"#"+courseId+"#"+mainTable.getValueAt(i, 0).toString()+"'";
                
                
                System.out.println(sql);
                Statement statementObj;

                try {

                    statementObj = connectionObj.prepareStatement(sql);
                    statementObj.executeUpdate(sql);


                } catch (SQLException ex) {
                    Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }

                
            }
            
            if (i == rowCount1) {
                 JOptionPane.showMessageDialog(this, "Lab Examiner info send to admin table successfully.");
                 this.loadTheTable();
                String sql="UPDATE `rpsdbms`.`labfinalexaminedstatus` SET `labfinalExaminerStatus` = 'YES' WHERE `labfinalexaminedstatus`.`labfinalexaminerTagId` = '" + labfinalTestTagId+ "' AND `labfinalexaminedstatus`.`labfinalexaminerserialId` ="+labfinalTestSerialId+"";
                
                
                System.out.println(sql);
                Statement statementObj;

                try {

                    statementObj = connectionObj.prepareStatement(sql);
                    statementObj.executeUpdate(sql);
                    submitButton.setEnabled(false); 

                } catch (SQLException ex) {
                    Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Lab Examiner info can not send successfully.");
        } 
      }
    }//GEN-LAST:event_submitButtonActionPerformed

    private void mainTableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mainTableKeyReleased
        // TODO add your handling code here:
             try {
           
            double total = Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 1).toString())
                + Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 2).toString());
               
         
            if(total>=0 && total<=fullmarks){
                mainTable.setValueAt(String.valueOf(total),mainTable.getSelectedRow(),3); 
            }else{
               JOptionPane.showMessageDialog(null,"Full Marks is out of range");
               mainTable.setValueAt("0.00",mainTable.getSelectedRow(),mainTable.getSelectedColumn());
            }
              
       
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
    }//GEN-LAST:event_mainTableKeyReleased

  void fillData(File file) {

        Workbook workbook = null;
        try {
            try {
                workbook = Workbook.getWorkbook(file);
            } catch (IOException ex) {
                Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE,null, ex);
            }
         
            u= (int) jSpinner1.getValue();
            Sheet sheet = workbook.getSheet(u);

            headers.clear();
            for (int i = 0; i < sheet.getColumns(); i++) {
                Cell cell1 = sheet.getCell(i, 0);
                headers.add(cell1.getContents());
            }

            data.clear();
            for (int j = 1; j < sheet.getRows(); j++) {
                Vector d = new Vector();
                for (int i = 0; i < sheet.getColumns(); i++) {
                    Cell cell = sheet.getCell(i, j);
                    d.add(cell.getContents());   
                }
                d.add("\n");
                data.add(d);
            }
        } catch (BiffException e) {
            e.printStackTrace();
        } catch(IndexOutOfBoundsException e){
              JOptionPane.showMessageDialog(null,"Sheet can not be found");
        }
    }
  
  
   private void loadTheTable() {
        rowCount1 = 0;
        try {

            for (int i = 0; i < mainTable.getRowCount();) {
                
                tablemodel.removeRow(i);
            }
            
           
            Connection connectionObj = DatabaseConnection.getConnectionObject();
            NewInfoDatabaseRetrivation obj=new NewInfoDatabaseRetrivation(connectionObj);
            ResultSet rs=obj.loadLabExaminedSheet(resultIdentification);
           

          
            while (rs.next()) {
                
                existingLabFinalMarks[rowCount1][0] = rs.getString("studentExamRoll");
                System.out.println("student:"+existingLabFinalMarks[rowCount1][0]);
                existingLabFinalMarks[rowCount1][1] = rs.getString("experiment");
                existingLabFinalMarks[rowCount1][2] = rs.getString("viva");
                existingLabFinalMarks[rowCount1][3] = rs.getString("total");
                
               
                
                String[] rowStrings = {existingLabFinalMarks[rowCount1][0], existingLabFinalMarks[rowCount1][1], existingLabFinalMarks[rowCount1][2],existingLabFinalMarks[rowCount1][3]};
                tablemodel.addRow(rowStrings);
                rowCount1++;

            } 
            
            clonedexistingLabFinalMarks = existingLabFinalMarks.clone();
            System.out.println("verified:"+rowCount1);
            countTextField.setText(String.valueOf(rowCount1+"/"+count));

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Exception :" + ex);
             Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField assignFirstExaminerIdTextField;
    private javax.swing.JButton backButton;
    private javax.swing.JTextField countTextField;
    private javax.swing.JTextField courseIdTextField;
    private javax.swing.JButton createReportButton;
    private javax.swing.JButton deleteButton;
    private javax.swing.JButton excelSaveButton;
    private javax.swing.JTextField experimentTextField;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField labExaminerIdTextField;
    private javax.swing.JTable mainTable;
    private javax.swing.JButton saveButton;
    private javax.swing.JButton selectExcelButton;
    private javax.swing.JTextField studentExamRollTextField;
    private javax.swing.JList studentList;
    private javax.swing.JTextField studentSemesterTextField;
    private javax.swing.JTextField studentSessionTextField;
    private javax.swing.JButton submitButton;
    private javax.swing.JTextField teacherIdTextField;
    private javax.swing.JTextField totalTextField;
    private javax.swing.JButton updateButton;
    private javax.swing.JTextField vivaTextField;
    // End of variables declaration//GEN-END:variables
}
