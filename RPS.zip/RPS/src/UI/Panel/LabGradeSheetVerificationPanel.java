/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * LabGradeSheetVerificationPanelPanel.java
 *
 * Created on Oct 18, 2013, 8:58:01 PM
 */
package UI.Panel;

import Database.DatabaseConnection;
import Database.ReportLocation;
import UI.Database.DatabaseInsertion;
import UI.Database.DatabaseRetrivation;
import UI.Database.NewInfoDatabaseRetrivation;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

public class LabGradeSheetVerificationPanel extends javax.swing.JPanel {

    static Vector headers = new Vector();
    NumberFormat nf;
    // Model is used to construct JTable
    static DefaultTableModel model = null;
    static DefaultTableModel tablemodel = null; 
    static DefaultTableModel temptablemodel = null; 
    // data is Vector contains Data from Excel File
    static Vector data = new Vector();
    static JFileChooser jChooser;
    static int tableWidth = 0; // set the tableWidth
    static int tableHeight = 0;
    double[] getDoubleData=new double[100];
    int u,rowCount1,rowCount2;
    private SpinnerModel model1;
    String[][] existingStudents = new String[500][10];
    String[][] existingLabFinalMarks = new String[500][10]; 
    String[][] existingTempLabFinalMarks = new String[500][10]; 
    String[][] clonedexistingLabFinalMarks = new String[500][10];
    boolean result;
    JTable Table1;
    private String[][] dataNames;
    private String[] columnNames;
    double TotalMarks[]=new double[800];
    double TestMarks[]=new double[800];
    double FinalMarks[]=new double[800];
    double gradepoints[]=new double[800];
    String letters[]=new String[800];
    String courseIdList[]=new String[1000];
    String courseList[]=new String[1000];
    String t[]=new String[100];
    int count,rowCount;
    int marks_per_answer=100;
    int fullmarks=100;
    String semesterNo,studentSession,assignlabExaminerId,identification;
    String resultIdentification,assignYear,teacherName,teacherDesignation,courseName,courseId;
    ReportLocation location=new ReportLocation();
    String studentExamRoll;
    private String LabExaminerId;
    
    public LabGradeSheetVerificationPanel(String identification,String assignFirstExaminerId,String courseId,String semesterNo,String studentSession) {
         try {
           
            // identification means adminId 
             
            this.identification = identification;
            this.semesterNo = semesterNo;
            this.studentSession = studentSession;
            this.courseId=courseId;
            
            jChooser = new JFileChooser();
            model1 = new SpinnerNumberModel(0, 0, 20, 1);
            
           Connection conn = DatabaseConnection.getConnectionObject();
           DatabaseRetrivation obj = new DatabaseRetrivation(conn);
           ResultSet resultSetObj1 = obj.loadOtherAssignTeacherYear(identification);

           while (resultSetObj1.next()) {
               assignYear = resultSetObj1.getString("adminAssignYear");
           }

          

            initComponents();
            
            this.loadTempTable();
          
            
            ResultSet resultSetObj2 = obj.courseNameByCourseId(courseId); 
            
             while (resultSetObj2.next()) {
                courseName = resultSetObj2.getString("courseName");
                    
            }
            
            ResultSet resultSetObj3 = obj.adminNameDesignationByadminId(identification);
            
             while (resultSetObj3.next()) {
                teacherName = resultSetObj3.getString("a.teacherName");
                teacherDesignation=resultSetObj3.getString("a.teacherDesignation");        
            }
            
           
            NewInfoDatabaseRetrivation assignTeacherobj=new NewInfoDatabaseRetrivation(conn);
            ResultSet rs1=assignTeacherobj.getLabCourseTeacherIdNameTableByCourseIdSemesterSession(courseId, semesterNo, studentSession); 
             
             while (rs1.next()) {
               LabExaminerId=rs1.getString("b.teacherId");  
               LabExaminerNameTextField.setText(rs1.getString("a.teacherName"));
               
            } 
             
             
               
            resultIdentification="LGS0000"+identification+assignYear+courseId;
            teacherIdTextField.setText(resultIdentification);
            studentSessionTextField.setText(studentSession);
            studentSemesterTextField.setText(semesterNo);
            courseIdTextField.setText(courseId);
            courseNameTextField.setText(courseName);
            
             this.loadTheTable(); 
         
  
        } catch (SQLException ex) {
            Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tempTable = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        tempSaveButton = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        mainTable = new javax.swing.JTable(){

            public boolean isCellEditable(int row,int column){

                switch(column){
                    case 0:

                    return false;
                    default:
                    return true;

                }

            }}
            ;
            jPanel3 = new javax.swing.JPanel();
            createReportButton = new javax.swing.JButton();
            backButton = new javax.swing.JButton();
            updateGradeSheetButton = new javax.swing.JButton();
            jPanel6 = new javax.swing.JPanel();
            courseIdTextField = new javax.swing.JTextField();
            teacherIdTextField = new javax.swing.JTextField();
            studentSessionTextField = new javax.swing.JTextField();
            studentSemesterTextField = new javax.swing.JTextField();
            courseNameTextField = new javax.swing.JTextField();
            jLabel3 = new javax.swing.JLabel();
            LabExaminerNameTextField = new javax.swing.JTextField();
            jLabel1 = new javax.swing.JLabel();
            NumberOfStudentTextField = new javax.swing.JTextField();
            jLabel2 = new javax.swing.JLabel();
            NumberOfStudentTextField1 = new javax.swing.JTextField();

            setBackground(new java.awt.Color(89, 13, 23));

            tempTable.setBackground(new java.awt.Color(198, 244, 245));
            tempTable.setModel(temptablemodel=new javax.swing.table.DefaultTableModel(
                new Object [][] {
                    {null, null, null},
                    {null, null, null},
                    {null, null, null},
                    {null, null, null},
                    {null, null, null},
                    {null, null, null},
                    {null, null, null},
                    {null, null, null},
                    {null, null, null},
                    {null, null, null},
                    {null, null, null},
                    {null, null, null},
                    {null, null, null}
                },
                new String [] {
                    "studentExamId", "Lab Class Test", "Lab Final Exam"
                }
            ));
            jScrollPane1.setViewportView(tempTable);

            jPanel1.setBackground(new java.awt.Color(26, 60, 26));
            jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

            tempSaveButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            tempSaveButton.setText("Save");
            tempSaveButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    tempSaveButtonActionPerformed(evt);
                }
            });

            updateButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            updateButton.setText("Update");
            updateButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    updateButtonActionPerformed(evt);
                }
            });

            deleteButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            deleteButton.setText("Delete All");
            deleteButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    deleteButtonActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
            jPanel1.setLayout(jPanel1Layout);
            jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(50, 50, 50)
                    .addComponent(tempSaveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(125, 125, 125)
                    .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 151, Short.MAX_VALUE)
                    .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(61, 61, 61))
            );
            jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tempSaveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(13, Short.MAX_VALUE))
            );

            mainTable.setBackground(new java.awt.Color(198, 244, 245));
            mainTable.setModel(tablemodel=new javax.swing.table.DefaultTableModel(
                new Object [][] {
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null}
                },
                new String [] {
                    "studentExamId", "Lab Class Test", "Lab Final Exam", "Total","GPA","Letter"
                }
            ));
            mainTable.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    mainTableMouseClicked(evt);
                }
            });
            mainTable.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    mainTableKeyReleased(evt);
                }
            });
            jScrollPane2.setViewportView(mainTable);

            jPanel3.setBackground(new java.awt.Color(26, 60, 26));
            jPanel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

            createReportButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            createReportButton.setText("Create Report");
            createReportButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    createReportButtonActionPerformed(evt);
                }
            });

            backButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            backButton.setText("Back");
            backButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    backButtonActionPerformed(evt);
                }
            });

            updateGradeSheetButton.setFont(new java.awt.Font("Tahoma", 1, 13));
            updateGradeSheetButton.setText("Update Grade Sheet");
            updateGradeSheetButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    updateGradeSheetButtonActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
            jPanel3.setLayout(jPanel3Layout);
            jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGap(67, 67, 67)
                    .addComponent(createReportButton, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(39, 39, 39)
                    .addComponent(updateGradeSheetButton, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(43, 43, 43)
                    .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(144, Short.MAX_VALUE))
            );
            jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(updateGradeSheetButton, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                        .addComponent(createReportButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap())
            );

            jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Info"));

            courseIdTextField.setEditable(false);

            teacherIdTextField.setEditable(false);

            studentSessionTextField.setEditable(false);

            studentSemesterTextField.setEditable(false);

            courseNameTextField.setEditable(false);

            jLabel3.setText("Course Teacher");

            LabExaminerNameTextField.setEditable(false);

            javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
            jPanel6.setLayout(jPanel6Layout);
            jPanel6Layout.setHorizontalGroup(
                jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel6Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(studentSessionTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 209, Short.MAX_VALUE)
                        .addComponent(studentSemesterTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 209, Short.MAX_VALUE)
                        .addComponent(teacherIdTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 209, Short.MAX_VALUE)
                        .addComponent(courseIdTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 209, Short.MAX_VALUE)
                        .addComponent(courseNameTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 209, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addComponent(LabExaminerNameTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 209, Short.MAX_VALUE))
                    .addContainerGap())
            );
            jPanel6Layout.setVerticalGroup(
                jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel6Layout.createSequentialGroup()
                    .addComponent(courseIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(teacherIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(studentSessionTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(studentSemesterTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(courseNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jLabel3)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(LabExaminerNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(39, Short.MAX_VALUE))
            );

            jLabel1.setForeground(new java.awt.Color(255, 255, 255));
            jLabel1.setText("Total Student");

            NumberOfStudentTextField.setEditable(false);

            jLabel2.setForeground(new java.awt.Color(255, 255, 255));
            jLabel2.setText("Total Student");

            NumberOfStudentTextField1.setEditable(false);

            javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
            this.setLayout(layout);
            layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(544, 544, 544)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(NumberOfStudentTextField))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 792, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addContainerGap()
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 783, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(19, 19, 19)
                                        .addComponent(NumberOfStudentTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGap(18, 18, 18)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addContainerGap(67, Short.MAX_VALUE))
            );
            layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(38, 38, 38)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel2)
                                .addComponent(NumberOfStudentTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(34, 34, 34)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(18, 18, 18)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 362, Short.MAX_VALUE)
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(NumberOfStudentTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap())
            );
        }// </editor-fold>//GEN-END:initComponents

    private void tempSaveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tempSaveButtonActionPerformed
        // TODO add your handling code here:
        
        try {
            
            Connection connectionObj = DatabaseConnection.getConnectionObject();
            DatabaseInsertion dbInsert = new DatabaseInsertion(connectionObj);
            
            for (int i = 0; i < tempTable.getRowCount(); i++) {
                
                TestMarks[i] = Double.parseDouble(tempTable.getValueAt(i, 1).toString());
                FinalMarks[i] = Double.parseDouble(tempTable.getValueAt(i, 2).toString());
                TotalMarks[i] = TestMarks[i] + FinalMarks[i];
                
                gradepoints[i]=gradeCalculate(TotalMarks[i]);
                letters[i]=letterCalculate(TotalMarks[i]);
                
             
                if(dbInsert.insertLabGradeResultInfo(resultIdentification,tempTable.getValueAt(i,0).toString(),tempTable.getValueAt(i,1).toString(),tempTable.getValueAt(i,2).toString(), String.valueOf(gradepoints[i]),letters[i],String.valueOf(TotalMarks[i]))) {
                    this.result = true;
                }else{
                    this.result=false;
                }
                
                
            }
            
            if(result){
                JOptionPane.showMessageDialog(null, "Data Inserted && Calculated database Sucessfully");
                this.loadTheTable();
            }else{
                JOptionPane.showMessageDialog(null, "Data already exist");
            }
            
            
            
        }catch(ArrayIndexOutOfBoundsException ex){
            JOptionPane.showMessageDialog(null,"Excel file can not adjust");
        }
}//GEN-LAST:event_tempSaveButtonActionPerformed

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        // TODO add your handling code here:
        if (mainTable.getEditingColumn() == -1) {
            int i = 0;
            for (i = 0; i < mainTable.getRowCount(); i++) {
                try {
                    
                    Connection connectionObj = DatabaseConnection.getConnectionObject();
                    
                    String sql = "select * from labgradeexaminedsheet where labGradeExaminedId = '" + resultIdentification + "' and studentExamRoll='"+clonedexistingLabFinalMarks[i][0]+"'";
                    System.out.println("sql: " + sql);
                    
                    Statement stmt = connectionObj.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    ResultSet rs = stmt.executeQuery(sql);
                    
                    rs.next();
                    
                    rs.updateString("labGradeExaminedId",resultIdentification);
                    
                    rs.updateString("studentExamRoll",clonedexistingLabFinalMarks[i][0]);
                    
                    rs.updateString("labClassTest", (String) mainTable.getValueAt(i, 1));
                    
                    rs.updateString("labFinalExam", (String) mainTable.getValueAt(i, 2));
                    
                    rs.updateString("total", (String) mainTable.getValueAt(i, 3));
                    
                    rs.updateString("GPA", (String) mainTable.getValueAt(i, 4)); 
                    
                    rs.updateString("LetterGrade", (String) mainTable.getValueAt(i, 5));
                    
                    rs.updateRow();
                    
                    
                    
                }catch (SQLException ex) {
                    // JOptionPane.showMessageDialog(null, ex.getMessage());
                    Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }catch (NullPointerException ex) {
                    // JOptionPane.showMessageDialog(null, ex.getMessage());
                    Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (i == rowCount1) {
                JOptionPane.showMessageDialog(this, "Lab Final Info Updated Successfully.");
                this.loadTheTable();
            }
            
        }else {
            JOptionPane.showMessageDialog(this, "Editing item cant be updated.");
        }
}//GEN-LAST:event_updateButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        // TODO add your handling code here:
        Connection connectionObj = DatabaseConnection.getConnectionObject();
        try {
            Statement stmt = connectionObj.createStatement();
            String query = "DELETE FROM labgradeexaminedsheet where labGradeExaminedId = '" + resultIdentification + "'";
            int deletedRows = stmt.executeUpdate(query);
            if (deletedRows > 0) {
                System.out.println("Deleted All Rows In The Table Successfully...");
                JOptionPane.showMessageDialog(null, "Deleted All Rows In The Table Successfully...");
                this.loadTheTable();
            } else {
                System.out.println("Table already empty.");
                JOptionPane.showMessageDialog(null, "Table already empty.");
                this.loadTheTable();
            }
            
        } catch (SQLException s) {
            System.out.println("Deleted All Rows In  Table Error. ");
            s.printStackTrace();
        }
}//GEN-LAST:event_deleteButtonActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // TODO add your handling code here:
        GradeSheetAccessPanel obj=new GradeSheetAccessPanel(identification,studentSession,semesterNo);
        this.removeAll();
        BoxLayout box=new BoxLayout(this,BoxLayout.Y_AXIS);
        this.setLayout(box);
        this.setPreferredSize(obj.getPreferredSize());
        this.add(obj);
        this.validate();
        this.repaint();
    }//GEN-LAST:event_backButtonActionPerformed

    private void createReportButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createReportButtonActionPerformed
        // TODO add your handling code here:
            Connection connection = null;
            JasperReport jasperReport = null;
            JasperPrint jasperPrint = null;

            try {
               
              
              // String reportSource = "C:/Users/SHAHRIAR/Documents/NetBeansProjects/RPS/src/UI/Report/labVerificationReport.jrxml";
               
                String reportSource=location.LabGradeSheetReportLocation();
                
                Map map = new HashMap();
                map.put("resultparam",resultIdentification);
                map.put("teacherNameparam",teacherName);
                map.put("teacherDesignationparam",teacherDesignation);
                map.put("courseIdparam",courseIdTextField.getText()); 
                map.put("courseNameparam",courseName);
                Class.forName("com.mysql.jdbc.Driver");
                connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/rpsdbms", "root", "");
                
                jasperReport = (JasperReport) JasperCompileManager.compileReport(reportSource);
                jasperPrint = JasperFillManager.fillReport(jasperReport, map, connection);
                
                connection.close();
                
                JasperViewer.viewReport(jasperPrint, false);

            } catch (Exception ex) {
                 System.err.println(ex.getMessage());
            }
    }//GEN-LAST:event_createReportButtonActionPerformed

    private void updateGradeSheetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateGradeSheetButtonActionPerformed
        // TODO add your handling code here: 
        Connection connectionObj = DatabaseConnection.getConnectionObject();
        char lastdigitofcI = courseId.charAt(courseId.length() - 1);
        char secondlastdigitofcI = courseId.charAt(courseId.length() - 2);
        
         if (secondlastdigitofcI == '0' && lastdigitofcI == '2') {

            System.out.println("YES 01");
            for (int i = 0; i < mainTable.getRowCount(); i++) {
                String sql = "UPDATE `rpsdbms`.`finalgradesheet` SET "
                        + "`Subject8Tutorial` = '" + mainTable.getValueAt(i, 1) + "',"
                        + "`Subject8LabFinal` = '" + mainTable.getValueAt(i, 2) + "',"                     
                        + "`Subject8Total` = '" + mainTable.getValueAt(i, 3) + "',"
                        + "`Subject8GPA` = '" + mainTable.getValueAt(i, 4) + "' "
                        + "WHERE `finalgradesheet`.`adminId` = '" + identification + "' AND `finalgradesheet`.`studentSession` = '" + studentSession + "' AND `finalgradesheet`.`semesterNo` = '" + semesterNo + "' AND `finalgradesheet`.`studentExamRoll` = '" + mainTable.getValueAt(i, 0) + "'";

                System.out.println(sql);
                
                Statement statementObj;

                try {

                    statementObj = connectionObj.prepareStatement(sql);
                    statementObj.executeUpdate(sql);


                } catch (SQLException ex) {
                    Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }



            }

        } else if (secondlastdigitofcI == '0' && lastdigitofcI == '4') { 
             for (int i = 0; i < mainTable.getRowCount(); i++) {
                String sql = "UPDATE `rpsdbms`.`finalgradesheet` SET "
                        + "`Subject9Tutorial` = '" + mainTable.getValueAt(i, 1) + "',"
                        + "`Subject9LabFinal` = '" + mainTable.getValueAt(i, 2) + "',"                     
                        + "`Subject9Total` = '" + mainTable.getValueAt(i, 3) + "',"
                        + "`Subject9GPA` = '" + mainTable.getValueAt(i, 4) + "' "
                        + "WHERE `finalgradesheet`.`adminId` = '" + identification + "' AND `finalgradesheet`.`studentSession` = '" + studentSession + "' AND `finalgradesheet`.`semesterNo` = '" + semesterNo + "' AND `finalgradesheet`.`studentExamRoll` = '" + mainTable.getValueAt(i, 0) + "'";

                      System.out.println(sql);

                Statement statementObj;

                try {

                    statementObj = connectionObj.prepareStatement(sql);
                    statementObj.executeUpdate(sql);


                } catch (SQLException ex) {
                    Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }



            }
            
        } else if (secondlastdigitofcI == '0' && lastdigitofcI == '6') {
             for (int i = 0; i < mainTable.getRowCount(); i++) {
                 String sql = "UPDATE `rpsdbms`.`finalgradesheet` SET "
                        + "`Subject10Tutorial` = '" + mainTable.getValueAt(i, 1) + "',"
                        + "`Subject10LabFinal` = '" + mainTable.getValueAt(i, 2) + "',"                     
                        + "`Subject10Total` = '" + mainTable.getValueAt(i, 3) + "',"
                        + "`Subject10GPA` = '" + mainTable.getValueAt(i, 4) + "' "
                        + "WHERE `finalgradesheet`.`adminId` = '" + identification + "' AND `finalgradesheet`.`studentSession` = '" + studentSession + "' AND `finalgradesheet`.`semesterNo` = '" + semesterNo + "' AND `finalgradesheet`.`studentExamRoll` = '" + mainTable.getValueAt(i, 0) + "'";

                       System.out.println(sql);

                Statement statementObj;

                try {

                    statementObj = connectionObj.prepareStatement(sql);
                    statementObj.executeUpdate(sql);


                } catch (SQLException ex) {
                    Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }



            }
        } else if (secondlastdigitofcI == '0' && lastdigitofcI == '8') { 
             for (int i = 0; i < mainTable.getRowCount(); i++) {
                String sql = "UPDATE `rpsdbms`.`finalgradesheet` SET "
                        + "`Subject11Tutorial` = '" + mainTable.getValueAt(i, 1) + "',"
                        + "`Subject11LabFinal` = '" + mainTable.getValueAt(i, 2) + "',"                     
                        + "`Subject11Total` = '" + mainTable.getValueAt(i, 3) + "',"
                        + "`Subject11GPA` = '" + mainTable.getValueAt(i, 4) + "' "
                        + "WHERE `finalgradesheet`.`adminId` = '" + identification + "' AND `finalgradesheet`.`studentSession` = '" + studentSession + "' AND `finalgradesheet`.`semesterNo` = '" + semesterNo + "' AND `finalgradesheet`.`studentExamRoll` = '" + mainTable.getValueAt(i, 0) + "'";

                      System.out.println(sql);

                Statement statementObj;

                try {

                    statementObj = connectionObj.prepareStatement(sql);
                    statementObj.executeUpdate(sql);


                } catch (SQLException ex) {
                    Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }



            }
        } else if (secondlastdigitofcI == '1' && lastdigitofcI == '2') { 
             for (int i = 0; i < mainTable.getRowCount(); i++) {
                String sql = "UPDATE `rpsdbms`.`finalgradesheet` SET "
                        + "`Subject12Tutorial` = '" + mainTable.getValueAt(i, 1) + "',"
                        + "`Subject12LabFinal` = '" + mainTable.getValueAt(i, 2) + "',"                     
                        + "`Subject12Total` = '" + mainTable.getValueAt(i, 3) + "',"
                        + "`Subject12GPA` = '" + mainTable.getValueAt(i, 4) + "' "
                        + "WHERE `finalgradesheet`.`adminId` = '" + identification + "' AND `finalgradesheet`.`studentSession` = '" + studentSession + "' AND `finalgradesheet`.`semesterNo` = '" + semesterNo + "' AND `finalgradesheet`.`studentExamRoll` = '" + mainTable.getValueAt(i, 0) + "'";


                      System.out.println(sql);
                
                Statement statementObj;

                try {

                    statementObj = connectionObj.prepareStatement(sql);
                    statementObj.executeUpdate(sql);


                } catch (SQLException ex) {
                    Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }



            }
        } 
    }//GEN-LAST:event_updateGradeSheetButtonActionPerformed

    private void mainTableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mainTableKeyReleased
        // TODO add your handling code here:
                try {
             
            double total = Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 1).toString())
                + Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 2).toString());
              
            if(total>=0 && total<=fullmarks){ 
                double grade=gradeCalculate(total);
                String letter=letterCalculate(total); 
                mainTable.setValueAt(String.valueOf(total),mainTable.getSelectedRow(),3); 
                mainTable.setValueAt(String.valueOf(grade),mainTable.getSelectedRow(),4); 
                mainTable.setValueAt(letter,mainTable.getSelectedRow(),5); 
           
            }else{
               JOptionPane.showMessageDialog(null,"Full Marks is out of range");
               mainTable.setValueAt("0.00",mainTable.getSelectedRow(),mainTable.getSelectedColumn());
            }
              
       
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
    }//GEN-LAST:event_mainTableKeyReleased

    private void mainTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainTableMouseClicked
        // TODO add your handling code here:
       
    }//GEN-LAST:event_mainTableMouseClicked

     public void SetData(Object obj, int row_index, int col_index){
           mainTable.getModel().setValueAt(obj,row_index,col_index);
     }
     public Object GetData(JTable table, int row_index, int col_index){
        
        if(table.getModel().getValueAt(row_index, col_index).equals("")){
            return 0;
        }
        else{
            return table.getModel().getValueAt(row_index, col_index);  
        }
     }
    
  
    public double gradeCalculate(double value) {

        if (value <= 100 && value >= 80) {
            return 4.00;

        } else if (value <= 79.99 && value >= 75) {
            return 3.75;

        } else if (value <= 74.99 && value >= 70) {
            return 3.50;

        } else if (value <= 69.99 && value >= 65) {
            return 3.25;

        } else if (value <= 64.99 && value >= 60) {
            return 3.00;

        } else if (value <= 59.99 && value >= 55) {
            return 2.75;

        } else if (value <= 54.99 && value >= 50) {
            return 2.50;

        } else if (value <= 49.99 && value >= 45) {
            return 2.25;

        } else if (value <= 44.99 && value >= 40) {
            return 2.00;

        } else {
            return 0.00;

        }
    }
  
    public String letterCalculate(double value) {
        if (value <= 100 && value >= 80) {

            return "A+";
        } else if (value <= 79.99 && value >= 75) {

            return "A";
        } else if (value <= 74.99 && value >= 70) {

            return "A-";
        } else if (value <= 69.99 && value >= 65) {

            return "B+";
        } else if (value <= 64.99 && value >= 60) {

            return "B";
        } else if (value <= 59.99 && value >= 55) {

            return "B-";
        } else if (value <= 54.99 && value >= 50) {

            return "C+";
        } else if (value <= 49.99 && value >= 45) {

            return "C";
        } else if (value <= 44.99 && value >= 40) {

            return "D";
        } else {

            return "F";
        }

    }
   
   private void loadTempTable() {
        rowCount2 = 0;
        try {

            for (int i = 0; i < tempTable.getRowCount();) {
                
                temptablemodel.removeRow(i);
            }
            
           
            Connection connectionObj = DatabaseConnection.getConnectionObject();
            NewInfoDatabaseRetrivation obj=new NewInfoDatabaseRetrivation(connectionObj);
          
            ResultSet rs=obj.loadTempLabGradeExaminedSheet(identification,semesterNo,studentSession,courseId);
          
           while (rs.next()) {         
                existingTempLabFinalMarks[rowCount2][0] = rs.getString("studentExamRoll");
                System.out.println("student:"+existingTempLabFinalMarks[rowCount2][0]);
                existingTempLabFinalMarks[rowCount2][1] = rs.getString("labClassTest");
                existingTempLabFinalMarks[rowCount2][2] = rs.getString("labFinalExam");
                
                String[] rowStrings = {existingTempLabFinalMarks[rowCount2][0], existingTempLabFinalMarks[rowCount2][1], existingTempLabFinalMarks[rowCount2][2]};
                temptablemodel.addRow(rowStrings);
                rowCount2++;

            } 
            
            //clonedexistingTheoryFinalMarks = existingTmpTheoryFinalMarks.clone();
            NumberOfStudentTextField1.setText(String.valueOf(rowCount2));

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Exception :" + ex);
            Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
        } 
   }  


   private void loadTheTable() {
        rowCount1 = 0;
        try {

            for (int i = 0; i < mainTable.getRowCount();) {
                
                tablemodel.removeRow(i);
            }
            
           
            Connection connectionObj = DatabaseConnection.getConnectionObject();
            NewInfoDatabaseRetrivation obj=new NewInfoDatabaseRetrivation(connectionObj);
            ResultSet rs=obj.loadLabGradeExaminedSheet(resultIdentification);
           
          
            while (rs.next()) {
                
                existingLabFinalMarks[rowCount1][0] = rs.getString("studentExamRoll");
                System.out.println("student:"+existingLabFinalMarks[rowCount1][0]);
                existingLabFinalMarks[rowCount1][1] = rs.getString("labClassTest");
                existingLabFinalMarks[rowCount1][2] = rs.getString("labFinalExam");
                existingLabFinalMarks[rowCount1][3] = rs.getString("total");
                existingLabFinalMarks[rowCount1][4] = rs.getString("GPA");
                existingLabFinalMarks[rowCount1][5] = rs.getString("LetterGrade");
               
                
                String[] rowStrings = {existingLabFinalMarks[rowCount1][0], existingLabFinalMarks[rowCount1][1], existingLabFinalMarks[rowCount1][2],existingLabFinalMarks[rowCount1][3], existingLabFinalMarks[rowCount1][4],existingLabFinalMarks[rowCount1][5]};
                tablemodel.addRow(rowStrings);
                rowCount1++;

            } 
            
            
            //
            NumberOfStudentTextField.setText(String.valueOf(rowCount1));
            clonedexistingLabFinalMarks = existingLabFinalMarks.clone();


        } catch (Exception ex) {
            //JOptionPane.showMessageDialog(null, "Exception :" + ex);
             //Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex); 
            System.out.println("Exception:"+ex.getMessage());
        } 
   }
  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField LabExaminerNameTextField;
    private javax.swing.JTextField NumberOfStudentTextField;
    private javax.swing.JTextField NumberOfStudentTextField1;
    private javax.swing.JButton backButton;
    private javax.swing.JTextField courseIdTextField;
    private javax.swing.JTextField courseNameTextField;
    private javax.swing.JButton createReportButton;
    private javax.swing.JButton deleteButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable mainTable;
    private javax.swing.JTextField studentSemesterTextField;
    private javax.swing.JTextField studentSessionTextField;
    private javax.swing.JTextField teacherIdTextField;
    private javax.swing.JButton tempSaveButton;
    private javax.swing.JTable tempTable;
    private javax.swing.JButton updateButton;
    private javax.swing.JButton updateGradeSheetButton;
    // End of variables declaration//GEN-END:variables
}
