/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package UI.Panel;

/**
 *
 * @author SHAHRIAR
 */
class Quicksort {
      public  void quicksort(double[] a, int p, int r) {
           int q;   
        if(p<r){
            q=partition(a,p,r);
            quicksort(a,p,q-1);
            quicksort(a,q+1,r);
           }
    }

    private  int partition(double[] a, int p, int r) {
        double x=a[r];
        int i=p-1;
        double temp;
      for(int j=p;j<=r-1;j++){
          if(a[j]<=x){
             i++; 
             temp=a[j];
             a[j]=a[i];
             a[i]=temp;
             
            
          }
      }
      
      temp=a[i+1];
      a[i+1]=a[r];
      a[r]=temp;
          
      return i+1;
    } 
}
