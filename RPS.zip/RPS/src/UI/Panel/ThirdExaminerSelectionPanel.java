/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * ThirdExaminerSelectionPanel.java
 *
 * Created on Oct 22, 2013, 3:25:19 AM
 */
package UI.Panel;

import Database.DatabaseConnection;
import UI.Database.DatabaseInsertion;
import UI.Database.DatabaseRetrivation;
import UI.Database.NewInfoDatabaseRetrivation;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author SHAHRIAR
 */
public class ThirdExaminerSelectionPanel extends javax.swing.JPanel {

    String session, semester, courseteacherid, adminId;
    String courseId = new String();
    String teacherId[] = new String[500];
    String teacherName[] = new String[500];
    String courseName[] = new String[500];
    JLabel courseIdlabel[] = new JLabel[100];
    JLabel courseNamelabel[] = new JLabel[100];
    String FirstExaminerId,SecondExaminerId;
    int courseCount, teacherCount;
    String firstTeacherId, secondTeacherId;
    boolean firstExaminerresult, secondExaminerresult;
    int rowCount, rowCount1;
    static DefaultTableModel model = null;
    static DefaultTableModel tablemodel = null;
    static DefaultTableModel tablemodel1 = null;
    String[][] existingTeachers = new String[500][10];
    String[][] clonedExistingTeachers = new String[500][10];
    String[][] existingTeachers1 = new String[500][10];
    String[][] clonedExistingTeachers1 = new String[500][10];
    String courseType = "theory";
    String teacherId3;
    boolean result,statusresult;
    String assignYear, assignYear1;

    public ThirdExaminerSelectionPanel(String session,String semester,String adminId,String courseId) {
          this.session=session;
          this.semester=semester;
          this.adminId=adminId;
          this.courseId=courseId;
           
            initComponents();
            
            try{
            
                studentSessionTextField.setText(session);
                

                try {

                    Connection connectionObj = DatabaseConnection.getConnectionObject();
                    DatabaseRetrivation obj = new DatabaseRetrivation(connectionObj);
                    ResultSet resultSetObj = obj.semesterNameByAdminId(adminId, semester);

                    
                    while (resultSetObj.next()) {
                        studentSemesterTextField.setText(resultSetObj.getString("a.semesterName"));
                       
                    }
                    
                    courseIdTextField.setText(courseId); 
                    
                    ResultSet resultSetObj1 = obj.courseNameByCourseId(courseId);
                    
                    while (resultSetObj1.next()) {
                        courseNameTextField.setText(resultSetObj1.getString("courseName"));
                       
                    }
                    

                } catch (SQLException ex) {
                    Logger.getLogger(GradeSheetAccessPanel.class.getName()).log(Level.SEVERE, null, ex);
                }

            
            
            Connection conn = DatabaseConnection.getConnectionObject();
            NewInfoDatabaseRetrivation assignTeacherobj=new NewInfoDatabaseRetrivation(conn);
            ResultSet rs=assignTeacherobj.getAssignTeacherIdTableBySemesterCourseId(semester,courseId);

            while (rs.next()) {
                assignIdTextField.setText(rs.getString("assignTeacherId")); 
                assignYear=rs.getString("assignYear");
                assignYearTextField.setText(assignYear); 
            }
            
            ResultSet rs1=assignTeacherobj.getFirstTeacherIdNameTableByCourseIdSemesterSession(courseId,semester,session); 
             
             while (rs1.next()) {
               FirstExaminerId=rs1.getString("b.teacherId");  
               firstExaminerNameTextField.setText(rs1.getString("a.teacherName"));
               
            } 
             
             
             ResultSet rs2=assignTeacherobj.getSecondTeacherIdNameTableByCourseIdSemesterSession(courseId,semester,session); 
             
             while (rs2.next()) {
               SecondExaminerId=rs2.getString("b.teacherId");  
               secondExaminerNameTextField.setText(rs2.getString("a.teacherName"));
               
            }
             
             
           
            NewInfoDatabaseRetrivation obj=new NewInfoDatabaseRetrivation(conn);
            ResultSet teacherrs=obj.loadThirdExaminerIdTableInfo(FirstExaminerId,SecondExaminerId);

            while (teacherrs.next()) {
            
                teacherId[rowCount] = teacherrs.getString("teacherId");
                System.out.println(teacherId[rowCount]);
                rowCount++;
            }

            System.out.println(rowCount);

            for (int i = 0; i < rowCount; i++) {

                DatabaseRetrivation obj1=new DatabaseRetrivation(conn);
                ResultSet teacherrs1=obj1.teacherNameByteacherId(teacherId[i]);

                while (teacherrs1.next()) {
                    teacherNameComboBox.addItem(teacherrs1.getString("teacherName"));
                }
            }

            this.loadTheTable();

        }catch (SQLException ex) {
           // Logger.getLogger(AssignTeacherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        courseIdTextField = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        courseNameTextField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        assignYearTextField = new javax.swing.JTextField();
        teacherNameComboBox = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        addButton = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        firstExaminerNameTextField = new javax.swing.JTextField();
        secondExaminerNameTextField = new javax.swing.JTextField();
        assignIdTextField = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        updateButton = new javax.swing.JButton();
        studentSessionTextField = new javax.swing.JTextField();
        studentSemesterTextField = new javax.swing.JTextField();

        setBackground(new java.awt.Color(89, 13, 23));

        jPanel3.setBackground(new java.awt.Color(51, 51, 0));
        jPanel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("AssignId");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Course Id");

        courseIdTextField.setEditable(false);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Course Title");

        courseNameTextField.setEditable(false);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Assign Year");

        assignYearTextField.setEditable(false);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Teacher Name");

        addButton.setFont(new java.awt.Font("Tahoma", 1, 11));
        addButton.setText("Add");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("First Examiner Name");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Second Examiner Name");

        firstExaminerNameTextField.setEditable(false);
        firstExaminerNameTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                firstExaminerNameTextFieldActionPerformed(evt);
            }
        });

        secondExaminerNameTextField.setEditable(false);

        assignIdTextField.setEditable(false);

        org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel7)
                    .add(jLabel6)
                    .add(jLabel1)
                    .add(jLabel2)
                    .add(jLabel3)
                    .add(jLabel4)
                    .add(jLabel5))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(teacherNameComboBox, 0, 267, Short.MAX_VALUE)
                    .add(assignIdTextField, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE)
                    .add(secondExaminerNameTextField, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE)
                    .add(addButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 160, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(assignYearTextField, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, firstExaminerNameTextField, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE)
                    .add(courseNameTextField, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE)
                    .add(courseIdTextField, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE))
                .add(19, 19, 19))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(23, 23, 23)
                        .add(jLabel1))
                    .add(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .add(assignIdTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .add(18, 18, 18)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(courseIdTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel2))
                .add(18, 18, 18)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(courseNameTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel3))
                .add(18, 18, 18)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel4)
                    .add(assignYearTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(18, 18, 18)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel6)
                    .add(firstExaminerNameTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(18, 18, 18)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel7)
                    .add(secondExaminerNameTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(64, 64, 64)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel3Layout.createSequentialGroup()
                        .add(teacherNameComboBox, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 151, Short.MAX_VALUE)
                        .add(addButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(36, 36, 36))
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(jLabel5)
                        .addContainerGap())))
        );

        jPanel4.setBackground(java.awt.Color.darkGray);
        jPanel4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jTable1.setModel(tablemodel=new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null,null},
                {null, null,null},
                {null, null,null},
                {null, null,null}
            },
            new String [] {
                "Course Id", "Teacher Id","Teacher Name"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        updateButton.setFont(new java.awt.Font("Tahoma", 1, 11));
        updateButton.setText("Back");
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel4Layout = new org.jdesktop.layout.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .add(30, 30, 30)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(updateButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 160, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 587, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, 18)
                .add(updateButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 43, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(59, Short.MAX_VALUE))
        );

        studentSessionTextField.setEditable(false);

        studentSemesterTextField.setEditable(false);
        studentSemesterTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentSemesterTextFieldActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .addContainerGap()
                        .add(jPanel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(layout.createSequentialGroup()
                        .add(577, 577, 577)
                        .add(studentSessionTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 169, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(83, 83, 83)
                        .add(studentSemesterTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 182, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(23, 23, 23)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(studentSessionTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(studentSemesterTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(18, 18, 18)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jPanel3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            String resultIdentification = assignIdTextField.getText().toString() + assignYearTextField.getText().toString();
            System.out.print(resultIdentification);

            Connection conn = DatabaseConnection.getConnectionObject();
            DatabaseRetrivation obj1 = new DatabaseRetrivation(conn);
            ResultSet rs = obj1.teacherIdFromTeacherName(teacherNameComboBox.getSelectedItem());
            while (rs.next()) {
                teacherId3 = rs.getString("teacherId");
            }
            
            int response = JOptionPane.showConfirmDialog(null, "Do you want to submit?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

            if (response == JOptionPane.NO_OPTION) {
                System.out.println("No button clicked");

            }else if (response == JOptionPane.YES_OPTION) {

            DatabaseInsertion dbInsert = new DatabaseInsertion(conn);
            if (dbInsert.insertCourseThirdExaminerAssignInfo(resultIdentification, courseIdTextField.getText().toString(), teacherId3, session, semester, courseType, assignYear)) {
                this.result = true;
                System.out.println("Insertion sucessfull T1");

            } else {
                this.result = false;
            }

            if (dbInsert.insertThirdExaminerStatus("ET", resultIdentification, "NO")) {
                this.statusresult = true;
                System.out.println("Insertion sucessfull T2");

            } else {
                this.statusresult = false;
            }

            this.loadTheTable();
            
            }else if (response == JOptionPane.CLOSED_OPTION) {
                 System.out.println("JOptionPane closed");
            }

            
        } catch (SQLException ex) {
            // Logger.getLogger(AssignTeacherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
}//GEN-LAST:event_addButtonActionPerformed

    private void studentSemesterTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentSemesterTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentSemesterTextFieldActionPerformed

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        // TODO add your handling code here:
        TheoryGradeSheetVerificationPanel obj = new TheoryGradeSheetVerificationPanel(adminId,courseId, semester, session);
        this.removeAll();
        BoxLayout boxlayoutObj = new BoxLayout(this, BoxLayout.Y_AXIS);
        this.setLayout(boxlayoutObj);
        this.setPreferredSize(obj.getPreferredSize());
        this.add(obj);
        this.validate();
        this.repaint();
        obj.setVisible(true);
    }//GEN-LAST:event_updateButtonActionPerformed

    private void firstExaminerNameTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_firstExaminerNameTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_firstExaminerNameTextFieldActionPerformed

    private void loadTheTable() {
        rowCount1 = 0;
        try {

            for (int i = 0; i < jTable1.getRowCount();) {

                tablemodel.removeRow(i);
            }


            Connection connectionObj = DatabaseConnection.getConnectionObject();
            NewInfoDatabaseRetrivation obj = new NewInfoDatabaseRetrivation(connectionObj);
            ResultSet rs = obj.loadAssignThirdExaminerTable(session, semester, courseType);



            while (rs.next()) {

                existingTeachers[rowCount1][0] = rs.getString("courseId");
                existingTeachers[rowCount1][1] = rs.getString("teacherId");

                DatabaseRetrivation obj1 = new DatabaseRetrivation(connectionObj);
                ResultSet teacherrs1 = obj1.teacherNameByteacherId(existingTeachers[rowCount1][1]);

                while (teacherrs1.next()) {
                    existingTeachers[rowCount1][2] = teacherrs1.getString("teacherName");
                }

                String[] rowStrings = {existingTeachers[rowCount1][0], existingTeachers[rowCount1][1], existingTeachers[rowCount1][2]};
                tablemodel.addRow(rowStrings);
                rowCount1++;

            }
            clonedExistingTeachers = existingTeachers.clone();


        } catch (Exception ex) {
            //JOptionPane.showMessageDialog(null, "Exception :" + ex);
            Logger.getLogger(AssignTheoryCourseTeacherPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JTextField assignIdTextField;
    private javax.swing.JTextField assignYearTextField;
    private javax.swing.JTextField courseIdTextField;
    private javax.swing.JTextField courseNameTextField;
    private javax.swing.JTextField firstExaminerNameTextField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField secondExaminerNameTextField;
    private javax.swing.JTextField studentSemesterTextField;
    private javax.swing.JTextField studentSessionTextField;
    private javax.swing.JComboBox teacherNameComboBox;
    private javax.swing.JButton updateButton;
    // End of variables declaration//GEN-END:variables
}
