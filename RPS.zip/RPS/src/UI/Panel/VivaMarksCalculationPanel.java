/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * VivaMarksCalculationPanel.java
 *
 * Created on Oct 18, 2013, 8:56:47 PM
 */
package UI.Panel;

import Database.DatabaseConnection;
import Database.ReportLocation;
import UI.Database.DatabaseInsertion;
import UI.Database.DatabaseRetrivation;
import UI.Database.NewInfoDatabaseRetrivation;
import java.awt.Dimension;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

public class VivaMarksCalculationPanel extends javax.swing.JPanel {

    static Vector headers = new Vector();
    // Model is used to construct JTable
    static DefaultTableModel model = null;
    static DefaultTableModel tablemodel = null;
    // data is Vector contains Data from Excel File
    static Vector data = new Vector();
    static JFileChooser jChooser;
    static int tableWidth = 0; // set the tableWidth
    static int tableHeight = 0;
    int u, rowCount1;
    private SpinnerModel model1;
    String[][] existingStudents = new String[500][10];
    String[][]existingVivaMarks = new String[500][10];
    String[][] clonedexistingVivaMarks = new String[500][10];
    boolean result;
    JTable Table1;
    private String[][] dataNames;
    private String[] columnNames;
    double ExperimentMarks[] = new double[800];
    double VivaMarks[] = new double[800];
    double TotalMarks[] = new double[800];
    double gradepoints[] = new double[800];
    String letters[] = new String[800];
    String s[] = new String[1000];
    String t[] = new String[100];
    int count, rowCount;
    int marks_per_answer = 25;
    int fullmarks = 50;
    String courseId, semesterNo, studentSession, assignlabExaminerId, identification;
    String resultIdentification, assignYear, course, teacherName, teacherDesignation;
    ReportLocation location = new ReportLocation();
    private String studentExamRoll;

    public VivaMarksCalculationPanel(String identification, String studentSession, String semesterNo) {
        try {

            this.identification = identification;
            this.semesterNo = semesterNo;
            this.studentSession = studentSession;




            //courseId="IT 800";

            jChooser = new JFileChooser();
            model1 = new SpinnerNumberModel(0, 0, 20, 1);

            Connection conn = DatabaseConnection.getConnectionObject();
            DatabaseRetrivation obj = new DatabaseRetrivation(conn);
            ResultSet resultSetObj1 = obj.loadOtherAssignTeacherYear(identification);

            while (resultSetObj1.next()) {
                assignYear = resultSetObj1.getString("adminAssignYear");
            }


            String sql = "select studentExamRoll from student where studentSemester='" + semesterNo + "'";
            System.out.println(sql);


            Statement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {

                s[count] = rs.getString("studentExamRoll");
                System.out.println(rs.getString("studentExamRoll"));
                count++;
            }

            initComponents();

            ResultSet resultSetObj2 = obj.otherCourseIdBySemester(semesterNo);

            while (resultSetObj2.next()) {
                courseIdTextField.setText(resultSetObj2.getString("courseId"));
                courseId = resultSetObj2.getString("courseId");
                courseNameTextField.setText(resultSetObj2.getString("courseName"));
                rowCount++;
            }


            ResultSet resultSetObj3 = obj.adminNameDesignationByadminId(identification);

            while (resultSetObj3.next()) {

                teacherName = resultSetObj3.getString("a.teacherName");
                teacherNameTextField.setText(resultSetObj3.getString("a.teacherName"));
                teacherDesignation = resultSetObj3.getString("a.teacherDesignation");
                teacherIdTextField.setText(resultSetObj3.getString("a.teacherDesignation"));
            }





            resultIdentification = "VV00000" + identification + assignYear + courseId;
            adminIdTextField.setText(resultIdentification);
            studentSessionTextField.setText(studentSession);
            studentSemesterTextField.setText(semesterNo);

            studentList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            studentList.addListSelectionListener(new ListSelectionListener() {

                @Override
                public void valueChanged(ListSelectionEvent e) {
                    int idx = studentList.getSelectedIndex();
                    studentExamRollTextField.setText(String.valueOf(studentList.getSelectedValue()));

                }
            });

            this.loadTheTable();

        } catch (SQLException ex) {
            Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        excelTable = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        selectExcelButton = new javax.swing.JButton();
        jSpinner1 = new javax.swing.JSpinner(model1);
        excelSaveButton = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        studentList = new javax.swing.JList(s);
        jPanel3 = new javax.swing.JPanel();
        saveButton = new javax.swing.JButton();
        createReportButton = new javax.swing.JButton();
        teacherIdTextField = new javax.swing.JTextField();
        teacherNameTextField = new javax.swing.JTextField();
        updategradesheetButton = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        studentExamRollTextField = new javax.swing.JTextField();
        experimentTextField = new javax.swing.JTextField(0);
        vivaTextField = new javax.swing.JTextField(0);
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        totalTextField = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        mainTable = new javax.swing.JTable(){

            public boolean isCellEditable(int row,int column){

                switch(column){
                    case 0:

                    return false;
                    default:
                    return true;

                }

            }};
            jPanel6 = new javax.swing.JPanel();
            courseIdTextField = new javax.swing.JTextField();
            adminIdTextField = new javax.swing.JTextField();
            studentSessionTextField = new javax.swing.JTextField();
            studentSemesterTextField = new javax.swing.JTextField();
            courseNameTextField = new javax.swing.JTextField();

            setBackground(new java.awt.Color(89, 13, 23));

            excelTable.setBackground(new java.awt.Color(198, 244, 245));
            excelTable.setModel(new javax.swing.table.DefaultTableModel(
                new Object [][] {
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null}
                },
                new String [] {
                    "Student Exam Roll", "ProjectWork", "Viva", "Total"
                }
            ));
            jScrollPane1.setViewportView(excelTable);

            jPanel1.setBackground(new java.awt.Color(26, 60, 26));
            jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

            selectExcelButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            selectExcelButton.setText("select Excel file");
            selectExcelButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    selectExcelButtonActionPerformed(evt);
                }
            });

            excelSaveButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            excelSaveButton.setText("Save");
            excelSaveButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    excelSaveButtonActionPerformed(evt);
                }
            });

            updateButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            updateButton.setText("Update");
            updateButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    updateButtonActionPerformed(evt);
                }
            });

            deleteButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            deleteButton.setText("Delete All");
            deleteButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    deleteButtonActionPerformed(evt);
                }
            });

            org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
            jPanel1.setLayout(jPanel1Layout);
            jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(jPanel1Layout.createSequentialGroup()
                    .add(210, 210, 210)
                    .add(selectExcelButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 126, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(18, 18, 18)
                    .add(jSpinner1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(18, 18, 18)
                    .add(excelSaveButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(26, 26, 26)
                    .add(updateButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 109, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(31, 31, 31)
                    .add(deleteButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 109, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(296, Short.MAX_VALUE))
            );
            jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(jSpinner1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(selectExcelButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(deleteButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 34, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(updateButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 34, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(excelSaveButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 38, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .addContainerGap(19, Short.MAX_VALUE))
            );

            studentList.setFont(new java.awt.Font("Times New Roman", 0, 24));
            studentList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
            jScrollPane4.setViewportView(studentList);

            jPanel3.setBackground(new java.awt.Color(26, 60, 26));
            jPanel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

            saveButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            saveButton.setText("Save Entry");
            saveButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    saveButtonActionPerformed(evt);
                }
            });

            createReportButton.setFont(new java.awt.Font("Tahoma", 1, 11));
            createReportButton.setText("Create Report");
            createReportButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    createReportButtonActionPerformed(evt);
                }
            });

            teacherIdTextField.setEditable(false);

            teacherNameTextField.setEditable(false);
            teacherNameTextField.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    teacherNameTextFieldActionPerformed(evt);
                }
            });

            updategradesheetButton.setFont(new java.awt.Font("Tahoma", 1, 13));
            updategradesheetButton.setText("Update Grade Sheet");
            updategradesheetButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    updategradesheetButtonActionPerformed(evt);
                }
            });

            org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
            jPanel3.setLayout(jPanel3Layout);
            jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel3Layout.createSequentialGroup()
                    .add(30, 30, 30)
                    .add(saveButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 125, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(18, 18, 18)
                    .add(createReportButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 122, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(18, 18, 18)
                    .add(updategradesheetButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 173, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 87, Short.MAX_VALUE)
                    .add(teacherIdTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 122, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(18, 18, 18)
                    .add(teacherNameTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 239, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap())
            );
            jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(jPanel3Layout.createSequentialGroup()
                    .addContainerGap()
                    .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(saveButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(createReportButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 40, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(updategradesheetButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 38, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(teacherIdTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(teacherNameTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .addContainerGap(21, Short.MAX_VALUE))
            );

            jPanel2.setBackground(new java.awt.Color(153, 153, 0));
            jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

            studentExamRollTextField.setEditable(false);

            experimentTextField.setText("0");
            experimentTextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    experimentTextFieldKeyReleased(evt);
                }
            });

            vivaTextField.setText("0");
            vivaTextField.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    vivaTextFieldKeyReleased(evt);
                }
            });

            jLabel2.setText("Student Exam Roll");

            jLabel3.setText("Viva");

            jLabel4.setText("Experiment");

            totalTextField.setEditable(false);
            totalTextField.setText("0");

            jLabel11.setText("Total");

            org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
            jPanel2.setLayout(jPanel2Layout);
            jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(jPanel2Layout.createSequentialGroup()
                    .addContainerGap()
                    .add(jLabel2)
                    .add(18, 18, 18)
                    .add(studentExamRollTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 127, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(18, 18, 18)
                    .add(jLabel4)
                    .add(18, 18, 18)
                    .add(experimentTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 156, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(18, 18, 18)
                    .add(jLabel3)
                    .add(18, 18, 18)
                    .add(vivaTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 167, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(18, 18, 18)
                    .add(jLabel11)
                    .add(18, 18, 18)
                    .add(totalTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 131, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(24, Short.MAX_VALUE))
            );
            jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(experimentTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(jLabel4)
                        .add(studentExamRollTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(jLabel2)
                        .add(jLabel3)
                        .add(vivaTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(jLabel11)
                        .add(totalTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(26, Short.MAX_VALUE))
            );

            mainTable.setBackground(new java.awt.Color(198, 244, 245));
            mainTable.setModel(tablemodel=new javax.swing.table.DefaultTableModel(
                new Object [][] {
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null}
                },
                new String [] {
                    "Student Exam Roll", "Project Work","Viva", "Total","GPA","LetterGrade"
                }
            ));
            mainTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
            mainTable.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    mainTableMouseClicked(evt);
                }
            });
            mainTable.addKeyListener(new java.awt.event.KeyAdapter() {
                public void keyPressed(java.awt.event.KeyEvent evt) {
                    mainTableKeyPressed(evt);
                }
                public void keyReleased(java.awt.event.KeyEvent evt) {
                    mainTableKeyReleased(evt);
                }
            });
            jScrollPane2.setViewportView(mainTable);

            jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Info"));

            courseIdTextField.setEditable(false);

            adminIdTextField.setEditable(false);

            studentSessionTextField.setEditable(false);

            studentSemesterTextField.setEditable(false);

            courseNameTextField.setEditable(false);

            org.jdesktop.layout.GroupLayout jPanel6Layout = new org.jdesktop.layout.GroupLayout(jPanel6);
            jPanel6.setLayout(jPanel6Layout);
            jPanel6Layout.setHorizontalGroup(
                jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(jPanel6Layout.createSequentialGroup()
                    .addContainerGap()
                    .add(jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                        .add(adminIdTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 157, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(courseIdTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 157, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(studentSessionTextField, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                        .add(studentSemesterTextField, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                        .add(org.jdesktop.layout.GroupLayout.TRAILING, courseNameTextField, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE))
                    .addContainerGap())
            );
            jPanel6Layout.setVerticalGroup(
                jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(jPanel6Layout.createSequentialGroup()
                    .add(courseIdTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                    .add(adminIdTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(18, 18, 18)
                    .add(studentSessionTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(18, 18, 18)
                    .add(studentSemesterTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                    .add(courseNameTextField, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(19, Short.MAX_VALUE))
            );

            org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(this);
            this.setLayout(layout);
            layout.setHorizontalGroup(
                layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(layout.createSequentialGroup()
                    .addContainerGap()
                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                        .add(layout.createSequentialGroup()
                            .add(jScrollPane4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 100, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(jPanel2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .add(jPanel3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 970, Short.MAX_VALUE)))
                        .add(org.jdesktop.layout.GroupLayout.TRAILING, jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 1082, Short.MAX_VALUE)
                        .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .add(18, 18, 18)
                    .add(jPanel6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap())
            );
            layout.setVerticalGroup(
                layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(layout.createSequentialGroup()
                    .addContainerGap()
                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                        .add(jPanel6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(layout.createSequentialGroup()
                            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 190, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(18, 18, 18)
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(jScrollPane4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 370, Short.MAX_VALUE)
                                .add(layout.createSequentialGroup()
                                    .add(8, 8, 8)
                                    .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 199, Short.MAX_VALUE)
                                    .add(15, 15, 15)
                                    .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                    .add(jPanel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))))
                    .addContainerGap())
            );
        }// </editor-fold>//GEN-END:initComponents

    private void selectExcelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectExcelButtonActionPerformed
        // TODO add your handling code here:
        jChooser.showOpenDialog(null);

        try {

            File file = jChooser.getSelectedFile();
            if (!file.getName().endsWith("xls")) {
                JOptionPane.showMessageDialog(null, "Please select only Excel file.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                fillData(file);
                model = new DefaultTableModel(data, headers);
                tableWidth = model.getColumnCount() * 150;
                tableHeight = model.getRowCount() * 25;
                excelTable.setPreferredSize(new Dimension(tableWidth, tableHeight));
                excelTable.setModel(model);
            }
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(null, "Thank you", "Message", JOptionPane.INFORMATION_MESSAGE);
        }
}//GEN-LAST:event_selectExcelButtonActionPerformed

    private void excelSaveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_excelSaveButtonActionPerformed
        // TODO add your handling code here:

        try {

            Connection connectionObj = DatabaseConnection.getConnectionObject();
            DatabaseInsertion dbInsert = new DatabaseInsertion(connectionObj);

            for (int i = 0; i < excelTable.getRowCount(); i++) {


                ExperimentMarks[i] = Double.parseDouble(excelTable.getValueAt(i, 1).toString());
                VivaMarks[i] = Double.parseDouble(excelTable.getValueAt(i, 2).toString());
                TotalMarks[i] = ExperimentMarks[i] + VivaMarks[i];

                gradepoints[i] = gradeCalculate(TotalMarks[i]);
                letters[i] = letterCalculate(TotalMarks[i]);


                if (dbInsert.insertOtherfinalResultInfo(resultIdentification, excelTable.getValueAt(i, 0).toString(), excelTable.getValueAt(i, 1).toString(), excelTable.getValueAt(i, 2).toString(), String.valueOf(TotalMarks[i]), String.valueOf(gradepoints[i]), letters[i])) {
                    this.result = true;
                } else {
                    this.result = false;
                }


            }

            if (result) {
                JOptionPane.showMessageDialog(null, "Data Inserted database Sucessfully");
                this.loadTheTable();
            } else {
                JOptionPane.showMessageDialog(null, "Data already exist");
            }



        } catch (ArrayIndexOutOfBoundsException ex) {
            JOptionPane.showMessageDialog(null, "Excel file can not adjust");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Exception" + ex.getMessage());
        }
}//GEN-LAST:event_excelSaveButtonActionPerformed

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        // TODO add your handling code here:
        if (mainTable.getEditingColumn() == -1) {
            int i = 0;
            for (i = 0; i < mainTable.getRowCount(); i++) {
                try {

                    Connection connectionObj = DatabaseConnection.getConnectionObject();

                    String sql = "select * from vivaexaminedsheet where vivaExaminedId = '" + resultIdentification + "' and studentExamRoll='" + clonedexistingVivaMarks[i][0] + "'";
                    System.out.println("sql: " + sql);

                    Statement stmt = connectionObj.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    ResultSet rs = stmt.executeQuery(sql);

                    rs.next();

                    rs.updateString("vivaExaminedId", resultIdentification);

                    rs.updateString("studentExamRoll", clonedexistingVivaMarks[i][0]);

                    rs.updateString("ProjectWork", (String) mainTable.getValueAt(i, 1));

                    rs.updateString("viva", (String) mainTable.getValueAt(i, 2));

                    rs.updateString("total", (String) mainTable.getValueAt(i, 3));

                    rs.updateString("GPA", (String) mainTable.getValueAt(i, 4));

                    rs.updateString("LetterGrade", (String) mainTable.getValueAt(i, 5));

                    rs.updateRow();



                } catch (SQLException ex) {
                    // JOptionPane.showMessageDialog(null, ex.getMessage());
                    Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                } catch (NullPointerException ex) {
                    // JOptionPane.showMessageDialog(null, ex.getMessage());
                    Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (i == rowCount1) {
                JOptionPane.showMessageDialog(this, "Lab Final Info Updated Successfully.");
                this.loadTheTable();
            }

        } else {
            JOptionPane.showMessageDialog(this, "Editing item cant be updated.");
        }
}//GEN-LAST:event_updateButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        // TODO add your handling code here:
        Connection connectionObj = DatabaseConnection.getConnectionObject();
        try {
            Statement stmt = connectionObj.createStatement();
            String query = "DELETE FROM vivaexaminedsheet where vivaExaminedId = '" + resultIdentification + "'";
            int deletedRows = stmt.executeUpdate(query);
            if (deletedRows > 0) {
                System.out.println("Deleted All Rows In The Table Successfully...");
                JOptionPane.showMessageDialog(null, "Deleted All Rows In The Table Successfully...");
                this.loadTheTable();
            } else {
                System.out.println("Table already empty.");
                JOptionPane.showMessageDialog(null, "Table already empty.");
                this.loadTheTable();
            }

        } catch (SQLException s) {
            System.out.println("Deleted All Rows In  Table Error. ");
            s.printStackTrace();
        }
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveButtonActionPerformed
        // TODO add your handling code here:
        try {

            Connection connectionObj = DatabaseConnection.getConnectionObject();
            DatabaseInsertion dbInsert = new DatabaseInsertion(connectionObj);

            if (studentExamRollTextField.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Please Select Exam Roll");
            } else {

                double value = Double.parseDouble(totalTextField.getText());
                if (value >= 0 && value <= fullmarks) {
                    double grade = 0;
                    String letter = null;

                    grade = gradeCalculate(value);
                    letter = letterCalculate(value);


                    if (dbInsert.insertOtherfinalResultInfo(resultIdentification, studentExamRollTextField.getText(), experimentTextField.getText(), vivaTextField.getText(), totalTextField.getText(), String.valueOf(grade), letter)) {
                        this.result = true;
                    } else {
                        this.result = false;
                    }

                    if (result) {
                        JOptionPane.showMessageDialog(null, "Data Inserted database Sucessfully");
                        this.loadTheTable();
                    } else {
                        JOptionPane.showMessageDialog(null, "Data already exist");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Full Marks is greater then " + fullmarks);
                }

            }

        } catch (ArrayIndexOutOfBoundsException ex) {
            JOptionPane.showMessageDialog(null, "Excel file can not adjust");
        }
}//GEN-LAST:event_saveButtonActionPerformed

    private void experimentTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_experimentTextFieldKeyReleased
        // TODO add your handling code here:
        try {
            double value = Double.parseDouble(experimentTextField.getText());
            if (value >= 0 && value <= marks_per_answer) {
            } else {
                JOptionPane.showMessageDialog(null, "Value is out of range");
                experimentTextField.setText("0");
            }


            double total = Double.parseDouble(experimentTextField.getText()) + Double.parseDouble(vivaTextField.getText());
            totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_experimentTextFieldKeyReleased

    private void vivaTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_vivaTextFieldKeyReleased
        // TODO add your handling code here:
        try {

            double value = Double.parseDouble(vivaTextField.getText());
            if (value >= 0 && value <= marks_per_answer) {
            } else {
                JOptionPane.showMessageDialog(null, "Value is out of range");
                vivaTextField.setText("0");
            }

            double total = Double.parseDouble(experimentTextField.getText()) + Double.parseDouble(vivaTextField.getText());
            totalTextField.setText(String.valueOf(total));
        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
}//GEN-LAST:event_vivaTextFieldKeyReleased

    private void createReportButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createReportButtonActionPerformed
        // TODO add your handling code here:
        Connection connection = null;
        JasperReport jasperReport = null;
        JasperPrint jasperPrint = null;

        try {

            //String reportSource = "C:/Users/Setu/Documents/NetBeansProjects/RPS/src/UI/Report/vivaReport.jrxml";

            String reportSource = location.VivaMarksCalculationSheetReportLocation();

            Map map = new HashMap();
            map.put("resultparam", resultIdentification);
            map.put("teacherNameparam", teacherName);
            map.put("teacherDesignationparam", teacherDesignation);
            map.put("courseIdparam", courseIdTextField.getText());
            map.put("courseNameparam", courseNameTextField.getText());
            Class.forName("com.mysql.jdbc.Driver");
            connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/rpsdbms", "root", "");

            jasperReport = (JasperReport) JasperCompileManager.compileReport(reportSource);
            jasperPrint = JasperFillManager.fillReport(jasperReport, map, connection);

            connection.close();

            JasperViewer.viewReport(jasperPrint, false);

        } catch (Exception ex) {
            System.err.println(ex.getMessage());
        }
    }//GEN-LAST:event_createReportButtonActionPerformed

    private void teacherNameTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacherNameTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_teacherNameTextFieldActionPerformed

    private void updategradesheetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updategradesheetButtonActionPerformed
        // TODO add your handling code here:
        Connection connectionObj = DatabaseConnection.getConnectionObject();
        char lastdigitofcI = courseId.charAt(courseId.length() - 1);
        char secondlastdigitofcI = courseId.charAt(courseId.length() - 2);

        if (secondlastdigitofcI == '0' && lastdigitofcI == '0') {

            System.out.println("YES 01");
            for (int i = 0; i < mainTable.getRowCount(); i++) {
                String sql = "UPDATE `rpsdbms`.`finalgradesheet` SET "
                        + "`Subject14Project` = '" + mainTable.getValueAt(i, 1) + "',"
                        + "`Subject14Viva` = '" + mainTable.getValueAt(i, 2) + "',"
                        + "`Subject14Total` = '" + mainTable.getValueAt(i, 3) + "',"
                        + "`Subject14GPA` = '" + mainTable.getValueAt(i, 4) + "' "
                        + "WHERE `finalgradesheet`.`adminId` = '" + identification + "' AND `finalgradesheet`.`studentSession` = '" + studentSession + "' AND `finalgradesheet`.`semesterNo` = '" + semesterNo + "' AND `finalgradesheet`.`studentExamRoll` = '" + mainTable.getValueAt(i, 0) + "'";

                System.out.println(sql);

                Statement statementObj;

                try {

                    statementObj = connectionObj.prepareStatement(sql);
                    statementObj.executeUpdate(sql);


                } catch (SQLException ex) {
                    Logger.getLogger(FinalExamThreeResultPanel.class.getName()).log(Level.SEVERE, null, ex);
                }



            }

        }
    }//GEN-LAST:event_updategradesheetButtonActionPerformed

    private void mainTableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mainTableKeyReleased
        // TODO add your handling code here:
        try {

          
            double total = Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 1).toString())
                    + Double.parseDouble(mainTable.getValueAt(mainTable.getSelectedRow(), 2).toString());


            if (total >= 0 && total <= fullmarks) {
                double grade = gradeCalculate(total);
                String letter = letterCalculate(total);
                mainTable.setValueAt(String.valueOf(total), mainTable.getSelectedRow(), 3);
                mainTable.setValueAt(String.valueOf(grade), mainTable.getSelectedRow(), 4);
                mainTable.setValueAt(letter, mainTable.getSelectedRow(), 5);
            } else {
                JOptionPane.showMessageDialog(null, "Full Marks is out of range");
                mainTable.setValueAt("0.00", mainTable.getSelectedRow(), mainTable.getSelectedColumn());
            }


        } catch (NumberFormatException ex) {
            System.out.println("Empty String");
        }
    }//GEN-LAST:event_mainTableKeyReleased

    private void mainTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainTableMouseClicked
        // TODO add your handling code here:
       
    }//GEN-LAST:event_mainTableMouseClicked

    private void mainTableKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mainTableKeyPressed
      
    }//GEN-LAST:event_mainTableKeyPressed

    public double gradeCalculate(double value) {
        if (value <= 50 && value >= 40) {
            return 4.00;

        } else if (value <= 39.99 && value >= 37.50) {
            return 3.75;

        } else if (value <= 37.49 && value >= 35) {
            return 3.50;

        } else if (value <= 34.99 && value >= 32.50) {
            return 3.25;

        } else if (value <= 32.49 && value >= 30) {
            return 3.00;

        } else if (value <= 29.99 && value >= 27.50) {
            return 2.75;

        } else if (value <= 27.49 && value >= 25) {
            return 2.50;

        } else if (value <= 24.99 && value >= 22.50) {
            return 2.25;

        } else if (value <= 22.49 && value >= 20) {
            return 2.00;

        } else {
            return 0.00;

        }
    }

    public String letterCalculate(double value) {
        if (value <= 50 && value >= 40) {

            return "A+";
        } else if (value <= 39.99 && value >= 37.50) {

            return "A";
        } else if (value <= 37.49 && value >= 35) {

            return "A-";
        } else if (value <= 34.99 && value >= 32.50) {

            return "B+";
        } else if (value <= 32.49 && value >= 30) {

            return "B";
        } else if (value <= 29.99 && value >= 27.50) {

            return "B-";
        } else if (value <= 27.49 && value >= 25) {

            return "C+";
        } else if (value <= 24.99 && value >= 22.50) {

            return "C";
        } else if (value <= 22.49 && value >= 20) {

            return "D";
        } else {

            return "F";
        }
    }

    void fillData(File file) {

        Workbook workbook = null;
        try {
            try {
                workbook = Workbook.getWorkbook(file);
            } catch (IOException ex) {
                Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
            }

            u = (int) jSpinner1.getValue();
            Sheet sheet = workbook.getSheet(u);

            headers.clear();
            for (int i = 0; i < sheet.getColumns(); i++) {
                Cell cell1 = sheet.getCell(i, 0);
                headers.add(cell1.getContents());
            }

            data.clear();
            for (int j = 1; j < sheet.getRows(); j++) {
                Vector d = new Vector();
                for (int i = 0; i < sheet.getColumns(); i++) {

                    Cell cell = sheet.getCell(i, j);

                    d.add(cell.getContents());

                }
                d.add("\n");
                data.add(d);
            }
        } catch (BiffException e) {
            e.printStackTrace();
        } catch (IndexOutOfBoundsException e) {
            JOptionPane.showMessageDialog(null, "Sheet can not be found");
        }
    }

    private void loadTheTable() {
        rowCount1 = 0;
        try {

            for (int i = 0; i < mainTable.getRowCount();) {

                tablemodel.removeRow(i);
            }


            Connection connectionObj = DatabaseConnection.getConnectionObject();
            NewInfoDatabaseRetrivation obj = new NewInfoDatabaseRetrivation(connectionObj);
            ResultSet rs = obj.loadOtherExaminedSheet(resultIdentification);



            while (rs.next()) {

               existingVivaMarks[rowCount1][0] = rs.getString("studentExamRoll");
                System.out.println("student:" +existingVivaMarks[rowCount1][0]);
               existingVivaMarks[rowCount1][1] = rs.getString("ProjectWork");
               existingVivaMarks[rowCount1][2] = rs.getString("viva");
               existingVivaMarks[rowCount1][3] = rs.getString("total");
               existingVivaMarks[rowCount1][4] = rs.getString("GPA");
               existingVivaMarks[rowCount1][5] = rs.getString("LetterGrade");


                String[] rowStrings = {existingVivaMarks[rowCount1][0],existingVivaMarks[rowCount1][1],existingVivaMarks[rowCount1][2],existingVivaMarks[rowCount1][3],existingVivaMarks[rowCount1][4],existingVivaMarks[rowCount1][5]};
                tablemodel.addRow(rowStrings);
                rowCount1++;

            }

            clonedexistingVivaMarks =existingVivaMarks.clone();


        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Exception :" + ex);
            Logger.getLogger(FinalExamOneResultPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField adminIdTextField;
    private javax.swing.JTextField courseIdTextField;
    private javax.swing.JTextField courseNameTextField;
    private javax.swing.JButton createReportButton;
    private javax.swing.JButton deleteButton;
    private javax.swing.JButton excelSaveButton;
    private javax.swing.JTable excelTable;
    private javax.swing.JTextField experimentTextField;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JTable mainTable;
    private javax.swing.JButton saveButton;
    private javax.swing.JButton selectExcelButton;
    private javax.swing.JTextField studentExamRollTextField;
    private javax.swing.JList studentList;
    private javax.swing.JTextField studentSemesterTextField;
    private javax.swing.JTextField studentSessionTextField;
    private javax.swing.JTextField teacherIdTextField;
    private javax.swing.JTextField teacherNameTextField;
    private javax.swing.JTextField totalTextField;
    private javax.swing.JButton updateButton;
    private javax.swing.JButton updategradesheetButton;
    private javax.swing.JTextField vivaTextField;
    // End of variables declaration//GEN-END:variables
}
