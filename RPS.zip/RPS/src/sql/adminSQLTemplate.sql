create table admin(
adminId varchar(100) primary key, 
adminUserId int(100) unique not null auto_increment,
adminTeacherId varchar(100),
adminPassword varchar(100),
foreign key(adminTeacherId) references teacher(teacherId)
);