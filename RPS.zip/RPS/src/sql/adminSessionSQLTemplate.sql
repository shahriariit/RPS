create table adminSession(
adminId varchar(100), 
adminSession varchar(100),
semesterNo varchar(100),
primary key(adminId,adminSession,semesterNo),
foreign key(adminId) references admin(adminId),
foreign key(semesterNo) references semester(semesterNo)
);