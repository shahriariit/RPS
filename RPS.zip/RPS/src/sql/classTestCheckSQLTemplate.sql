create table classTestStatus(
   classTestTagId char(2) NOT NULL, 
   classTestSerialId int(8) unsigned zerofill NOT NULL AUTO_INCREMENT, 
   assignId varchar(100) unique, 
   UNIQUE KEY  classTestSerialId(classTestSerialId),
   classTestStatus varchar(50) not null default 'NO',
   primary key(classTestTagId,classTestSerialId)
)