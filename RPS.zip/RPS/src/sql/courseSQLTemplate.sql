create table course(
courseId varchar(50) not null primary key,
courseName varchar(100),
courseCredit DECIMAL(7,2) NOT NULL DEFAULT 0,
semesterNo varchar(50),
courseType varchar(100),
foreign key(semesterNo) references semester(semesterNo)
)