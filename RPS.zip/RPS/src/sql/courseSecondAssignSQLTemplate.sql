create table courseSecondExaminerAssignTable (
   assignSecondExaminerId varchar(100) NOT NULL,  
   courseId varchar(100),
   teacherId varchar(100),
   studentSession varchar(100),
   studentSemester varchar(100), 
   courseType varchar(80), 
   teacherAssignYear varchar(100),  
   primary key(assignSecondExaminerId),
   foreign key(teacherId) references teacher(teacherId)
)ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1