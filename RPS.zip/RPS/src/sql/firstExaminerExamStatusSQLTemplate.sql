create table firstexaminedStatus(
   examinerOneTagId char(2) NOT NULL, 
   examinerserialId int(8) unsigned zerofill NOT NULL AUTO_INCREMENT, 
   assignId varchar(100) unique, 
   UNIQUE KEY examinerserialId(examinerserialId),
   ExaminerOneStatus varchar(50) not null default 'NO',
   primary key(examinerOneTagId,examinerserialId)
)