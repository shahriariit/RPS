create table labClassTestStatus(
   labClassTestTagId char(2) NOT NULL, 
   labClassTestSerialId int(8) unsigned zerofill NOT NULL AUTO_INCREMENT, 
   assignId varchar(100) unique, 
   UNIQUE KEY  labClassTestSerialId(labClassTestSerialId),
   classTestStatus varchar(50) not null default 'NO',
   primary key(labClassTestTagId,labClassTestSerialId)
)