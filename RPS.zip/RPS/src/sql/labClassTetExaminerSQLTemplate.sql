create table labClassPerformancetable (
   labClassTestId varchar(100),
   studentClassRoll varchar(100),
   studentExamRoll varchar(100),
   classTestOne DECIMAL(7,2)  NOT NULL DEFAULT 0,
   classTestTwo DECIMAL(7,2)  NOT NULL DEFAULT 0,
   classTestThree DECIMAL(7,2)  NOT NULL DEFAULT 0,
   classTestFinal DECIMAL(7,2)  NOT NULL DEFAULT 0,
   classLabReport DECIMAL(7,2)  NOT NULL DEFAULT 0,
   classAssignment DECIMAL(7,2)  NOT NULL DEFAULT 0,
   classAttendance DECIMAL(7,2)  NOT NULL DEFAULT 0,
   classPresentation DECIMAL(7,2)  NOT NULL DEFAULT 0, 
   total DECIMAL(7,2)  NOT NULL DEFAULT 0,
   primary key(labClassTestId,studentClassRoll,studentExamRoll)
  )