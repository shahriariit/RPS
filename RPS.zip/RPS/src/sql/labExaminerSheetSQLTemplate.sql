create table labExaminedSheet(
   labfinalExaminedId varchar(100), 
   studentExamRoll varchar(50) ,
   experiment   DECIMAL(7,2)  NOT NULL DEFAULT 0,
   viva   DECIMAL(7,2)  NOT NULL DEFAULT 0,
   total DECIMAL(7,2)  NOT NULL DEFAULT 0,
   primary key(labfinalExaminedId,studentExamRoll)
   
)