create table labfinalexaminedStatus(
   labfinalexaminerTagId char(2) NOT NULL, 
   labfinalexaminerserialId int(8) unsigned zerofill NOT NULL AUTO_INCREMENT, 
   assignId varchar(100) unique, 
   UNIQUE KEY labfinalexaminerserialId(labfinalexaminerserialId),
   labfinalExaminerStatus varchar(50) not null default 'NO',
   primary key(labfinalexaminerTagId,labfinalexaminerserialId)
)