create table labGradeExaminedSheet(
   labGradeExaminedId varchar(100), 
   studentExamRoll varchar(50) ,
   labClassTest   DECIMAL(7,2)  NOT NULL DEFAULT 0,
   labFinalExam   DECIMAL(7,2)  NOT NULL DEFAULT 0,
   total DECIMAL(7,2)  NOT NULL DEFAULT 0,
   primary key(labGradeExaminedId,studentExamRoll)
   
)