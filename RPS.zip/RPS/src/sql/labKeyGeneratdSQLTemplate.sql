create table labKeyGeneratedAssignmentTable (
   assignTeacherId varchar(100) NOT NULL, 
   courseId varchar(100),
   assignYear varchar(100),
   semesterNo varchar(100), 
   primary key(assignTeacherId)    
)