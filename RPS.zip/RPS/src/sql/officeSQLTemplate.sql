create table staff(
staffId varchar(35) not null primary key,
staffUserId int unique not null auto_increment, 
staffName varchar(100),
staffDesignation varchar(55),
staffJoinDate date,
staffEmailId varchar(50) unique not null,
staffSex varchar(55),
staffContactNo varchar(100),
staffPresentAddress text,
staffPermanentAddress text,
staffPassword varchar(100) unique not null 
)