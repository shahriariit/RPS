create table semester(
  semesterNo varchar(50) not null primary key,
  semesterName varchar(50),
  semesterCredit DECIMAL(7,2) NOT NULL DEFAULT 0
)