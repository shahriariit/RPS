create table student (
studentUserId int not null unique auto_increment,
studentSession varchar(100),
studentSemester varchar(100),
studentClassRoll varchar(100),
studentRegNo varchar(100),
studentExamRoll varchar(100) unique,
studentName varchar(100),
studentFatherName varchar(100),
studentMotherName varchar(100),
studentHall varchar(150),
studentSex varchar(7),
studentEmailId varchar(100),
studentContactNo varchar(15),
studentPresentAddress text,
studentPermanentAddress text,
studentPassword varchar(100) not null,
primary key(studentSession,studentClassRoll,studentExamRoll)
 
);