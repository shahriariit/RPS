create table teacher(
teacherId varchar(35) not null primary key,
teacherUserId int unique not null auto_increment, 
teacherName varchar(100),
teacherDesignation varchar(55),
teacherJoinDate varchar(50),
teacherEmailId varchar(50) unique not null,
teacherSex varchar(55),
teacherContactNo varchar(100),
teacherPresentAddress text,
teacherPermanentAddress text,
teacherPassword varchar(100) unique not null 
)