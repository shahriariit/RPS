create table temporalTheoryGradeExaminedSheet(
   adminId varchar(50), 
   adminSession varchar(100),
   semesterNo varchar(50),
   courseId varchar(50),
   studentExamRoll varchar(50) unique,
   firstExaminerMarks  DECIMAL(7,2)  NOT NULL DEFAULT 0,
   secondExaminerMarks  DECIMAL(7,2)  NOT NULL DEFAULT 0,
   tutorialMarks   DECIMAL(7,2)  NOT NULL DEFAULT 0,
   primary key(adminId,adminSession,semesterNo,courseId,studentExamRoll),
   foreign key(adminId) references admin(adminId),
   foreign key(semesterNo) references semester(semesterNo) 
   
)