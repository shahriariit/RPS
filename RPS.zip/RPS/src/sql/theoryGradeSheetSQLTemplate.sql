create table theoryGradeExaminedSheet(
   theoryGradeExaminedId varchar(100), 
   studentExamRoll varchar(50),
   firstExaminerMarks  DECIMAL(7,2)  NOT NULL DEFAULT 0,
   secondExaminerMarks  DECIMAL(7,2)  NOT NULL DEFAULT 0,
   differences  DECIMAL(7,2)  NOT NULL DEFAULT 0,
   averages  DECIMAL(7,2)  NOT NULL DEFAULT 0,
   finalMarks  DECIMAL(7,2)  NOT NULL DEFAULT 0,
   tutorialMarks   DECIMAL(7,2)  NOT NULL DEFAULT 0,
   total DECIMAL(7,2)  NOT NULL DEFAULT 0, 
   GPA DECIMAL(10,2)NOT NULL DEFAULT 0,
   LetterGrade varchar(50),  
   adminId varchar(100),
   studentSession varchar(100),
   semesterNo varchar(50), 
   courseId varchar(100),
   primary key(theoryGradeExaminedId,studentExamRoll)
 )