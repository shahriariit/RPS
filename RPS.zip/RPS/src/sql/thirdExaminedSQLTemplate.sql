create table thirdExaminedSheet(
   thirdExaminedId varchar(100), 
   studentExamRoll varchar(50) ,
   one   DECIMAL(7,2)  NOT NULL DEFAULT 0,
   two   DECIMAL(7,2)  NOT NULL DEFAULT 0,
   three DECIMAL(7,2)  NOT NULL DEFAULT 0,
   four  DECIMAL(7,2)  NOT NULL DEFAULT 0,
   five  DECIMAL(7,2)  NOT NULL DEFAULT 0,
   six   DECIMAL(7,2)  NOT NULL DEFAULT 0,
   seven DECIMAL(7,2)  NOT NULL DEFAULT 0,
   eight DECIMAL(7,2)  NOT NULL DEFAULT 0,
   total DECIMAL(7,2)  NOT NULL DEFAULT 0,
   primary key(thirdExaminedId,studentExamRoll)
)