create table vivaExaminedSheet(
   vivaExaminedId varchar(100), 
   studentExamRoll varchar(50) unique,
   experiment   DECIMAL(7,2)  NOT NULL DEFAULT 0,
   viva   DECIMAL(7,2)  NOT NULL DEFAULT 0,
   total DECIMAL(7,2)  NOT NULL DEFAULT 0,
   primary key(vivaExaminedId,studentExamRoll)
   
)